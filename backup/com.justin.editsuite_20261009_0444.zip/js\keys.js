/* Justin EDIT Suite — Comprehensive Premiere Pro Shortcuts & Feature Runner.
   Auto-generated and curated for editors: instant search, filtering by category,
   and direct command execution via Premiere ExtendScript host. */
(function () {
  "use strict";
  var cs = new CSInterface();
  var $ = function (id) { return document.getElementById(id); };

  var CATEGORIES = {
  "tools": [
    "Công cụ (Toolbox)",
    "Thanh công cụ làm việc chính trong Premiere"
  ],
  "timeline": [
    "Timeline & Trim",
    "Thao tác trên timeline, cắt gọt, dồn và di chuyển clip"
  ],
  "playback": [
    "Playback & Điều hướng",
    "Phát video, tua nhanh chậm, di chuyển playhead, frame"
  ],
  "file": [
    "Menu File & Dự án",
    "Tạo mới, mở, lưu, import, export, quản lý project"
  ],
  "edit": [
    "Menu Edit & Clipboard",
    "Undo, copy, paste, duplicate, nhãn màu, cài đặt"
  ],
  "clip": [
    "Menu Clip",
    "Thao tác trên clip: tốc độ, âm lượng, subclip, nest, đồng bộ"
  ],
  "sequence": [
    "Menu Sequence",
    "Thiết lập sequence, render, chuyển cảnh, match frame"
  ],
  "markers": [
    "Markers & In/Out",
    "Đánh dấu điểm In/Out, đặt marker, quản lý màu marker"
  ],
  "graphics": [
    "Graphics & Chữ",
    "Layer chữ, hình khối, căn chỉnh, cỡ chữ, dãn dòng"
  ],
  "audio": [
    "Âm thanh & Mixer",
    "Âm lượng clip, Audio Track Mixer, Pan, Mute, Solo"
  ],
  "multicam": [
    "Multi-Camera",
    "Cắt góc máy, chọn camera, bật tắt chế độ multicam"
  ],
  "panels": [
    "Panels & Workspace",
    "Không gian làm việc, mở các bảng điều khiển, phóng to cửa sổ"
  ],
  "text": [
    "Text Panel & Phụ đề",
    "Transcript, sửa câu thoại, gộp/tách câu, tạo captions"
  ],
  "view": [
    "View & Màn hình Monitor",
    "Program Monitor, Source Monitor, thước đo, đường gióng"
  ],
  "general": [
    "Tính năng khác",
    "Các lệnh điều khiển và thiết lập bổ trợ trong Premiere"
  ]
};

  var ITEMS = [
  {
    "name": "Selection Tool",
    "key": "V",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Selection Tool",
    "desc": "Công cụ chọn cơ bản (di chuyển, chọn clip trên timeline)",
    "cmd": "Selection Tool"
  },
  {
    "name": "Track Select Backward Tool",
    "key": "Shift+A",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Track Select Backward Tool",
    "desc": "Chọn tất cả clip về phía trước playhead/con trỏ",
    "cmd": "Track Select Backward Tool"
  },
  {
    "name": "Track Select Forward Tool",
    "key": "A",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Track Select Forward Tool",
    "desc": "Chọn tất cả clip về phía sau playhead/con trỏ",
    "cmd": "Track Select Forward Tool"
  },
  {
    "name": "Ripple Edit Tool",
    "key": "B",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Ripple Edit Tool",
    "desc": "Kéo dài/thu ngắn clip và tự động dồn timeline",
    "cmd": "Ripple Edit Tool"
  },
  {
    "name": "Rolling Edit Tool",
    "key": "N",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Rolling Edit Tool",
    "desc": "Dời điểm nối giữa 2 clip liền kề (tổng thời lượng không đổi)",
    "cmd": "Rolling Edit Tool"
  },
  {
    "name": "Rate Stretch Tool",
    "key": "R",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Rate Stretch Tool",
    "desc": "Kéo co giãn tốc độ playback của clip trực tiếp trên timeline",
    "cmd": "Rate Stretch Tool"
  },
  {
    "name": "Razor Tool",
    "key": "C",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Razor Tool",
    "desc": "Dao cắt clip tại vị trí click chuột",
    "cmd": "Razor Tool"
  },
  {
    "name": "Slip Tool",
    "key": "Y",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Slip Tool",
    "desc": "Trượt nội dung hiển thị bên trong clip mà không đổi vị trí/độ dài",
    "cmd": "Slip Tool"
  },
  {
    "name": "Slide Tool",
    "key": "U",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Slide Tool",
    "desc": "Trượt clip dọc timeline, 2 clip xung quanh tự co giãn bù trừ",
    "cmd": "Slide Tool"
  },
  {
    "name": "Pen Tool",
    "key": "P",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Pen Tool",
    "desc": "Bút vẽ path, keyframe và tạo mask tự do",
    "cmd": "Pen Tool"
  },
  {
    "name": "Hand Tool",
    "key": "H",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Hand Tool",
    "desc": "Bàn tay cuộn kéo không gian timeline",
    "cmd": "Hand Tool"
  },
  {
    "name": "Zoom Tool",
    "key": "Z",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Zoom Tool",
    "desc": "Kính lúp phóng to thu nhỏ timeline",
    "cmd": "Zoom Tool"
  },
  {
    "name": "Type Tool",
    "key": "T",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Type Tool",
    "desc": "Công cụ gõ chữ / tạo tiêu đề trực tiếp trên Program Monitor",
    "cmd": "Type Tool"
  },
  {
    "name": "Rectangle Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Rectangle Tool",
    "desc": "Vẽ hình chữ nhật đồ họa",
    "cmd": "Rectangle Tool"
  },
  {
    "name": "Vertical Type Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Vertical Type Tool",
    "desc": "Gõ chữ theo chiều dọc",
    "cmd": "Vertical Type Tool"
  },
  {
    "name": "Ellipse Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Ellipse Tool",
    "desc": "Vẽ hình elip / tròn đồ họa",
    "cmd": "Ellipse Tool"
  },
  {
    "name": "Remix Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Remix Tool",
    "desc": "AI tự động remix và co giãn độ dài bài nhạc bám theo nhịp",
    "cmd": "Remix Tool"
  },
  {
    "name": "Polygon Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Polygon Tool",
    "desc": "Vẽ hình đa giác đồ họa",
    "cmd": "Polygon Tool"
  },
  {
    "name": "Object Mask Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Object Mask Tool",
    "desc": "Mặt nạ AI tự động bám theo đối tượng chuyển động",
    "cmd": "Object Mask Tool"
  },
  {
    "name": "Ellipse Mask Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Ellipse Mask Tool",
    "desc": "Tạo mặt nạ hình elip",
    "cmd": "Ellipse Mask Tool"
  },
  {
    "name": "Rectangle Mask Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Rectangle Mask Tool",
    "desc": "Tạo mặt nạ hình chữ nhật",
    "cmd": "Rectangle Mask Tool"
  },
  {
    "name": "Pen Mask Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Pen Mask Tool",
    "desc": "Tạo mặt nạ vẽ tay tự do bằng Pen Tool",
    "cmd": "Pen Mask Tool"
  },
  {
    "name": "HSL Mask Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > HSL Mask Tool",
    "desc": "Tạo mặt nạ chọn theo dải màu sắc (Hue, Saturation, Luminance)",
    "cmd": "HSL Mask Tool"
  },
  {
    "name": "Luminance Mask Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Luminance Mask Tool",
    "desc": "Tạo mặt nạ chọn theo độ sáng tối của video",
    "cmd": "Luminance Mask Tool"
  },
  {
    "name": "Generative Extend Tool",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Generative Extend Tool",
    "desc": "AI sinh thêm khung hình kéo dài video hoặc audio tự nhiên",
    "cmd": "Generative Extend Tool"
  },
  {
    "name": "Project...",
    "key": "Ctrl+Alt+N",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Project...",
    "desc": "Tạo project mới hoặc mở project",
    "cmd": "Project..."
  },
  {
    "name": "Production...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Production...",
    "desc": "Lệnh trong menu Application > File > New > Production...",
    "cmd": "Production..."
  },
  {
    "name": "Team Project...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Team Project...",
    "desc": "Lệnh trong menu Application > File > New > Team Project...",
    "cmd": "Team Project..."
  },
  {
    "name": "Sequence...",
    "key": "Ctrl+N",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Sequence...",
    "desc": "Tạo sequence mới",
    "cmd": "Sequence..."
  },
  {
    "name": "Sequence From Clip",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Sequence From Clip",
    "desc": "Lệnh trong menu Application > File > New > Sequence From Clip",
    "cmd": "Sequence From Clip"
  },
  {
    "name": "Bin",
    "key": "Ctrl+/",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Bin",
    "desc": "Tạo thư mục bin mới trong project để quản lý media",
    "cmd": "Bin"
  },
  {
    "name": "Bin From Selection",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Bin From Selection",
    "desc": "Lệnh trong menu Application > File > New > Bin From Selection",
    "cmd": "Bin From Selection"
  },
  {
    "name": "Search Bin",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Search Bin",
    "desc": "Lệnh trong menu Application > File > New > Search Bin",
    "cmd": "Search Bin"
  },
  {
    "name": "Project Shortcut",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Project Shortcut",
    "desc": "Lệnh trong menu Application > File > New > Project Shortcut",
    "cmd": "Project Shortcut"
  },
  {
    "name": "Linked Team Project...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Linked Team Project...",
    "desc": "Lệnh trong menu Application > File > New > Linked Team Project...",
    "cmd": "Linked Team Project..."
  },
  {
    "name": "Offline File...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Offline File...",
    "desc": "Lệnh trong menu Application > File > New > Offline File...",
    "cmd": "Offline File..."
  },
  {
    "name": "Adjustment Layer...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > File > New > Adjustment Layer...",
    "desc": "Tạo lớp hiệu ứng Adjustment Layer áp chung cho các track bên dưới",
    "cmd": "Adjustment Layer..."
  },
  {
    "name": "Photoshop File...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > New > Photoshop File...",
    "desc": "Lệnh trong menu Application > File > New > Photoshop File...",
    "cmd": "Photoshop File..."
  },
  {
    "name": "Open Project...",
    "key": "Ctrl+O",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Open Project...",
    "desc": "Lệnh trong menu Application > File > Open Project...",
    "cmd": "Open Project..."
  },
  {
    "name": "Open Production...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Open Production...",
    "desc": "Lệnh trong menu Application > File > Open Production...",
    "cmd": "Open Production..."
  },
  {
    "name": "Open Team Project...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Open Team Project...",
    "desc": "Lệnh trong menu Application > File > Open Team Project...",
    "cmd": "Open Team Project..."
  },
  {
    "name": "Close",
    "key": "Ctrl+W",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Close",
    "desc": "Đóng panel hoặc cửa sổ hiện tại",
    "cmd": "Close"
  },
  {
    "name": "Close Project",
    "key": "Ctrl+Shift+W",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Close Project",
    "desc": "Đóng project hiện tại",
    "cmd": "Close Project"
  },
  {
    "name": "Close Production",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Close Production",
    "desc": "Lệnh trong menu Application > File > Close Production",
    "cmd": "Close Production"
  },
  {
    "name": "Close All Projects",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Close All Projects",
    "desc": "Lệnh trong menu Application > File > Close All Projects",
    "cmd": "Close All Projects"
  },
  {
    "name": "Close All Other Projects",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Close All Other Projects",
    "desc": "Lệnh trong menu Application > File > Close All Other Projects",
    "cmd": "Close All Other Projects"
  },
  {
    "name": "Refresh All Projects",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Refresh All Projects",
    "desc": "Lệnh trong menu Application > File > Refresh All Projects",
    "cmd": "Refresh All Projects"
  },
  {
    "name": "Save",
    "key": "Ctrl+S",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Save",
    "desc": "Lưu project hiện tại",
    "cmd": "Save"
  },
  {
    "name": "Save As...",
    "key": "Ctrl+Shift+S",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Save As...",
    "desc": "Lưu project thành file mới với tên khác",
    "cmd": "Save As..."
  },
  {
    "name": "Save a Copy...",
    "key": "Ctrl+Alt+S",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Save a Copy...",
    "desc": "Lưu một bản sao project phụ",
    "cmd": "Save a Copy..."
  },
  {
    "name": "Save as Template...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Save as Template...",
    "desc": "Lệnh trong menu Application > File > Save as Template...",
    "cmd": "Save as Template..."
  },
  {
    "name": "Save All",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Save All",
    "desc": "Lệnh trong menu Application > File > Save All",
    "cmd": "Save All"
  },
  {
    "name": "Revert",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Revert",
    "desc": "Lệnh trong menu Application > File > Revert",
    "cmd": "Revert"
  },
  {
    "name": "Link Media...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Link Media...",
    "desc": "Lệnh trong menu Application > File > Link Media...",
    "cmd": "Link Media..."
  },
  {
    "name": "Make Offline...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Make Offline...",
    "desc": "Lệnh trong menu Application > File > Make Offline...",
    "cmd": "Make Offline..."
  },
  {
    "name": "Replace with After Effects Composition",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Adobe Dynamic Link > Replace with After Effects Composition",
    "desc": "Lệnh trong menu Application > File > Adobe Dynamic Link > Replace with After Effects Composition",
    "cmd": "Replace with After Effects Composition"
  },
  {
    "name": "New After Effects Composition...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Adobe Dynamic Link > New After Effects Composition...",
    "desc": "Lệnh trong menu Application > File > Adobe Dynamic Link > New After Effects Composition...",
    "cmd": "New After Effects Composition..."
  },
  {
    "name": "Import After Effects Composition...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Adobe Dynamic Link > Import After Effects Composition...",
    "desc": "Lệnh trong menu Application > File > Adobe Dynamic Link > Import After Effects Composition...",
    "cmd": "Import After Effects Composition..."
  },
  {
    "name": "Import from Media Browser",
    "key": "Ctrl+Alt+I",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Import from Media Browser",
    "desc": "Import clip được chọn từ Media Browser vào project",
    "cmd": "Import from Media Browser"
  },
  {
    "name": "Import...",
    "key": "Ctrl+I",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Import...",
    "desc": "Import file media vào project",
    "cmd": "Import..."
  },
  {
    "name": "Create in Adobe Firefly...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Create in Adobe Firefly...",
    "desc": "Lệnh trong menu Application > File > Create in Adobe Firefly...",
    "cmd": "Create in Adobe Firefly..."
  },
  {
    "name": "Brainstorm in Adobe Firefly Boards...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Brainstorm in Adobe Firefly Boards...",
    "desc": "Lệnh trong menu Application > File > Brainstorm in Adobe Firefly Boards...",
    "cmd": "Brainstorm in Adobe Firefly Boards..."
  },
  {
    "name": "Search Adobe Stock...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Search Adobe Stock...",
    "desc": "Lệnh trong menu Application > File > Search Adobe Stock...",
    "cmd": "Search Adobe Stock..."
  },
  {
    "name": "Media...",
    "key": "Ctrl+M",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > Media...",
    "desc": "Mở hộp thoại Export Media để xuất video",
    "cmd": "Media..."
  },
  {
    "name": "Send to Adobe Media Encoder",
    "key": "Alt+Shift+M",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > Send to Adobe Media Encoder",
    "desc": "Đưa sequence vào hàng đợi Adobe Media Encoder để render nền",
    "cmd": "Send to Adobe Media Encoder"
  },
  {
    "name": "Motion Graphics Template...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > File > Export > Motion Graphics Template...",
    "desc": "Lệnh trong menu Application > File > Export > Motion Graphics Template...",
    "cmd": "Motion Graphics Template..."
  },
  {
    "name": "Captions...",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Application > File > Export > Captions...",
    "desc": "Lệnh trong menu Application > File > Export > Captions...",
    "cmd": "Captions..."
  },
  {
    "name": "EDL...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > EDL...",
    "desc": "Lệnh trong menu Application > File > Export > EDL...",
    "cmd": "EDL..."
  },
  {
    "name": "OMF...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > OMF...",
    "desc": "Lệnh trong menu Application > File > Export > OMF...",
    "cmd": "OMF..."
  },
  {
    "name": "Markers...",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > File > Export > Markers...",
    "desc": "Lệnh trong menu Application > File > Export > Markers...",
    "cmd": "Markers..."
  },
  {
    "name": "Selection as Premiere Project...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > Selection as Premiere Project...",
    "desc": "Lệnh trong menu Application > File > Export > Selection as Premiere Project...",
    "cmd": "Selection as Premiere Project..."
  },
  {
    "name": "OpenTimelineIO...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > OpenTimelineIO...",
    "desc": "Lệnh trong menu Application > File > Export > OpenTimelineIO...",
    "cmd": "OpenTimelineIO..."
  },
  {
    "name": "AAF...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > AAF...",
    "desc": "Lệnh trong menu Application > File > Export > AAF...",
    "cmd": "AAF..."
  },
  {
    "name": "Avid Log Exchange...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > Avid Log Exchange...",
    "desc": "Lệnh trong menu Application > File > Export > Avid Log Exchange...",
    "cmd": "Avid Log Exchange..."
  },
  {
    "name": "Final Cut Pro XML...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Export > Final Cut Pro XML...",
    "desc": "Xuất file XML Final Cut Pro để chia sẻ sang DaVinci Resolve hoặc dựng ngoài",
    "cmd": "Final Cut Pro XML..."
  },
  {
    "name": "File...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Get Media File Properties for > File...",
    "desc": "Lệnh trong menu Application > File > Get Media File Properties for > File...",
    "cmd": "File..."
  },
  {
    "name": "Selection...",
    "key": "Ctrl+Shift+H",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Get Media File Properties for > Selection...",
    "desc": "Lệnh trong menu Application > File > Get Media File Properties for > Selection...",
    "cmd": "Selection..."
  },
  {
    "name": "General...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Project Settings > General...",
    "desc": "Lệnh trong menu Application > File > Project Settings > General...",
    "cmd": "General..."
  },
  {
    "name": "Color...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Project Settings > Color...",
    "desc": "Lệnh trong menu Application > File > Project Settings > Color...",
    "cmd": "Color..."
  },
  {
    "name": "Scratch Disks...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Project Settings > Scratch Disks...",
    "desc": "Lệnh trong menu Application > File > Project Settings > Scratch Disks...",
    "cmd": "Scratch Disks..."
  },
  {
    "name": "Ingest Settings...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Project Settings > Ingest Settings...",
    "desc": "Lệnh trong menu Application > File > Project Settings > Ingest Settings...",
    "cmd": "Ingest Settings..."
  },
  {
    "name": "General...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Production Settings > General...",
    "desc": "Lệnh trong menu Application > File > Production Settings > General...",
    "cmd": "General..."
  },
  {
    "name": "Color...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Production Settings > Color...",
    "desc": "Lệnh trong menu Application > File > Production Settings > Color...",
    "cmd": "Color..."
  },
  {
    "name": "Scratch Disks...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Production Settings > Scratch Disks...",
    "desc": "Lệnh trong menu Application > File > Production Settings > Scratch Disks...",
    "cmd": "Scratch Disks..."
  },
  {
    "name": "Project Manager...",
    "key": "",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Project Manager...",
    "desc": "Gom trọn gói media của project để lưu trữ (archive/collect files)",
    "cmd": "Project Manager..."
  },
  {
    "name": "Exit",
    "key": "Ctrl+Q",
    "cat": "file",
    "catName": "Menu File & Dự án",
    "path": "Application > File > Exit",
    "desc": "Thoát Premiere Pro",
    "cmd": "Exit"
  },
  {
    "name": "Undo",
    "key": "Ctrl+Z",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Undo",
    "desc": "Hoàn tác thao tác vừa thực hiện",
    "cmd": "Undo"
  },
  {
    "name": "Redo",
    "key": "Ctrl+Shift+Z",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Redo",
    "desc": "Làm lại thao tác vừa hoàn tác",
    "cmd": "Redo"
  },
  {
    "name": "Cut",
    "key": "Ctrl+X",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Cut",
    "desc": "Cắt đối tượng vào clipboard",
    "cmd": "Cut"
  },
  {
    "name": "Copy",
    "key": "Ctrl+C",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Copy",
    "desc": "Sao chép đối tượng vào clipboard",
    "cmd": "Copy"
  },
  {
    "name": "Paste",
    "key": "Ctrl+V",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Paste",
    "desc": "Dán đối tượng từ clipboard tại playhead",
    "cmd": "Paste"
  },
  {
    "name": "Paste Insert",
    "key": "Ctrl+Shift+V",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Paste Insert",
    "desc": "Dán chèn (dồn các clip sau ra để chèn vào)",
    "cmd": "Paste Insert"
  },
  {
    "name": "Paste Attributes...",
    "key": "Ctrl+Alt+V",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Paste Attributes...",
    "desc": "Dán các thuộc tính/effect/motion đã copy sang clip khác",
    "cmd": "Paste Attributes..."
  },
  {
    "name": "Remove Attributes...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Remove Attributes...",
    "desc": "Lệnh trong menu Application > Edit > Remove Attributes...",
    "cmd": "Remove Attributes..."
  },
  {
    "name": "Clear",
    "key": "Delete",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Clear",
    "desc": "Xóa đối tượng đang chọn (để lại khoảng trống)",
    "cmd": "Clear"
  },
  {
    "name": "Ripple Delete",
    "key": "Shift+Delete",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Ripple Delete",
    "desc": "Xóa đối tượng và dồn toàn bộ khoảng trống lại",
    "cmd": "Ripple Delete"
  },
  {
    "name": "Duplicate",
    "key": "Ctrl+Shift+/",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Duplicate",
    "desc": "Nhân đôi clip hoặc sequence đã chọn",
    "cmd": "Duplicate"
  },
  {
    "name": "Select All",
    "key": "Ctrl+A",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Select All",
    "desc": "Chọn tất cả clip trên timeline hoặc item trong bin",
    "cmd": "Select All"
  },
  {
    "name": "Select All Matching",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Select All Matching",
    "desc": "Lệnh trong menu Application > Edit > Select All Matching",
    "cmd": "Select All Matching"
  },
  {
    "name": "Deselect All",
    "key": "Ctrl+Shift+A",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Deselect All",
    "desc": "Bỏ chọn tất cả",
    "cmd": "Deselect All"
  },
  {
    "name": "Find...",
    "key": "Ctrl+F",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Find...",
    "desc": "Tìm kiếm clip hoặc text",
    "cmd": "Find..."
  },
  {
    "name": "Find Next",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Find Next",
    "desc": "Lệnh trong menu Application > Edit > Find Next",
    "cmd": "Find Next"
  },
  {
    "name": "Check Spelling",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Spelling > Check Spelling",
    "desc": "Lệnh trong menu Application > Edit > Spelling > Check Spelling",
    "cmd": "Check Spelling"
  },
  {
    "name": "Spell Check Settings...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Spelling > Spell Check Settings...",
    "desc": "Lệnh trong menu Application > Edit > Spelling > Spell Check Settings...",
    "cmd": "Spell Check Settings..."
  },
  {
    "name": "Select Label Group",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Select Label Group",
    "desc": "Lệnh trong menu Application > Edit > Label > Select Label Group",
    "cmd": "Select Label Group"
  },
  {
    "name": "Violet",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Violet",
    "desc": "Lệnh trong menu Application > Edit > Label > Violet",
    "cmd": "Violet"
  },
  {
    "name": "Iris",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Iris",
    "desc": "Lệnh trong menu Application > Edit > Label > Iris",
    "cmd": "Iris"
  },
  {
    "name": "Caribbean",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Caribbean",
    "desc": "Lệnh trong menu Application > Edit > Label > Caribbean",
    "cmd": "Caribbean"
  },
  {
    "name": "Lavender",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Lavender",
    "desc": "Lệnh trong menu Application > Edit > Label > Lavender",
    "cmd": "Lavender"
  },
  {
    "name": "Cerulean",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Cerulean",
    "desc": "Lệnh trong menu Application > Edit > Label > Cerulean",
    "cmd": "Cerulean"
  },
  {
    "name": "Forest",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Forest",
    "desc": "Lệnh trong menu Application > Edit > Label > Forest",
    "cmd": "Forest"
  },
  {
    "name": "Rose",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Rose",
    "desc": "Lệnh trong menu Application > Edit > Label > Rose",
    "cmd": "Rose"
  },
  {
    "name": "Mango",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Mango",
    "desc": "Lệnh trong menu Application > Edit > Label > Mango",
    "cmd": "Mango"
  },
  {
    "name": "Purple",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Purple",
    "desc": "Lệnh trong menu Application > Edit > Label > Purple",
    "cmd": "Purple"
  },
  {
    "name": "Blue",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Blue",
    "desc": "Lệnh trong menu Application > Edit > Label > Blue",
    "cmd": "Blue"
  },
  {
    "name": "Teal",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Teal",
    "desc": "Lệnh trong menu Application > Edit > Label > Teal",
    "cmd": "Teal"
  },
  {
    "name": "Magenta",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Magenta",
    "desc": "Lệnh trong menu Application > Edit > Label > Magenta",
    "cmd": "Magenta"
  },
  {
    "name": "Tan",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Tan",
    "desc": "Lệnh trong menu Application > Edit > Label > Tan",
    "cmd": "Tan"
  },
  {
    "name": "Green",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Green",
    "desc": "Lệnh trong menu Application > Edit > Label > Green",
    "cmd": "Green"
  },
  {
    "name": "Brown",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Brown",
    "desc": "Lệnh trong menu Application > Edit > Label > Brown",
    "cmd": "Brown"
  },
  {
    "name": "Yellow",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Label > Yellow",
    "desc": "Lệnh trong menu Application > Edit > Label > Yellow",
    "cmd": "Yellow"
  },
  {
    "name": "Remove Unused",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Remove Unused",
    "desc": "Lệnh trong menu Application > Edit > Remove Unused",
    "cmd": "Remove Unused"
  },
  {
    "name": "Consolidate Duplicates",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Consolidate Duplicates",
    "desc": "Lệnh trong menu Application > Edit > Consolidate Duplicates",
    "cmd": "Consolidate Duplicates"
  },
  {
    "name": "Generate Source Clips for Media",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Generate Source Clips for Media",
    "desc": "Lệnh trong menu Application > Edit > Generate Source Clips for Media",
    "cmd": "Generate Source Clips for Media"
  },
  {
    "name": "Reassociate Source Clips...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Reassociate Source Clips...",
    "desc": "Lệnh trong menu Application > Edit > Reassociate Source Clips...",
    "cmd": "Reassociate Source Clips..."
  },
  {
    "name": "Update",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Team Project > Update",
    "desc": "Lệnh trong menu Application > Edit > Team Project > Update",
    "cmd": "Update"
  },
  {
    "name": "Publish",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Team Project > Publish",
    "desc": "Lệnh trong menu Application > Edit > Team Project > Publish",
    "cmd": "Publish"
  },
  {
    "name": "Resolve Conflicts...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Team Project > Resolve Conflicts...",
    "desc": "Lệnh trong menu Application > Edit > Team Project > Resolve Conflicts...",
    "cmd": "Resolve Conflicts..."
  },
  {
    "name": "Convert Project to Team Project...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Team Project > Convert Project to Team Project...",
    "desc": "Lệnh trong menu Application > Edit > Team Project > Convert Project to Team Project...",
    "cmd": "Convert Project to Team Project..."
  },
  {
    "name": "Convert Team Project to Project...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Team Project > Convert Team Project to Project...",
    "desc": "Lệnh trong menu Application > Edit > Team Project > Convert Team Project to Project...",
    "cmd": "Convert Team Project to Project..."
  },
  {
    "name": "Media Management...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Team Project > Media Management...",
    "desc": "Lệnh trong menu Application > Edit > Team Project > Media Management...",
    "cmd": "Media Management..."
  },
  {
    "name": "Browse Versions",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Team Project > Browse Versions",
    "desc": "Lệnh trong menu Application > Edit > Team Project > Browse Versions",
    "cmd": "Browse Versions"
  },
  {
    "name": "Browse Auto-Saves",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Team Project > Browse Auto-Saves",
    "desc": "Lệnh trong menu Application > Edit > Team Project > Browse Auto-Saves",
    "cmd": "Browse Auto-Saves"
  },
  {
    "name": "Edit Original",
    "key": "Ctrl+E",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Edit Original",
    "desc": "Lệnh trong menu Application > Edit > Edit Original",
    "cmd": "Edit Original"
  },
  {
    "name": "Clip",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Edit in Adobe Audition > Clip",
    "desc": "Lệnh trong menu Application > Edit > Edit in Adobe Audition > Clip",
    "cmd": "Clip"
  },
  {
    "name": "Sequence...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Edit in Adobe Audition > Sequence...",
    "desc": "Tạo sequence mới",
    "cmd": "Sequence..."
  },
  {
    "name": "Edit in Adobe Photoshop",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Edit in Adobe Photoshop",
    "desc": "Lệnh trong menu Application > Edit > Edit in Adobe Photoshop",
    "cmd": "Edit in Adobe Photoshop"
  },
  {
    "name": "Keyboard Shortcuts...",
    "key": "Ctrl+Alt+K",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Keyboard Shortcuts...",
    "desc": "Mở bảng tùy biến phím tắt của Premiere Pro",
    "cmd": "Keyboard Shortcuts..."
  },
  {
    "name": "General...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > General...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > General...",
    "cmd": "General..."
  },
  {
    "name": "Appearance...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Appearance...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Appearance...",
    "cmd": "Appearance..."
  },
  {
    "name": "AI Models...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > AI Models...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > AI Models...",
    "cmd": "AI Models..."
  },
  {
    "name": "Audio...",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Edit > Preferences > Audio...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Audio...",
    "cmd": "Audio..."
  },
  {
    "name": "Audio Hardware...",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Edit > Preferences > Audio Hardware...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Audio Hardware...",
    "cmd": "Audio Hardware..."
  },
  {
    "name": "Auto Save...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Auto Save...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Auto Save...",
    "cmd": "Auto Save..."
  },
  {
    "name": "Cloud Media Downloads...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Cloud Media Downloads...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Cloud Media Downloads...",
    "cmd": "Cloud Media Downloads..."
  },
  {
    "name": "Collaboration...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Collaboration...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Collaboration...",
    "cmd": "Collaboration..."
  },
  {
    "name": "Color...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Color...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Color...",
    "cmd": "Color..."
  },
  {
    "name": "Control Surface...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Control Surface...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Control Surface...",
    "cmd": "Control Surface..."
  },
  {
    "name": "Graphics...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Edit > Preferences > Graphics...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Graphics...",
    "cmd": "Graphics..."
  },
  {
    "name": "Labels...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Labels...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Labels...",
    "cmd": "Labels..."
  },
  {
    "name": "Media...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Media...",
    "desc": "Mở hộp thoại Export Media để xuất video",
    "cmd": "Media..."
  },
  {
    "name": "Media Analysis  Transcription...",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Application > Edit > Preferences > Media Analysis  Transcription...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Media Analysis  Transcription...",
    "cmd": "Media Analysis  Transcription..."
  },
  {
    "name": "Media Cache...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Media Cache...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Media Cache...",
    "cmd": "Media Cache..."
  },
  {
    "name": "Memory...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Memory...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Memory...",
    "cmd": "Memory..."
  },
  {
    "name": "Playback...",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Edit > Preferences > Playback...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Playback...",
    "cmd": "Playback..."
  },
  {
    "name": "Plugins...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Plugins...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Plugins...",
    "cmd": "Plugins..."
  },
  {
    "name": "Timeline...",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit > Preferences > Timeline...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Timeline...",
    "cmd": "Timeline..."
  },
  {
    "name": "Trim...",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Edit > Preferences > Trim...",
    "desc": "Lệnh trong menu Application > Edit > Preferences > Trim...",
    "cmd": "Trim..."
  },
  {
    "name": "Rename...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Rename...",
    "desc": "Lệnh trong menu Application > Clip > Rename...",
    "cmd": "Rename..."
  },
  {
    "name": "Make Subclip...",
    "key": "Ctrl+U",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Make Subclip...",
    "desc": "Tạo subclip từ đoạn In/Out trong Source Monitor",
    "cmd": "Make Subclip..."
  },
  {
    "name": "Edit Subclip...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Edit Subclip...",
    "desc": "Lệnh trong menu Application > Clip > Edit Subclip...",
    "cmd": "Edit Subclip..."
  },
  {
    "name": "Edit Offline...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Edit Offline...",
    "desc": "Lệnh trong menu Application > Clip > Edit Offline...",
    "cmd": "Edit Offline..."
  },
  {
    "name": "Source Settings...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Source Settings...",
    "desc": "Lệnh trong menu Application > Clip > Source Settings...",
    "cmd": "Source Settings..."
  },
  {
    "name": "Audio Channels...",
    "key": "Shift+G",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Clip > Modify > Audio Channels...",
    "desc": "Chỉnh sửa kênh âm thanh (stereo, mono, 5.1)",
    "cmd": "Audio Channels..."
  },
  {
    "name": "Color...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Modify > Color...",
    "desc": "Lệnh trong menu Application > Clip > Modify > Color...",
    "cmd": "Color..."
  },
  {
    "name": "Interpret Footage...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Modify > Interpret Footage...",
    "desc": "Lệnh trong menu Application > Clip > Modify > Interpret Footage...",
    "cmd": "Interpret Footage..."
  },
  {
    "name": "Timecode...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Modify > Timecode...",
    "desc": "Lệnh trong menu Application > Clip > Modify > Timecode...",
    "cmd": "Timecode..."
  },
  {
    "name": "VR Properties...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Modify > VR Properties...",
    "desc": "Lệnh trong menu Application > Clip > Modify > VR Properties...",
    "cmd": "VR Properties..."
  },
  {
    "name": "Frame Hold Options...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Video Options > Frame Hold Options...",
    "desc": "Lệnh trong menu Application > Clip > Video Options > Frame Hold Options...",
    "cmd": "Frame Hold Options..."
  },
  {
    "name": "Add Frame Hold",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Video Options > Add Frame Hold",
    "desc": "Lệnh trong menu Application > Clip > Video Options > Add Frame Hold",
    "cmd": "Add Frame Hold"
  },
  {
    "name": "Insert Frame Hold Segment",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Video Options > Insert Frame Hold Segment",
    "desc": "Lệnh trong menu Application > Clip > Video Options > Insert Frame Hold Segment",
    "cmd": "Insert Frame Hold Segment"
  },
  {
    "name": "Field Options...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Video Options > Field Options...",
    "desc": "Lệnh trong menu Application > Clip > Video Options > Field Options...",
    "cmd": "Field Options..."
  },
  {
    "name": "Frame Sampling",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Clip > Video Options > Time Interpolation > Frame Sampling",
    "desc": "Lệnh trong menu Application > Clip > Video Options > Time Interpolation > Frame Sampling",
    "cmd": "Frame Sampling"
  },
  {
    "name": "Frame Blending",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Clip > Video Options > Time Interpolation > Frame Blending",
    "desc": "Lệnh trong menu Application > Clip > Video Options > Time Interpolation > Frame Blending",
    "cmd": "Frame Blending"
  },
  {
    "name": "Optical Flow",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Video Options > Time Interpolation > Optical Flow",
    "desc": "Lệnh trong menu Application > Clip > Video Options > Time Interpolation > Optical Flow",
    "cmd": "Optical Flow"
  },
  {
    "name": "Scale to Frame Size",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Clip > Video Options > Scale to Frame Size",
    "desc": "Đặt lại kích thước clip bằng kích thước sequence",
    "cmd": "Scale to Frame Size"
  },
  {
    "name": "Fit to frame",
    "key": "Shift+Z",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Video Options > Fit to frame",
    "desc": "Scale clip vừa khít khung hình sequence (giữ tỷ lệ, viền đen nếu khác tỷ lệ)",
    "cmd": "Fit to frame"
  },
  {
    "name": "Fill frame",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Video Options > Fill frame",
    "desc": "Lấp đầy khung hình sequence (tự crop phần thừa)",
    "cmd": "Fill frame"
  },
  {
    "name": "Audio Gain...",
    "key": "G",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Clip > Audio Options > Audio Gain...",
    "desc": "Chỉnh độ lợi âm lượng gốc của clip (Gain dB)",
    "cmd": "Audio Gain..."
  },
  {
    "name": "Breakout to Mono",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Audio Options > Breakout to Mono",
    "desc": "Lệnh trong menu Application > Clip > Audio Options > Breakout to Mono",
    "cmd": "Breakout to Mono"
  },
  {
    "name": "Extract Audio",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Clip > Audio Options > Extract Audio",
    "desc": "Lệnh trong menu Application > Clip > Audio Options > Extract Audio",
    "cmd": "Extract Audio"
  },
  {
    "name": "Speed/Duration...",
    "key": "Ctrl+R",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Speed/Duration...",
    "desc": "Đổi tốc độ %, đảo chiều và thuật toán nội suy thời gian của clip",
    "cmd": "Speed/Duration..."
  },
  {
    "name": "Scene Edit Detection...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Scene Edit Detection...",
    "desc": "AI tự động phát hiện và cắt các cảnh trong một video dài đã render",
    "cmd": "Scene Edit Detection..."
  },
  {
    "name": "Enable Enhance Speech",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Enable Enhance Speech",
    "desc": "Bật lọc âm AI Adobe Enhance Speech cho giọng nói trong trẻo",
    "cmd": "Enable Enhance Speech"
  },
  {
    "name": "Enable Remix",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Clip > Remix > Enable Remix",
    "desc": "Lệnh trong menu Application > Clip > Remix > Enable Remix",
    "cmd": "Enable Remix"
  },
  {
    "name": "Remix Properties",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Clip > Remix > Remix Properties",
    "desc": "Lệnh trong menu Application > Clip > Remix > Remix Properties",
    "cmd": "Remix Properties"
  },
  {
    "name": "Revert Remix",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Clip > Remix > Revert Remix",
    "desc": "Lệnh trong menu Application > Clip > Remix > Revert Remix",
    "cmd": "Revert Remix"
  },
  {
    "name": "Insert",
    "key": ",",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Insert",
    "desc": "Chèn clip từ Source Monitor vào timeline tại playhead (dồn clip sau)",
    "cmd": "Insert"
  },
  {
    "name": "Overwrite",
    "key": ".",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Overwrite",
    "desc": "Ghi đè clip từ Source Monitor vào timeline tại playhead",
    "cmd": "Overwrite"
  },
  {
    "name": "Replace Footage...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Replace Footage...",
    "desc": "Lệnh trong menu Application > Clip > Replace Footage...",
    "cmd": "Replace Footage..."
  },
  {
    "name": "From Source Monitor",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Replace With Clip > From Source Monitor",
    "desc": "Lệnh trong menu Application > Clip > Replace With Clip > From Source Monitor",
    "cmd": "From Source Monitor"
  },
  {
    "name": "From Source Monitor, Match Frame",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Clip > Replace With Clip > From Source Monitor, Match Frame",
    "desc": "Lệnh trong menu Application > Clip > Replace With Clip > From Source Monitor, Match Frame",
    "cmd": "From Source Monitor, Match Frame"
  },
  {
    "name": "From Bin",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Replace With Clip > From Bin",
    "desc": "Lệnh trong menu Application > Clip > Replace With Clip > From Bin",
    "cmd": "From Bin"
  },
  {
    "name": "Render and Replace...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Render and Replace...",
    "desc": "Lệnh trong menu Application > Clip > Render and Replace...",
    "cmd": "Render and Replace..."
  },
  {
    "name": "Restore Unrendered",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Restore Unrendered",
    "desc": "Lệnh trong menu Application > Clip > Restore Unrendered",
    "cmd": "Restore Unrendered"
  },
  {
    "name": "Restore Captions from Source Clip",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Application > Clip > Restore Captions from Source Clip",
    "desc": "Lệnh trong menu Application > Clip > Restore Captions from Source Clip",
    "cmd": "Restore Captions from Source Clip"
  },
  {
    "name": "Generate Audio Waveform",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Clip > Generate Audio Waveform",
    "desc": "Lệnh trong menu Application > Clip > Generate Audio Waveform",
    "cmd": "Generate Audio Waveform"
  },
  {
    "name": "Auto-Tag Audio Types",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Clip > Auto-Tag Audio Types",
    "desc": "Lệnh trong menu Application > Clip > Auto-Tag Audio Types",
    "cmd": "Auto-Tag Audio Types"
  },
  {
    "name": "Automate to Sequence...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Automate to Sequence...",
    "desc": "Lệnh trong menu Application > Clip > Automate to Sequence...",
    "cmd": "Automate to Sequence..."
  },
  {
    "name": "Enable",
    "key": "Shift+E",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Enable",
    "desc": "Bật/tắt kích hoạt clip trên timeline",
    "cmd": "Enable"
  },
  {
    "name": "Link",
    "key": "Ctrl+L",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Link",
    "desc": "Liên kết hoặc hủy liên kết hình và tiếng của clip",
    "cmd": "Link"
  },
  {
    "name": "Group",
    "key": "Ctrl+G",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Group",
    "desc": "Nhóm các clip lại với nhau",
    "cmd": "Group"
  },
  {
    "name": "Ungroup",
    "key": "Ctrl+Shift+G",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Ungroup",
    "desc": "Rã nhóm các clip",
    "cmd": "Ungroup"
  },
  {
    "name": "Synchronize...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Synchronize...",
    "desc": "Lệnh trong menu Application > Clip > Synchronize...",
    "cmd": "Synchronize..."
  },
  {
    "name": "Merge Clips...",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Merge Clips...",
    "desc": "Lệnh trong menu Application > Clip > Merge Clips...",
    "cmd": "Merge Clips..."
  },
  {
    "name": "Nest...",
    "key": "Shift+X",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Nest...",
    "desc": "Gom các clip đã chọn thành một sequence lồng (Nest sequence)",
    "cmd": "Nest..."
  },
  {
    "name": "Create Multi-Camera Source Sequence...",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Clip > Create Multi-Camera Source Sequence...",
    "desc": "Lệnh trong menu Application > Clip > Create Multi-Camera Source Sequence...",
    "cmd": "Create Multi-Camera Source Sequence..."
  },
  {
    "name": "Enable",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Multi-Camera > Enable",
    "desc": "Bật/tắt kích hoạt clip trên timeline",
    "cmd": "Enable"
  },
  {
    "name": "Flatten",
    "key": "",
    "cat": "clip",
    "catName": "Menu Clip",
    "path": "Application > Clip > Multi-Camera > Flatten",
    "desc": "Lệnh trong menu Application > Clip > Multi-Camera > Flatten",
    "cmd": "Flatten"
  },
  {
    "name": "Sequence Settings...",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Sequence Settings...",
    "desc": "Lệnh trong menu Application > Sequence > Sequence Settings...",
    "cmd": "Sequence Settings..."
  },
  {
    "name": "Render Effects in Work Area",
    "key": "Enter",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Sequence > Render Effects in Work Area",
    "desc": "Render xem trước các effect trong vùng làm việc",
    "cmd": "Render Effects in Work Area"
  },
  {
    "name": "Render Entire Work Area",
    "key": "Shift+Enter",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Sequence > Render Entire Work Area",
    "desc": "Render toàn bộ vùng làm việc",
    "cmd": "Render Entire Work Area"
  },
  {
    "name": "Render Selection",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Render Selection",
    "desc": "Lệnh trong menu Application > Sequence > Render Selection",
    "cmd": "Render Selection"
  },
  {
    "name": "Render Audio",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Sequence > Render Audio",
    "desc": "Lệnh trong menu Application > Sequence > Render Audio",
    "cmd": "Render Audio"
  },
  {
    "name": "Delete Render Files",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Delete Render Files",
    "desc": "Lệnh trong menu Application > Sequence > Delete Render Files",
    "cmd": "Delete Render Files"
  },
  {
    "name": "Delete Work Area Render Files",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Sequence > Delete Work Area Render Files",
    "desc": "Lệnh trong menu Application > Sequence > Delete Work Area Render Files",
    "cmd": "Delete Work Area Render Files"
  },
  {
    "name": "Match Frame",
    "key": "F",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Sequence > Match Frame",
    "desc": "Mở clip gốc đúng frame tại playhead vào Source Monitor",
    "cmd": "Match Frame"
  },
  {
    "name": "Reverse Match Frame",
    "key": "Shift+R",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Sequence > Reverse Match Frame",
    "desc": "Tìm vị trí frame trong Source Monitor xuất hiện trên timeline",
    "cmd": "Reverse Match Frame"
  },
  {
    "name": "Add Edit",
    "key": "Ctrl+K",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Sequence > Add Edit",
    "desc": "Cắt (razor) clip tại playhead trên track đang target",
    "cmd": "Add Edit"
  },
  {
    "name": "Add Edit to All Tracks",
    "key": "Ctrl+Shift+K",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Sequence > Add Edit to All Tracks",
    "desc": "Cắt đồng loạt clip tại playhead trên mọi track",
    "cmd": "Add Edit to All Tracks"
  },
  {
    "name": "Trim Edit",
    "key": "Shift+T",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Sequence > Trim Edit",
    "desc": "Mở chế độ Trim chỉnh điểm nối giữa hai clip",
    "cmd": "Trim Edit"
  },
  {
    "name": "Extend Selected Edit to Playhead",
    "key": "E",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Sequence > Extend Selected Edit to Playhead",
    "desc": "Kéo dài điểm nối đã chọn tới vị trí playhead hiện tại",
    "cmd": "Extend Selected Edit to Playhead"
  },
  {
    "name": "Apply Video Transition",
    "key": "Ctrl+D",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Apply Video Transition",
    "desc": "Áp hiệu ứng chuyển cảnh video mặc định (Cross Dissolve)",
    "cmd": "Apply Video Transition"
  },
  {
    "name": "Apply Audio Transition",
    "key": "Ctrl+Shift+D",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Sequence > Apply Audio Transition",
    "desc": "Áp hiệu ứng chuyển cảnh âm thanh mặc định (Constant Power)",
    "cmd": "Apply Audio Transition"
  },
  {
    "name": "Apply Default Transitions to Selection",
    "key": "Shift+D",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Apply Default Transitions to Selection",
    "desc": "Áp chuyển cảnh mặc định cho toàn bộ vùng chọn",
    "cmd": "Apply Default Transitions to Selection"
  },
  {
    "name": "Lift",
    "key": ";",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Lift",
    "desc": "Cắt đoạn giữa In/Out và để lại khoảng trống (Lift)",
    "cmd": "Lift"
  },
  {
    "name": "Extract",
    "key": "'",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Extract",
    "desc": "Cắt đoạn giữa In/Out và dồn khoảng trống lại (Extract)",
    "cmd": "Extract"
  },
  {
    "name": "Zoom In",
    "key": "=",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Zoom In",
    "desc": "Phóng to timeline hoặc monitor",
    "cmd": "Zoom In"
  },
  {
    "name": "Zoom Out",
    "key": "-",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Zoom Out",
    "desc": "Thu nhỏ timeline hoặc monitor",
    "cmd": "Zoom Out"
  },
  {
    "name": "Close Gap",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Sequence > Close Gap",
    "desc": "Đóng khoảng trống / tự động dồn các khoảng đen trên sequence",
    "cmd": "Close Gap"
  },
  {
    "name": "Next in Sequence",
    "key": "Shift+;",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Go to Gap > Next in Sequence",
    "desc": "Lệnh trong menu Application > Sequence > Go to Gap > Next in Sequence",
    "cmd": "Next in Sequence"
  },
  {
    "name": "Previous in Sequence",
    "key": "Ctrl+Shift+;",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Go to Gap > Previous in Sequence",
    "desc": "Lệnh trong menu Application > Sequence > Go to Gap > Previous in Sequence",
    "cmd": "Previous in Sequence"
  },
  {
    "name": "Next in Track",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Go to Gap > Next in Track",
    "desc": "Lệnh trong menu Application > Sequence > Go to Gap > Next in Track",
    "cmd": "Next in Track"
  },
  {
    "name": "Previous in Track",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Go to Gap > Previous in Track",
    "desc": "Lệnh trong menu Application > Sequence > Go to Gap > Previous in Track",
    "cmd": "Previous in Track"
  },
  {
    "name": "Snap in Timeline",
    "key": "S",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Snap in Timeline",
    "desc": "Bật/tắt chế độ hít nam châm (Snap) trên timeline",
    "cmd": "Snap in Timeline"
  },
  {
    "name": "Linked Selection",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Linked Selection",
    "desc": "Lệnh trong menu Application > Sequence > Linked Selection",
    "cmd": "Linked Selection"
  },
  {
    "name": "Selection Follows Playhead",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Sequence > Selection Follows Playhead",
    "desc": "Lệnh trong menu Application > Sequence > Selection Follows Playhead",
    "cmd": "Selection Follows Playhead"
  },
  {
    "name": "Show Through Edits",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Show Through Edits",
    "desc": "Lệnh trong menu Application > Sequence > Show Through Edits",
    "cmd": "Show Through Edits"
  },
  {
    "name": "Normalize Mix Track...",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Normalize Mix Track...",
    "desc": "Lệnh trong menu Application > Sequence > Normalize Mix Track...",
    "cmd": "Normalize Mix Track..."
  },
  {
    "name": "Make Subsequence",
    "key": "Shift+U",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Make Subsequence",
    "desc": "Tạo sequence con từ đoạn In/Out hoặc các clip đang chọn",
    "cmd": "Make Subsequence"
  },
  {
    "name": "Auto Reframe Sequence...",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Auto Reframe Sequence...",
    "desc": "AI tự động định khung lại sequence (chuyển 16:9 sang 9:16 dọc)",
    "cmd": "Auto Reframe Sequence..."
  },
  {
    "name": "Transcribe Sequence...",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Transcribe Sequence...",
    "desc": "Lệnh trong menu Application > Sequence > Transcribe Sequence...",
    "cmd": "Transcribe Sequence..."
  },
  {
    "name": "Simplify Sequence...",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Simplify Sequence...",
    "desc": "Lệnh trong menu Application > Sequence > Simplify Sequence...",
    "cmd": "Simplify Sequence..."
  },
  {
    "name": "Add Tracks...",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Add Tracks...",
    "desc": "Lệnh trong menu Application > Sequence > Add Tracks...",
    "cmd": "Add Tracks..."
  },
  {
    "name": "Delete Tracks...",
    "key": "",
    "cat": "sequence",
    "catName": "Menu Sequence",
    "path": "Application > Sequence > Delete Tracks...",
    "desc": "Lệnh trong menu Application > Sequence > Delete Tracks...",
    "cmd": "Delete Tracks..."
  },
  {
    "name": "Mark In",
    "key": "I",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Mark In",
    "desc": "Đánh dấu điểm bắt đầu (In point)",
    "cmd": "Mark In"
  },
  {
    "name": "Mark Out",
    "key": "O",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Mark Out",
    "desc": "Đánh dấu điểm kết thúc (Out point)",
    "cmd": "Mark Out"
  },
  {
    "name": "Mark Clip",
    "key": "X",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Mark Clip",
    "desc": "Đánh dấu In/Out khớp đúng thời lượng clip đang chọn",
    "cmd": "Mark Clip"
  },
  {
    "name": "Mark Selection",
    "key": "/",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Mark Selection",
    "desc": "Đánh dấu In/Out khớp toàn bộ vùng chọn",
    "cmd": "Mark Selection"
  },
  {
    "name": "Video In",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Mark Split > Video In",
    "desc": "Lệnh trong menu Application > Markers > Mark Split > Video In",
    "cmd": "Video In"
  },
  {
    "name": "Video Out",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Mark Split > Video Out",
    "desc": "Lệnh trong menu Application > Markers > Mark Split > Video Out",
    "cmd": "Video Out"
  },
  {
    "name": "Audio In",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Markers > Mark Split > Audio In",
    "desc": "Lệnh trong menu Application > Markers > Mark Split > Audio In",
    "cmd": "Audio In"
  },
  {
    "name": "Audio Out",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Markers > Mark Split > Audio Out",
    "desc": "Lệnh trong menu Application > Markers > Mark Split > Audio Out",
    "cmd": "Audio Out"
  },
  {
    "name": "Go to In",
    "key": "Shift+I",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Go to In",
    "desc": "Lệnh trong menu Application > Markers > Go to In",
    "cmd": "Go to In"
  },
  {
    "name": "Go to Out",
    "key": "Shift+O",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Go to Out",
    "desc": "Lệnh trong menu Application > Markers > Go to Out",
    "cmd": "Go to Out"
  },
  {
    "name": "Video In",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Go to Split > Video In",
    "desc": "Lệnh trong menu Application > Markers > Go to Split > Video In",
    "cmd": "Video In"
  },
  {
    "name": "Video Out",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Go to Split > Video Out",
    "desc": "Lệnh trong menu Application > Markers > Go to Split > Video Out",
    "cmd": "Video Out"
  },
  {
    "name": "Audio In",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Markers > Go to Split > Audio In",
    "desc": "Lệnh trong menu Application > Markers > Go to Split > Audio In",
    "cmd": "Audio In"
  },
  {
    "name": "Audio Out",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Markers > Go to Split > Audio Out",
    "desc": "Lệnh trong menu Application > Markers > Go to Split > Audio Out",
    "cmd": "Audio Out"
  },
  {
    "name": "Clear In",
    "key": "Ctrl+Shift+I",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Clear In",
    "desc": "Xóa điểm In",
    "cmd": "Clear In"
  },
  {
    "name": "Clear Out",
    "key": "Ctrl+Shift+O",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Clear Out",
    "desc": "Xóa điểm Out",
    "cmd": "Clear Out"
  },
  {
    "name": "Clear In and Out",
    "key": "Ctrl+Shift+X",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Markers > Clear In and Out",
    "desc": "Xóa cả điểm In và Out",
    "cmd": "Clear In and Out"
  },
  {
    "name": "Add Marker",
    "key": "M",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Add Marker",
    "desc": "Thêm marker đánh dấu tại playhead",
    "cmd": "Add Marker"
  },
  {
    "name": "Add Range Marker",
    "key": "Ctrl+Alt+Shift+N",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Add Range Marker",
    "desc": "Thêm marker có dải thời lượng",
    "cmd": "Add Range Marker"
  },
  {
    "name": "Add Range Marker to In and Out",
    "key": "Alt+Shift+N",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Add Range Marker to In and Out",
    "desc": "Lệnh trong menu Application > Markers > Add Range Marker to In and Out",
    "cmd": "Add Range Marker to In and Out"
  },
  {
    "name": "Go to Next Marker",
    "key": "Shift+M",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Go to Next Marker",
    "desc": "Nhảy tới marker tiếp theo",
    "cmd": "Go to Next Marker"
  },
  {
    "name": "Go to Previous Marker",
    "key": "Ctrl+Shift+M",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Go to Previous Marker",
    "desc": "Nhảy về marker phía trước",
    "cmd": "Go to Previous Marker"
  },
  {
    "name": "Clear Selected Marker",
    "key": "Ctrl+Alt+M",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Clear Selected Marker",
    "desc": "Xóa marker đang chọn",
    "cmd": "Clear Selected Marker"
  },
  {
    "name": "Clear Markers",
    "key": "Ctrl+Alt+Shift+M",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Clear Markers",
    "desc": "Xóa toàn bộ marker",
    "cmd": "Clear Markers"
  },
  {
    "name": "Show All Marker Colors",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Show All Marker Colors",
    "desc": "Lệnh trong menu Application > Markers > Show All Marker Colors",
    "cmd": "Show All Marker Colors"
  },
  {
    "name": "Edit Marker...",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Edit Marker...",
    "desc": "Lệnh trong menu Application > Markers > Edit Marker...",
    "cmd": "Edit Marker..."
  },
  {
    "name": "Add Chapter Marker...",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Add Chapter Marker...",
    "desc": "Lệnh trong menu Application > Markers > Add Chapter Marker...",
    "cmd": "Add Chapter Marker..."
  },
  {
    "name": "Add Flash Cue Marker...",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Add Flash Cue Marker...",
    "desc": "Lệnh trong menu Application > Markers > Add Flash Cue Marker...",
    "cmd": "Add Flash Cue Marker..."
  },
  {
    "name": "Ripple Sequence Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Ripple Sequence Markers",
    "desc": "Lệnh trong menu Application > Markers > Ripple Sequence Markers",
    "cmd": "Ripple Sequence Markers"
  },
  {
    "name": "Copy Paste Includes Sequence Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Markers > Copy Paste Includes Sequence Markers",
    "desc": "Lệnh trong menu Application > Markers > Copy Paste Includes Sequence Markers",
    "cmd": "Copy Paste Includes Sequence Markers"
  },
  {
    "name": "Add Fonts from Adobe Fonts...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Add Fonts from Adobe Fonts...",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Add Fonts from Adobe Fonts...",
    "cmd": "Add Fonts from Adobe Fonts..."
  },
  {
    "name": "Install Motion Graphics Template...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Install Motion Graphics Template...",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Install Motion Graphics Template...",
    "cmd": "Install Motion Graphics Template..."
  },
  {
    "name": "Text",
    "key": "Ctrl+T",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > New Layer > Text",
    "desc": "Tạo layer chữ mới",
    "cmd": "Text"
  },
  {
    "name": "Vertical Text",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > New Layer > Vertical Text",
    "desc": "Lệnh trong menu Application > Graphics and Titles > New Layer > Vertical Text",
    "cmd": "Vertical Text"
  },
  {
    "name": "Rectangle",
    "key": "Ctrl+Alt+R",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > New Layer > Rectangle",
    "desc": "Tạo layer hình chữ nhật mới",
    "cmd": "Rectangle"
  },
  {
    "name": "Ellipse",
    "key": "Ctrl+Alt+E",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > New Layer > Ellipse",
    "desc": "Tạo layer hình elip mới",
    "cmd": "Ellipse"
  },
  {
    "name": "Polygon",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > New Layer > Polygon",
    "desc": "Lệnh trong menu Application > Graphics and Titles > New Layer > Polygon",
    "cmd": "Polygon"
  },
  {
    "name": "From file...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > New Layer > From file...",
    "desc": "Lệnh trong menu Application > Graphics and Titles > New Layer > From file...",
    "cmd": "From file..."
  },
  {
    "name": "Left",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame > Left",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame > Left",
    "cmd": "Left"
  },
  {
    "name": "Center Horizontally",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame > Center Horizontally",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame > Center Horizontally",
    "cmd": "Center Horizontally"
  },
  {
    "name": "Right",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame > Right",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame > Right",
    "cmd": "Right"
  },
  {
    "name": "Top",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame > Top",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame > Top",
    "cmd": "Top"
  },
  {
    "name": "Center Vertically",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame > Center Vertically",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame > Center Vertically",
    "cmd": "Center Vertically"
  },
  {
    "name": "Bottom",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame > Bottom",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame > Bottom",
    "cmd": "Bottom"
  },
  {
    "name": "Left",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame as Group > Left",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame as Group > Left",
    "cmd": "Left"
  },
  {
    "name": "Center Horizontally",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame as Group > Center Horizontally",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame as Group > Center Horizontally",
    "cmd": "Center Horizontally"
  },
  {
    "name": "Right",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame as Group > Right",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame as Group > Right",
    "cmd": "Right"
  },
  {
    "name": "Top",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame as Group > Top",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame as Group > Top",
    "cmd": "Top"
  },
  {
    "name": "Center Vertically",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame as Group > Center Vertically",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame as Group > Center Vertically",
    "cmd": "Center Vertically"
  },
  {
    "name": "Bottom",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Video Frame as Group > Bottom",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Video Frame as Group > Bottom",
    "cmd": "Bottom"
  },
  {
    "name": "Left",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Selection > Left",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Selection > Left",
    "cmd": "Left"
  },
  {
    "name": "Center Horizontally",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Selection > Center Horizontally",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Selection > Center Horizontally",
    "cmd": "Center Horizontally"
  },
  {
    "name": "Right",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Selection > Right",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Selection > Right",
    "cmd": "Right"
  },
  {
    "name": "Top",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Selection > Top",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Selection > Top",
    "cmd": "Top"
  },
  {
    "name": "Center Vertically",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Selection > Center Vertically",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Selection > Center Vertically",
    "cmd": "Center Vertically"
  },
  {
    "name": "Bottom",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Align to Selection > Bottom",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Align to Selection > Bottom",
    "cmd": "Bottom"
  },
  {
    "name": "Distribute Vertically",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Distribute > Distribute Vertically",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Distribute > Distribute Vertically",
    "cmd": "Distribute Vertically"
  },
  {
    "name": "Distribute Space Vertically",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Distribute > Distribute Space Vertically",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Distribute > Distribute Space Vertically",
    "cmd": "Distribute Space Vertically"
  },
  {
    "name": "Distribute Horizontally",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Distribute > Distribute Horizontally",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Distribute > Distribute Horizontally",
    "cmd": "Distribute Horizontally"
  },
  {
    "name": "Distribute Space Horizontally",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Distribute > Distribute Space Horizontally",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Distribute > Distribute Space Horizontally",
    "cmd": "Distribute Space Horizontally"
  },
  {
    "name": "Bring to Front",
    "key": "Ctrl+Shift+]",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Arrange > Bring to Front",
    "desc": "Đưa layer đồ họa lên lớp trên cùng",
    "cmd": "Bring to Front"
  },
  {
    "name": "Bring Forward",
    "key": "Ctrl+]",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Arrange > Bring Forward",
    "desc": "Đưa layer đồ họa lên trên một lớp",
    "cmd": "Bring Forward"
  },
  {
    "name": "Send Backward",
    "key": "Ctrl+[",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Arrange > Send Backward",
    "desc": "Đưa layer đồ họa xuống dưới một lớp",
    "cmd": "Send Backward"
  },
  {
    "name": "Send to Back",
    "key": "Ctrl+Shift+[",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Arrange > Send to Back",
    "desc": "Đưa layer đồ họa xuống dưới cùng",
    "cmd": "Send to Back"
  },
  {
    "name": "Select Next Graphic",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Select > Select Next Graphic",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Select > Select Next Graphic",
    "cmd": "Select Next Graphic"
  },
  {
    "name": "Select Previous Graphic",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Select > Select Previous Graphic",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Select > Select Previous Graphic",
    "cmd": "Select Previous Graphic"
  },
  {
    "name": "Select Next Layer",
    "key": "Ctrl+Alt+]",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Select > Select Next Layer",
    "desc": "Chọn layer đồ họa tiếp theo",
    "cmd": "Select Next Layer"
  },
  {
    "name": "Select Previous Layer",
    "key": "Ctrl+Alt+[",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Select > Select Previous Layer",
    "desc": "Chọn layer đồ họa phía trước",
    "cmd": "Select Previous Layer"
  },
  {
    "name": "Upgrade to Source Graphic",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Upgrade to Source Graphic",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Upgrade to Source Graphic",
    "cmd": "Upgrade to Source Graphic"
  },
  {
    "name": "Upgrade Caption to Graphic",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Application > Graphics and Titles > Upgrade Caption to Graphic",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Upgrade Caption to Graphic",
    "cmd": "Upgrade Caption to Graphic"
  },
  {
    "name": "Reset All Parameters",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Reset All Parameters",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Reset All Parameters",
    "cmd": "Reset All Parameters"
  },
  {
    "name": "Reset Duration",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Reset Duration",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Reset Duration",
    "cmd": "Reset Duration"
  },
  {
    "name": "Export As Motion Graphics Template...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Export As Motion Graphics Template...",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Export As Motion Graphics Template...",
    "cmd": "Export As Motion Graphics Template..."
  },
  {
    "name": "Replace Fonts in Projects...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Graphics and Titles > Replace Fonts in Projects...",
    "desc": "Lệnh trong menu Application > Graphics and Titles > Replace Fonts in Projects...",
    "cmd": "Replace Fonts in Projects..."
  },
  {
    "name": "Full",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Playback Resolution > Full",
    "desc": "Lệnh trong menu Application > View > Playback Resolution > Full",
    "cmd": "Full"
  },
  {
    "name": "1/2",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Playback Resolution > 1/2",
    "desc": "Lệnh trong menu Application > View > Playback Resolution > 1/2",
    "cmd": "1/2"
  },
  {
    "name": "1/4",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Playback Resolution > 1/4",
    "desc": "Lệnh trong menu Application > View > Playback Resolution > 1/4",
    "cmd": "1/4"
  },
  {
    "name": "1/8",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Playback Resolution > 1/8",
    "desc": "Lệnh trong menu Application > View > Playback Resolution > 1/8",
    "cmd": "1/8"
  },
  {
    "name": "1/16",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Playback Resolution > 1/16",
    "desc": "Lệnh trong menu Application > View > Playback Resolution > 1/16",
    "cmd": "1/16"
  },
  {
    "name": "Full",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Paused Resolution > Full",
    "desc": "Lệnh trong menu Application > View > Paused Resolution > Full",
    "cmd": "Full"
  },
  {
    "name": "1/2",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Paused Resolution > 1/2",
    "desc": "Lệnh trong menu Application > View > Paused Resolution > 1/2",
    "cmd": "1/2"
  },
  {
    "name": "1/4",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Paused Resolution > 1/4",
    "desc": "Lệnh trong menu Application > View > Paused Resolution > 1/4",
    "cmd": "1/4"
  },
  {
    "name": "1/8",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Paused Resolution > 1/8",
    "desc": "Lệnh trong menu Application > View > Paused Resolution > 1/8",
    "cmd": "1/8"
  },
  {
    "name": "1/16",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Paused Resolution > 1/16",
    "desc": "Lệnh trong menu Application > View > Paused Resolution > 1/16",
    "cmd": "1/16"
  },
  {
    "name": "High Quality Playback",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > View > High Quality Playback",
    "desc": "Lệnh trong menu Application > View > High Quality Playback",
    "cmd": "High Quality Playback"
  },
  {
    "name": "Composite Video",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Display Mode > Composite Video",
    "desc": "Lệnh trong menu Application > View > Display Mode > Composite Video",
    "cmd": "Composite Video"
  },
  {
    "name": "Alpha",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Display Mode > Alpha",
    "desc": "Lệnh trong menu Application > View > Display Mode > Alpha",
    "cmd": "Alpha"
  },
  {
    "name": "Red",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Display Mode > Red",
    "desc": "Lệnh trong menu Application > View > Display Mode > Red",
    "cmd": "Red"
  },
  {
    "name": "Green",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Display Mode > Green",
    "desc": "Lệnh trong menu Application > View > Display Mode > Green",
    "cmd": "Green"
  },
  {
    "name": "Blue",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Display Mode > Blue",
    "desc": "Lệnh trong menu Application > View > Display Mode > Blue",
    "cmd": "Blue"
  },
  {
    "name": "Multi-Camera",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > View > Display Mode > Multi-Camera",
    "desc": "Lệnh trong menu Application > View > Display Mode > Multi-Camera",
    "cmd": "Multi-Camera"
  },
  {
    "name": "Audio Waveform",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > View > Display Mode > Audio Waveform",
    "desc": "Lệnh trong menu Application > View > Display Mode > Audio Waveform",
    "cmd": "Audio Waveform"
  },
  {
    "name": "Comparison View",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Display Mode > Comparison View",
    "desc": "Lệnh trong menu Application > View > Display Mode > Comparison View",
    "cmd": "Comparison View"
  },
  {
    "name": "Fit",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > Fit",
    "desc": "Lệnh trong menu Application > View > Magnification > Fit",
    "cmd": "Fit"
  },
  {
    "name": "10%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 10%",
    "desc": "Lệnh trong menu Application > View > Magnification > 10%",
    "cmd": "10%"
  },
  {
    "name": "25%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 25%",
    "desc": "Lệnh trong menu Application > View > Magnification > 25%",
    "cmd": "25%"
  },
  {
    "name": "50%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 50%",
    "desc": "Lệnh trong menu Application > View > Magnification > 50%",
    "cmd": "50%"
  },
  {
    "name": "75%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 75%",
    "desc": "Lệnh trong menu Application > View > Magnification > 75%",
    "cmd": "75%"
  },
  {
    "name": "100%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 100%",
    "desc": "Lệnh trong menu Application > View > Magnification > 100%",
    "cmd": "100%"
  },
  {
    "name": "150%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 150%",
    "desc": "Lệnh trong menu Application > View > Magnification > 150%",
    "cmd": "150%"
  },
  {
    "name": "200%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 200%",
    "desc": "Lệnh trong menu Application > View > Magnification > 200%",
    "cmd": "200%"
  },
  {
    "name": "400%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 400%",
    "desc": "Lệnh trong menu Application > View > Magnification > 400%",
    "cmd": "400%"
  },
  {
    "name": "800%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 800%",
    "desc": "Lệnh trong menu Application > View > Magnification > 800%",
    "cmd": "800%"
  },
  {
    "name": "1600%",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Magnification > 1600%",
    "desc": "Lệnh trong menu Application > View > Magnification > 1600%",
    "cmd": "1600%"
  },
  {
    "name": "Show Rulers",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Show Rulers",
    "desc": "Hiện/ẩn thước kẻ căn chỉnh (Rulers)",
    "cmd": "Show Rulers"
  },
  {
    "name": "Show Guides",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Show Guides",
    "desc": "Hiện/ẩn đường gióng căn chỉnh (Guides)",
    "cmd": "Show Guides"
  },
  {
    "name": "Lock Guides",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Lock Guides",
    "desc": "Khóa cố định các đường gióng",
    "cmd": "Lock Guides"
  },
  {
    "name": "Add Guide...",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Add Guide...",
    "desc": "Lệnh trong menu Application > View > Add Guide...",
    "cmd": "Add Guide..."
  },
  {
    "name": "Clear Guides",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Clear Guides",
    "desc": "Lệnh trong menu Application > View > Clear Guides",
    "cmd": "Clear Guides"
  },
  {
    "name": "Snap in Program Monitor",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Snap in Program Monitor",
    "desc": "Bật chế độ hít nam châm căn chỉnh trên Program Monitor",
    "cmd": "Snap in Program Monitor"
  },
  {
    "name": "Save Guides as Template...",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Guide Templates > Save Guides as Template...",
    "desc": "Lệnh trong menu Application > View > Guide Templates > Save Guides as Template...",
    "cmd": "Save Guides as Template..."
  },
  {
    "name": "Manage Guides...",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > View > Guide Templates > Manage Guides...",
    "desc": "Lệnh trong menu Application > View > Guide Templates > Manage Guides...",
    "cmd": "Manage Guides..."
  },
  {
    "name": "Dynamic Audio Waveforms",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > View > Dynamic Audio Waveforms",
    "desc": "Lệnh trong menu Application > View > Dynamic Audio Waveforms",
    "cmd": "Dynamic Audio Waveforms"
  },
  {
    "name": "Reset to Saved Layout",
    "key": "Alt+Shift+0",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Workspaces > Reset to Saved Layout",
    "desc": "Khôi phục giao diện làm việc về mặc định đã lưu",
    "cmd": "Reset to Saved Layout"
  },
  {
    "name": "Save Changes to this Workspace",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Window > Workspaces > Save Changes to this Workspace",
    "desc": "Lệnh trong menu Application > Window > Workspaces > Save Changes to this Workspace",
    "cmd": "Save Changes to this Workspace"
  },
  {
    "name": "Save as New Workspace...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Window > Workspaces > Save as New Workspace...",
    "desc": "Lệnh trong menu Application > Window > Workspaces > Save as New Workspace...",
    "cmd": "Save as New Workspace..."
  },
  {
    "name": "Edit Workspaces...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Window > Workspaces > Edit Workspaces...",
    "desc": "Lệnh trong menu Application > Window > Workspaces > Edit Workspaces...",
    "cmd": "Edit Workspaces..."
  },
  {
    "name": "Import Workspace from Projects",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Window > Workspaces > Import Workspace from Projects",
    "desc": "Lệnh trong menu Application > Window > Workspaces > Import Workspace from Projects",
    "cmd": "Import Workspace from Projects"
  },
  {
    "name": "Find Extensions on Exchange...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Find Extensions on Exchange...",
    "desc": "Lệnh trong menu Application > Window > Find Extensions on Exchange...",
    "cmd": "Find Extensions on Exchange..."
  },
  {
    "name": "Browse Plugins...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > UXP Plugins > Browse Plugins...",
    "desc": "Lệnh trong menu Application > Window > UXP Plugins > Browse Plugins...",
    "cmd": "Browse Plugins..."
  },
  {
    "name": "Manage Plugins...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > UXP Plugins > Manage Plugins...",
    "desc": "Lệnh trong menu Application > Window > UXP Plugins > Manage Plugins...",
    "cmd": "Manage Plugins..."
  },
  {
    "name": "Adobe Stock",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Adobe Stock",
    "desc": "Lệnh trong menu Application > Window > Adobe Stock",
    "cmd": "Adobe Stock"
  },
  {
    "name": "Audio Clip Mixer",
    "key": "Shift+9",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Window > Audio Clip Mixer",
    "desc": "Mở bảng trộn âm lượng theo từng clip",
    "cmd": "Audio Clip Mixer"
  },
  {
    "name": "Audio Meters",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Window > Audio Meters",
    "desc": "Lệnh trong menu Application > Window > Audio Meters",
    "cmd": "Audio Meters"
  },
  {
    "name": "Audio Track Mixer",
    "key": "Shift+6",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Window > Audio Track Mixer",
    "desc": "Mở bảng trộn âm lượng theo từng track âm thanh",
    "cmd": "Audio Track Mixer"
  },
  {
    "name": "Effect Controls",
    "key": "Shift+5",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Effect Controls",
    "desc": "Mở bảng điều khiển hiệu ứng & keyframe của clip",
    "cmd": "Effect Controls"
  },
  {
    "name": "Effects",
    "key": "Shift+7",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Effects",
    "desc": "Mở bảng danh sách Effect & Transition",
    "cmd": "Effects"
  },
  {
    "name": "Essential Sound",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Essential Sound",
    "desc": "Lệnh trong menu Application > Window > Essential Sound",
    "cmd": "Essential Sound"
  },
  {
    "name": "Events",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Events",
    "desc": "Lệnh trong menu Application > Window > Events",
    "cmd": "Events"
  },
  {
    "name": "Frame.io V4",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Window > Frame.io > Frame.io V4",
    "desc": "Lệnh trong menu Application > Window > Frame.io > Frame.io V4",
    "cmd": "Frame.io V4"
  },
  {
    "name": "Frame.io (Legacy)",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Window > Frame.io > Frame.io (Legacy)",
    "desc": "Lệnh trong menu Application > Window > Frame.io > Frame.io (Legacy)",
    "cmd": "Frame.io (Legacy)"
  },
  {
    "name": "Graphics Templates",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Window > Graphics Templates",
    "desc": "Lệnh trong menu Application > Window > Graphics Templates",
    "cmd": "Graphics Templates"
  },
  {
    "name": "History",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > History",
    "desc": "Lệnh trong menu Application > Window > History",
    "cmd": "History"
  },
  {
    "name": "Info",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Info",
    "desc": "Lệnh trong menu Application > Window > Info",
    "cmd": "Info"
  },
  {
    "name": "Learn",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Learn",
    "desc": "Lệnh trong menu Application > Window > Learn",
    "cmd": "Learn"
  },
  {
    "name": "Libraries",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Libraries",
    "desc": "Lệnh trong menu Application > Window > Libraries",
    "cmd": "Libraries"
  },
  {
    "name": "Lumetri Color",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Lumetri Color",
    "desc": "Lệnh trong menu Application > Window > Lumetri Color",
    "cmd": "Lumetri Color"
  },
  {
    "name": "Lumetri Scopes",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Lumetri Scopes",
    "desc": "Lệnh trong menu Application > Window > Lumetri Scopes",
    "cmd": "Lumetri Scopes"
  },
  {
    "name": "Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Window > Markers",
    "desc": "Lệnh trong menu Application > Window > Markers",
    "cmd": "Markers"
  },
  {
    "name": "Media Browser",
    "key": "Shift+8",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Media Browser",
    "desc": "Mở bảng duyệt file media trên máy tính",
    "cmd": "Media Browser"
  },
  {
    "name": "Metadata",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Metadata",
    "desc": "Lệnh trong menu Application > Window > Metadata",
    "cmd": "Metadata"
  },
  {
    "name": "Production",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Production",
    "desc": "Lệnh trong menu Application > Window > Production",
    "cmd": "Production"
  },
  {
    "name": "Program Monitor",
    "key": "Shift+4",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Window > Program Monitor",
    "desc": "Mở bảng xem video sequence chính",
    "cmd": "Program Monitor"
  },
  {
    "name": "Progress",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Progress",
    "desc": "Lệnh trong menu Application > Window > Progress",
    "cmd": "Progress"
  },
  {
    "name": "Projects",
    "key": "Shift+1",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Projects",
    "desc": "Mở bảng quản lý file dự án (Project Panel)",
    "cmd": "Projects"
  },
  {
    "name": "Properties",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Properties",
    "desc": "Lệnh trong menu Application > Window > Properties",
    "cmd": "Properties"
  },
  {
    "name": "Search",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Search",
    "desc": "Lệnh trong menu Application > Window > Search",
    "cmd": "Search"
  },
  {
    "name": "Sequence Index",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Sequence Index",
    "desc": "Lệnh trong menu Application > Window > Sequence Index",
    "cmd": "Sequence Index"
  },
  {
    "name": "Source Monitor",
    "key": "Shift+2",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Window > Source Monitor",
    "desc": "Mở bảng xem trước clip nguồn",
    "cmd": "Source Monitor"
  },
  {
    "name": "Text",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Window > Text",
    "desc": "Tạo layer chữ mới",
    "cmd": "Text"
  },
  {
    "name": "Timecode",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Timecode",
    "desc": "Lệnh trong menu Application > Window > Timecode",
    "cmd": "Timecode"
  },
  {
    "name": "Timelines",
    "key": "Shift+3",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Window > Timelines",
    "desc": "Mở bảng dòng thời gian Timeline",
    "cmd": "Timelines"
  },
  {
    "name": "Tools",
    "key": "",
    "cat": "tools",
    "catName": "Công cụ (Toolbox)",
    "path": "Application > Window > Tools",
    "desc": "Lệnh trong menu Application > Window > Tools",
    "cmd": "Tools"
  },
  {
    "name": "Premiere Help...",
    "key": "F1",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Help > Premiere Help...",
    "desc": "Lệnh trong menu Application > Help > Premiere Help...",
    "cmd": "Premiere Help..."
  },
  {
    "name": "Premiere In-App Tutorials...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Help > Premiere In-App Tutorials...",
    "desc": "Lệnh trong menu Application > Help > Premiere In-App Tutorials...",
    "cmd": "Premiere In-App Tutorials..."
  },
  {
    "name": "Premiere Online Tutorials...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Help > Premiere Online Tutorials...",
    "desc": "Lệnh trong menu Application > Help > Premiere Online Tutorials...",
    "cmd": "Premiere Online Tutorials..."
  },
  {
    "name": "Reveal Log Files...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Help > Reveal Log Files...",
    "desc": "Lệnh trong menu Application > Help > Reveal Log Files...",
    "cmd": "Reveal Log Files..."
  },
  {
    "name": "Provide Feedback...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Help > Provide Feedback...",
    "desc": "Lệnh trong menu Application > Help > Provide Feedback...",
    "cmd": "Provide Feedback..."
  },
  {
    "name": "System Compatibility Report...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Help > System Compatibility Report...",
    "desc": "Lệnh trong menu Application > Help > System Compatibility Report...",
    "cmd": "System Compatibility Report..."
  },
  {
    "name": "Keyboard...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Help > Keyboard...",
    "desc": "Lệnh trong menu Application > Help > Keyboard...",
    "cmd": "Keyboard..."
  },
  {
    "name": "About Premiere...",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Help > About Premiere...",
    "desc": "Lệnh trong menu Application > Help > About Premiere...",
    "cmd": "About Premiere..."
  },
  {
    "name": "Add 5.1 Audio Track",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Add 5.1 Audio Track",
    "desc": "Lệnh trong menu Application > Add 5.1 Audio Track",
    "cmd": "Add 5.1 Audio Track"
  },
  {
    "name": "Add Blue Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Add Blue Marker",
    "desc": "Lệnh trong menu Application > Add Blue Marker",
    "cmd": "Add Blue Marker"
  },
  {
    "name": "Add Captions Track...",
    "key": "Ctrl+Alt+A",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Application > Add Captions Track...",
    "desc": "Thêm track phụ đề mới vào sequence",
    "cmd": "Add Captions Track..."
  },
  {
    "name": "Add Cyan Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Add Cyan Marker",
    "desc": "Lệnh trong menu Application > Add Cyan Marker",
    "cmd": "Add Cyan Marker"
  },
  {
    "name": "Add Green Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Add Green Marker",
    "desc": "Lệnh trong menu Application > Add Green Marker",
    "cmd": "Add Green Marker"
  },
  {
    "name": "Add Magenta Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Add Magenta Marker",
    "desc": "Lệnh trong menu Application > Add Magenta Marker",
    "cmd": "Add Magenta Marker"
  },
  {
    "name": "Add Mono Audio Track",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Add Mono Audio Track",
    "desc": "Lệnh trong menu Application > Add Mono Audio Track",
    "cmd": "Add Mono Audio Track"
  },
  {
    "name": "Add Orange Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Add Orange Marker",
    "desc": "Lệnh trong menu Application > Add Orange Marker",
    "cmd": "Add Orange Marker"
  },
  {
    "name": "Add Red Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Add Red Marker",
    "desc": "Lệnh trong menu Application > Add Red Marker",
    "cmd": "Add Red Marker"
  },
  {
    "name": "Add Stereo Audio Track",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Add Stereo Audio Track",
    "desc": "Lệnh trong menu Application > Add Stereo Audio Track",
    "cmd": "Add Stereo Audio Track"
  },
  {
    "name": "Add Tracks to Match Source",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Add Tracks to Match Source",
    "desc": "Lệnh trong menu Application > Add Tracks to Match Source",
    "cmd": "Add Tracks to Match Source"
  },
  {
    "name": "Add Video Track",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Add Video Track",
    "desc": "Lệnh trong menu Application > Add Video Track",
    "cmd": "Add Video Track"
  },
  {
    "name": "Add White Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Add White Marker",
    "desc": "Lệnh trong menu Application > Add White Marker",
    "cmd": "Add White Marker"
  },
  {
    "name": "Add Yellow Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Add Yellow Marker",
    "desc": "Lệnh trong menu Application > Add Yellow Marker",
    "cmd": "Add Yellow Marker"
  },
  {
    "name": "Add new caption segment at playhead",
    "key": "Ctrl+Alt+C",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Add new caption segment at playhead",
    "desc": "Tạo một block phụ đề mới ngay tại vị trí playhead",
    "cmd": "Add new caption segment at playhead"
  },
  {
    "name": "Add or Remove Audio Keyframe",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Add or Remove Audio Keyframe",
    "desc": "Lệnh trong menu Application > Add or Remove Audio Keyframe",
    "cmd": "Add or Remove Audio Keyframe"
  },
  {
    "name": "Add or Remove Video Keyframe",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Add or Remove Video Keyframe",
    "desc": "Lệnh trong menu Application > Add or Remove Video Keyframe",
    "cmd": "Add or Remove Video Keyframe"
  },
  {
    "name": "Add to object",
    "key": "Ctrl+=",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Add to object",
    "desc": "Lệnh trong menu Application > Add to object",
    "cmd": "Add to object"
  },
  {
    "name": "All Caps",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > All Caps",
    "desc": "Lệnh trong menu Application > All Caps",
    "cmd": "All Caps"
  },
  {
    "name": "Begin Text Editing for a Graphic Layer",
    "key": "Ctrl+Alt+'",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Begin Text Editing for a Graphic Layer",
    "desc": "Lệnh trong menu Application > Begin Text Editing for a Graphic Layer",
    "cmd": "Begin Text Editing for a Graphic Layer"
  },
  {
    "name": "Center align text",
    "key": "Ctrl+Shift+C",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Center align text",
    "desc": "Căn giữa văn bản chữ",
    "cmd": "Center align text"
  },
  {
    "name": "Change Draw Mode",
    "key": "Ctrl+Alt+L",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change Draw Mode",
    "desc": "Lệnh trong menu Application > Change Draw Mode",
    "cmd": "Change Draw Mode"
  },
  {
    "name": "Change mask overlay color to black & white",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change mask overlay color to black & white",
    "desc": "Lệnh trong menu Application > Change mask overlay color to black & white",
    "cmd": "Change mask overlay color to black & white"
  },
  {
    "name": "Change mask overlay color to blue",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change mask overlay color to blue",
    "desc": "Lệnh trong menu Application > Change mask overlay color to blue",
    "cmd": "Change mask overlay color to blue"
  },
  {
    "name": "Change mask overlay color to cyan",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change mask overlay color to cyan",
    "desc": "Lệnh trong menu Application > Change mask overlay color to cyan",
    "cmd": "Change mask overlay color to cyan"
  },
  {
    "name": "Change mask overlay color to green",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change mask overlay color to green",
    "desc": "Lệnh trong menu Application > Change mask overlay color to green",
    "cmd": "Change mask overlay color to green"
  },
  {
    "name": "Change mask overlay color to magenta",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change mask overlay color to magenta",
    "desc": "Lệnh trong menu Application > Change mask overlay color to magenta",
    "cmd": "Change mask overlay color to magenta"
  },
  {
    "name": "Change mask overlay color to none",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change mask overlay color to none",
    "desc": "Lệnh trong menu Application > Change mask overlay color to none",
    "cmd": "Change mask overlay color to none"
  },
  {
    "name": "Change mask overlay color to red",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change mask overlay color to red",
    "desc": "Lệnh trong menu Application > Change mask overlay color to red",
    "cmd": "Change mask overlay color to red"
  },
  {
    "name": "Change mask overlay color to yellow",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change mask overlay color to yellow",
    "desc": "Lệnh trong menu Application > Change mask overlay color to yellow",
    "cmd": "Change mask overlay color to yellow"
  },
  {
    "name": "Change to opacity mask",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Change to opacity mask",
    "desc": "Lệnh trong menu Application > Change to opacity mask",
    "cmd": "Change to opacity mask"
  },
  {
    "name": "Clear Poster Frame",
    "key": "Ctrl+Shift+P",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Clear Poster Frame",
    "desc": "Lệnh trong menu Application > Clear Poster Frame",
    "cmd": "Clear Poster Frame"
  },
  {
    "name": "Cut to Camera 1",
    "key": "Ctrl+1",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 1",
    "desc": "Cắt góc máy sang Camera 1 (Multicam)",
    "cmd": "Cut to Camera 1"
  },
  {
    "name": "Cut to Camera 2",
    "key": "Ctrl+2",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 2",
    "desc": "Cắt góc máy sang Camera 2 (Multicam)",
    "cmd": "Cut to Camera 2"
  },
  {
    "name": "Cut to Camera 3",
    "key": "Ctrl+3",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 3",
    "desc": "Cắt góc máy sang Camera 3 (Multicam)",
    "cmd": "Cut to Camera 3"
  },
  {
    "name": "Cut to Camera 4",
    "key": "Ctrl+4",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 4",
    "desc": "Cắt góc máy sang Camera 4 (Multicam)",
    "cmd": "Cut to Camera 4"
  },
  {
    "name": "Cut to Camera 5",
    "key": "Ctrl+5",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 5",
    "desc": "Cắt góc máy sang Camera 5 (Multicam)",
    "cmd": "Cut to Camera 5"
  },
  {
    "name": "Cut to Camera 6",
    "key": "Ctrl+6",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 6",
    "desc": "Cắt góc máy sang Camera 6 (Multicam)",
    "cmd": "Cut to Camera 6"
  },
  {
    "name": "Cut to Camera 7",
    "key": "Ctrl+7",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 7",
    "desc": "Cắt góc máy sang Camera 7 (Multicam)",
    "cmd": "Cut to Camera 7"
  },
  {
    "name": "Cut to Camera 8",
    "key": "Ctrl+8",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 8",
    "desc": "Cắt góc máy sang Camera 8 (Multicam)",
    "cmd": "Cut to Camera 8"
  },
  {
    "name": "Cut to Camera 9",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 9",
    "desc": "Lệnh trong menu Application > Cut to Camera 9",
    "cmd": "Cut to Camera 9"
  },
  {
    "name": "Cut to Camera 10",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 10",
    "desc": "Lệnh trong menu Application > Cut to Camera 10",
    "cmd": "Cut to Camera 10"
  },
  {
    "name": "Cut to Camera 11",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 11",
    "desc": "Lệnh trong menu Application > Cut to Camera 11",
    "cmd": "Cut to Camera 11"
  },
  {
    "name": "Cut to Camera 12",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 12",
    "desc": "Lệnh trong menu Application > Cut to Camera 12",
    "cmd": "Cut to Camera 12"
  },
  {
    "name": "Cut to Camera 13",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 13",
    "desc": "Lệnh trong menu Application > Cut to Camera 13",
    "cmd": "Cut to Camera 13"
  },
  {
    "name": "Cut to Camera 14",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 14",
    "desc": "Lệnh trong menu Application > Cut to Camera 14",
    "cmd": "Cut to Camera 14"
  },
  {
    "name": "Cut to Camera 15",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 15",
    "desc": "Lệnh trong menu Application > Cut to Camera 15",
    "cmd": "Cut to Camera 15"
  },
  {
    "name": "Cut to Camera 16",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Cut to Camera 16",
    "desc": "Lệnh trong menu Application > Cut to Camera 16",
    "cmd": "Cut to Camera 16"
  },
  {
    "name": "Decrease Audio Keyframe Value",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Decrease Audio Keyframe Value",
    "desc": "Lệnh trong menu Application > Decrease Audio Keyframe Value",
    "cmd": "Decrease Audio Keyframe Value"
  },
  {
    "name": "Decrease Clip Volume",
    "key": "[",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Decrease Clip Volume",
    "desc": "Giảm âm lượng clip 1 dB",
    "cmd": "Decrease Clip Volume"
  },
  {
    "name": "Decrease Clip Volume Many",
    "key": "Shift+[",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Decrease Clip Volume Many",
    "desc": "Giảm âm lượng clip nhiều (6 dB)",
    "cmd": "Decrease Clip Volume Many"
  },
  {
    "name": "Decrease Font Size by Five Units",
    "key": "Ctrl+Alt+Shift+Left",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Decrease Font Size by Five Units",
    "desc": "Giảm cỡ chữ 5 đơn vị",
    "cmd": "Decrease Font Size by Five Units"
  },
  {
    "name": "Decrease Font Size by One Unit",
    "key": "Ctrl+Alt+Left",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Decrease Font Size by One Unit",
    "desc": "Giảm cỡ chữ 1 đơn vị",
    "cmd": "Decrease Font Size by One Unit"
  },
  {
    "name": "Decrease Kerning by Fifty Units",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Decrease Kerning by Fifty Units",
    "desc": "Lệnh trong menu Application > Decrease Kerning by Fifty Units",
    "cmd": "Decrease Kerning by Fifty Units"
  },
  {
    "name": "Decrease Kerning by Five Units",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Decrease Kerning by Five Units",
    "desc": "Lệnh trong menu Application > Decrease Kerning by Five Units",
    "cmd": "Decrease Kerning by Five Units"
  },
  {
    "name": "Decrease Kerning by One Unit",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Decrease Kerning by One Unit",
    "desc": "Lệnh trong menu Application > Decrease Kerning by One Unit",
    "cmd": "Decrease Kerning by One Unit"
  },
  {
    "name": "Decrease Leading by Five Units",
    "key": "Alt+Shift+Down",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Decrease Leading by Five Units",
    "desc": "Giảm khoảng cách dòng chữ 5 đơn vị",
    "cmd": "Decrease Leading by Five Units"
  },
  {
    "name": "Decrease Leading by One Unit",
    "key": "Alt+Down",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Decrease Leading by One Unit",
    "desc": "Giảm khoảng cách dòng chữ 1 đơn vị",
    "cmd": "Decrease Leading by One Unit"
  },
  {
    "name": "Decrease Video Keyframe Value",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Decrease Video Keyframe Value",
    "desc": "Lệnh trong menu Application > Decrease Video Keyframe Value",
    "cmd": "Decrease Video Keyframe Value"
  },
  {
    "name": "Default Source Assignment",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Default Source Assignment",
    "desc": "Lệnh trong menu Application > Default Source Assignment",
    "cmd": "Default Source Assignment"
  },
  {
    "name": "Delete Empty Tracks",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Delete Empty Tracks",
    "desc": "Lệnh trong menu Application > Delete Empty Tracks",
    "cmd": "Delete Empty Tracks"
  },
  {
    "name": "Edit Properties",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit Properties",
    "desc": "Lệnh trong menu Application > Edit Properties",
    "cmd": "Edit Properties"
  },
  {
    "name": "Edit selected caption text",
    "key": "",
    "cat": "edit",
    "catName": "Menu Edit & Clipboard",
    "path": "Application > Edit selected caption text",
    "desc": "Lệnh trong menu Application > Edit selected caption text",
    "cmd": "Edit selected caption text"
  },
  {
    "name": "Enable Transmit",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Enable Transmit",
    "desc": "Lệnh trong menu Application > Enable Transmit",
    "cmd": "Enable Transmit"
  },
  {
    "name": "Expand All Tracks",
    "key": "Shift+=",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Expand All Tracks",
    "desc": "Mở rộng độ cao của tất cả các track",
    "cmd": "Expand All Tracks"
  },
  {
    "name": "Export Frame",
    "key": "Ctrl+Shift+E",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Export Frame",
    "desc": "Xuất nhanh frame hình ảnh tĩnh tại playhead",
    "cmd": "Export Frame"
  },
  {
    "name": "Extend Next Edit To Playhead",
    "key": "Shift+W",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Extend Next Edit To Playhead",
    "desc": "Kéo dài điểm cắt tiếp theo lùi về playhead",
    "cmd": "Extend Next Edit To Playhead"
  },
  {
    "name": "Extend Previous Edit To Playhead",
    "key": "Shift+Q",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Extend Previous Edit To Playhead",
    "desc": "Kéo dài điểm cắt phía trước tiến tới playhead",
    "cmd": "Extend Previous Edit To Playhead"
  },
  {
    "name": "Fast Forward",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Fast Forward",
    "desc": "Lệnh trong menu Application > Fast Forward",
    "cmd": "Fast Forward"
  },
  {
    "name": "Faux Bold",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Faux Bold",
    "desc": "Lệnh trong menu Application > Faux Bold",
    "cmd": "Faux Bold"
  },
  {
    "name": "Faux Italic",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Faux Italic",
    "desc": "Lệnh trong menu Application > Faux Italic",
    "cmd": "Faux Italic"
  },
  {
    "name": "Force Media Refresh",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Force Media Refresh",
    "desc": "Lệnh trong menu Application > Force Media Refresh",
    "cmd": "Force Media Refresh"
  },
  {
    "name": "Gang Source and Program",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Gang Source and Program",
    "desc": "Lệnh trong menu Application > Gang Source and Program",
    "cmd": "Gang Source and Program"
  },
  {
    "name": "Go to First Multi-Camera Page",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Go to First Multi-Camera Page",
    "desc": "Lệnh trong menu Application > Go to First Multi-Camera Page",
    "cmd": "Go to First Multi-Camera Page"
  },
  {
    "name": "Go to Last Multi-Camera Page",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Go to Last Multi-Camera Page",
    "desc": "Lệnh trong menu Application > Go to Last Multi-Camera Page",
    "cmd": "Go to Last Multi-Camera Page"
  },
  {
    "name": "Go to Next Edit Point",
    "key": "Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Go to Next Edit Point",
    "desc": "Nhảy tới điểm cắt tiếp theo trên track đang target",
    "cmd": "Go to Next Edit Point"
  },
  {
    "name": "Go to Next Edit Point on Any Track",
    "key": "Shift+Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Go to Next Edit Point on Any Track",
    "desc": "Nhảy tới điểm cắt tiếp theo trên bất kỳ track nào",
    "cmd": "Go to Next Edit Point on Any Track"
  },
  {
    "name": "Go to Next Multi-Camera Page",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Go to Next Multi-Camera Page",
    "desc": "Lệnh trong menu Application > Go to Next Multi-Camera Page",
    "cmd": "Go to Next Multi-Camera Page"
  },
  {
    "name": "Go to Next Selected Edit Point",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Go to Next Selected Edit Point",
    "desc": "Lệnh trong menu Application > Go to Next Selected Edit Point",
    "cmd": "Go to Next Selected Edit Point"
  },
  {
    "name": "Go to Previous Edit Point",
    "key": "Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Go to Previous Edit Point",
    "desc": "Nhảy về điểm cắt phía trước trên track đang target",
    "cmd": "Go to Previous Edit Point"
  },
  {
    "name": "Go to Previous Edit Point on Any Track",
    "key": "Shift+Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Go to Previous Edit Point on Any Track",
    "desc": "Nhảy về điểm cắt phía trước trên bất kỳ track nào",
    "cmd": "Go to Previous Edit Point on Any Track"
  },
  {
    "name": "Go to Previous Multi-Camera Page",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Go to Previous Multi-Camera Page",
    "desc": "Lệnh trong menu Application > Go to Previous Multi-Camera Page",
    "cmd": "Go to Previous Multi-Camera Page"
  },
  {
    "name": "Go to Previous Selected Edit Point",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Go to Previous Selected Edit Point",
    "desc": "Lệnh trong menu Application > Go to Previous Selected Edit Point",
    "cmd": "Go to Previous Selected Edit Point"
  },
  {
    "name": "Go to Selected Clip End",
    "key": "Shift+End",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Go to Selected Clip End",
    "desc": "Nhảy tới điểm kết thúc của clip đang chọn",
    "cmd": "Go to Selected Clip End"
  },
  {
    "name": "Go to Selected Clip Start",
    "key": "Shift+Home",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Go to Selected Clip Start",
    "desc": "Nhảy tới điểm bắt đầu của clip đang chọn",
    "cmd": "Go to Selected Clip Start"
  },
  {
    "name": "Go to Sequence-Clip End",
    "key": "End",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Go to Sequence-Clip End",
    "desc": "Nhảy về cuối sequence (End)",
    "cmd": "Go to Sequence-Clip End"
  },
  {
    "name": "Go to Sequence-Clip Start",
    "key": "Home",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Go to Sequence-Clip Start",
    "desc": "Nhảy về đầu sequence (Home)",
    "cmd": "Go to Sequence-Clip Start"
  },
  {
    "name": "Increase Audio Keyframe Value",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Increase Audio Keyframe Value",
    "desc": "Lệnh trong menu Application > Increase Audio Keyframe Value",
    "cmd": "Increase Audio Keyframe Value"
  },
  {
    "name": "Increase Clip Volume",
    "key": "]",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Increase Clip Volume",
    "desc": "Tăng âm lượng clip 1 dB",
    "cmd": "Increase Clip Volume"
  },
  {
    "name": "Increase Clip Volume Many",
    "key": "Shift+]",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Increase Clip Volume Many",
    "desc": "Tăng âm lượng clip nhiều (6 dB)",
    "cmd": "Increase Clip Volume Many"
  },
  {
    "name": "Increase Font Size by Five Units",
    "key": "Ctrl+Alt+Shift+Right",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Increase Font Size by Five Units",
    "desc": "Tăng cỡ chữ 5 đơn vị",
    "cmd": "Increase Font Size by Five Units"
  },
  {
    "name": "Increase Font Size by One Unit",
    "key": "Ctrl+Alt+Right",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Increase Font Size by One Unit",
    "desc": "Tăng cỡ chữ 1 đơn vị",
    "cmd": "Increase Font Size by One Unit"
  },
  {
    "name": "Increase Kerning by Fifty Units",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Increase Kerning by Fifty Units",
    "desc": "Lệnh trong menu Application > Increase Kerning by Fifty Units",
    "cmd": "Increase Kerning by Fifty Units"
  },
  {
    "name": "Increase Kerning by Five Units",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Increase Kerning by Five Units",
    "desc": "Lệnh trong menu Application > Increase Kerning by Five Units",
    "cmd": "Increase Kerning by Five Units"
  },
  {
    "name": "Increase Kerning by One Unit",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Increase Kerning by One Unit",
    "desc": "Lệnh trong menu Application > Increase Kerning by One Unit",
    "cmd": "Increase Kerning by One Unit"
  },
  {
    "name": "Increase Leading by Five Units",
    "key": "Alt+Shift+Up",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Increase Leading by Five Units",
    "desc": "Tăng khoảng cách dòng chữ 5 đơn vị",
    "cmd": "Increase Leading by Five Units"
  },
  {
    "name": "Increase Leading by One Unit",
    "key": "Alt+Up",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Application > Increase Leading by One Unit",
    "desc": "Tăng khoảng cách dòng chữ 1 đơn vị",
    "cmd": "Increase Leading by One Unit"
  },
  {
    "name": "Increase Video Keyframe Value",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Increase Video Keyframe Value",
    "desc": "Lệnh trong menu Application > Increase Video Keyframe Value",
    "cmd": "Increase Video Keyframe Value"
  },
  {
    "name": "Invert mask",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Invert mask",
    "desc": "Lệnh trong menu Application > Invert mask",
    "cmd": "Invert mask"
  },
  {
    "name": "Left align text",
    "key": "Ctrl+Shift+L",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Left align text",
    "desc": "Căn trái văn bản chữ",
    "cmd": "Left align text"
  },
  {
    "name": "Left to right typing",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Left to right typing",
    "desc": "Lệnh trong menu Application > Left to right typing",
    "cmd": "Left to right typing"
  },
  {
    "name": "Loop Playback",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Loop Playback",
    "desc": "Lệnh trong menu Application > Loop Playback",
    "cmd": "Loop Playback"
  },
  {
    "name": "Make Subsequence From All Tracks",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Make Subsequence From All Tracks",
    "desc": "Lệnh trong menu Application > Make Subsequence From All Tracks",
    "cmd": "Make Subsequence From All Tracks"
  },
  {
    "name": "Manage Source Assignment Presets",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Manage Source Assignment Presets",
    "desc": "Lệnh trong menu Application > Manage Source Assignment Presets",
    "cmd": "Manage Source Assignment Presets"
  },
  {
    "name": "Manage Track Height Presets",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Manage Track Height Presets",
    "desc": "Lệnh trong menu Application > Manage Track Height Presets",
    "cmd": "Manage Track Height Presets"
  },
  {
    "name": "Maximize or Restore Active Frame",
    "key": "Shift+`",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Maximize or Restore Active Frame",
    "desc": "Phóng to tối đa cửa sổ đang hoạt động (hoặc khôi phục lại)",
    "cmd": "Maximize or Restore Active Frame"
  },
  {
    "name": "Maximize or Restore Frame Under Cursor",
    "key": "`",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Maximize or Restore Frame Under Cursor",
    "desc": "Phóng to tối đa cửa sổ dưới con trỏ chuột",
    "cmd": "Maximize or Restore Frame Under Cursor"
  },
  {
    "name": "Merge selected caption segments",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Merge selected caption segments",
    "desc": "Lệnh trong menu Application > Merge selected caption segments",
    "cmd": "Merge selected caption segments"
  },
  {
    "name": "Minimize All Tracks",
    "key": "Shift+-",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Minimize All Tracks",
    "desc": "Thu nhỏ tối đa độ cao của tất cả các track",
    "cmd": "Minimize All Tracks"
  },
  {
    "name": "Move All Audio Sources Down",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Move All Audio Sources Down",
    "desc": "Lệnh trong menu Application > Move All Audio Sources Down",
    "cmd": "Move All Audio Sources Down"
  },
  {
    "name": "Move All Audio Sources Up",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Move All Audio Sources Up",
    "desc": "Lệnh trong menu Application > Move All Audio Sources Up",
    "cmd": "Move All Audio Sources Up"
  },
  {
    "name": "Move All Audio Targets Down",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Move All Audio Targets Down",
    "desc": "Lệnh trong menu Application > Move All Audio Targets Down",
    "cmd": "Move All Audio Targets Down"
  },
  {
    "name": "Move All Audio Targets Up",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Move All Audio Targets Up",
    "desc": "Lệnh trong menu Application > Move All Audio Targets Up",
    "cmd": "Move All Audio Targets Up"
  },
  {
    "name": "Move All Video Sources Down",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Move All Video Sources Down",
    "desc": "Lệnh trong menu Application > Move All Video Sources Down",
    "cmd": "Move All Video Sources Down"
  },
  {
    "name": "Move All Video Sources Up",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Move All Video Sources Up",
    "desc": "Lệnh trong menu Application > Move All Video Sources Up",
    "cmd": "Move All Video Sources Up"
  },
  {
    "name": "Move All Video Targets Down",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Move All Video Targets Down",
    "desc": "Lệnh trong menu Application > Move All Video Targets Down",
    "cmd": "Move All Video Targets Down"
  },
  {
    "name": "Move All Video Targets Up",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Move All Video Targets Up",
    "desc": "Lệnh trong menu Application > Move All Video Targets Up",
    "cmd": "Move All Video Targets Up"
  },
  {
    "name": "Move Audio Keyframe 1 Frame earlier",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Move Audio Keyframe 1 Frame earlier",
    "desc": "Lệnh trong menu Application > Move Audio Keyframe 1 Frame earlier",
    "cmd": "Move Audio Keyframe 1 Frame earlier"
  },
  {
    "name": "Move Audio Keyframe 1 Frame later",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Move Audio Keyframe 1 Frame later",
    "desc": "Lệnh trong menu Application > Move Audio Keyframe 1 Frame later",
    "cmd": "Move Audio Keyframe 1 Frame later"
  },
  {
    "name": "Move Audio Keyframe 10 Frames earlier",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Move Audio Keyframe 10 Frames earlier",
    "desc": "Lệnh trong menu Application > Move Audio Keyframe 10 Frames earlier",
    "cmd": "Move Audio Keyframe 10 Frames earlier"
  },
  {
    "name": "Move Audio Keyframe 10 Frames later",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Move Audio Keyframe 10 Frames later",
    "desc": "Lệnh trong menu Application > Move Audio Keyframe 10 Frames later",
    "cmd": "Move Audio Keyframe 10 Frames later"
  },
  {
    "name": "Move Poster Frame 10 Frames Back",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Move Poster Frame 10 Frames Back",
    "desc": "Lệnh trong menu Application > Move Poster Frame 10 Frames Back",
    "cmd": "Move Poster Frame 10 Frames Back"
  },
  {
    "name": "Move Poster Frame 10 Frames Forward",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Move Poster Frame 10 Frames Forward",
    "desc": "Lệnh trong menu Application > Move Poster Frame 10 Frames Forward",
    "cmd": "Move Poster Frame 10 Frames Forward"
  },
  {
    "name": "Move Video Keyframe 1 Frame earlier",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Move Video Keyframe 1 Frame earlier",
    "desc": "Lệnh trong menu Application > Move Video Keyframe 1 Frame earlier",
    "cmd": "Move Video Keyframe 1 Frame earlier"
  },
  {
    "name": "Move Video Keyframe 1 Frame later",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Move Video Keyframe 1 Frame later",
    "desc": "Lệnh trong menu Application > Move Video Keyframe 1 Frame later",
    "cmd": "Move Video Keyframe 1 Frame later"
  },
  {
    "name": "Move Video Keyframe 10 Frames earlier",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Move Video Keyframe 10 Frames earlier",
    "desc": "Lệnh trong menu Application > Move Video Keyframe 10 Frames earlier",
    "cmd": "Move Video Keyframe 10 Frames earlier"
  },
  {
    "name": "Move Video Keyframe 10 Frames later",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Move Video Keyframe 10 Frames later",
    "desc": "Lệnh trong menu Application > Move Video Keyframe 10 Frames later",
    "cmd": "Move Video Keyframe 10 Frames later"
  },
  {
    "name": "Multi-Camera Audio Follows Video",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Multi-Camera Audio Follows Video",
    "desc": "Lệnh trong menu Application > Multi-Camera Audio Follows Video",
    "cmd": "Multi-Camera Audio Follows Video"
  },
  {
    "name": "Multi-Camera Follows Nest Setting",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Multi-Camera Follows Nest Setting",
    "desc": "Lệnh trong menu Application > Multi-Camera Follows Nest Setting",
    "cmd": "Multi-Camera Follows Nest Setting"
  },
  {
    "name": "Multi-Camera Record On/Off Toggle",
    "key": "0",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Multi-Camera Record On/Off Toggle",
    "desc": "Lệnh trong menu Application > Multi-Camera Record On/Off Toggle",
    "cmd": "Multi-Camera Record On/Off Toggle"
  },
  {
    "name": "Multi-Camera Selection Top Down",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Multi-Camera Selection Top Down",
    "desc": "Lệnh trong menu Application > Multi-Camera Selection Top Down",
    "cmd": "Multi-Camera Selection Top Down"
  },
  {
    "name": "Mute All Audio",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Mute All Audio",
    "desc": "Lệnh trong menu Application > Mute All Audio",
    "cmd": "Mute All Audio"
  },
  {
    "name": "Mute Program Monitor",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Mute Program Monitor",
    "desc": "Lệnh trong menu Application > Mute Program Monitor",
    "cmd": "Mute Program Monitor"
  },
  {
    "name": "Mute Source Monitor",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Mute Source Monitor",
    "desc": "Lệnh trong menu Application > Mute Source Monitor",
    "cmd": "Mute Source Monitor"
  },
  {
    "name": "Next Preview Item",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Next Preview Item",
    "desc": "Lệnh trong menu Application > Next Preview Item",
    "cmd": "Next Preview Item"
  },
  {
    "name": "Nudge Volume +1dB",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Nudge Volume +1dB",
    "desc": "Lệnh trong menu Application > Nudge Volume +1dB",
    "cmd": "Nudge Volume +1dB"
  },
  {
    "name": "Nudge Volume +3dB",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Nudge Volume +3dB",
    "desc": "Lệnh trong menu Application > Nudge Volume +3dB",
    "cmd": "Nudge Volume +3dB"
  },
  {
    "name": "Nudge Volume -1dB",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Nudge Volume -1dB",
    "desc": "Lệnh trong menu Application > Nudge Volume -1dB",
    "cmd": "Nudge Volume -1dB"
  },
  {
    "name": "Nudge Volume -3dB",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Nudge Volume -3dB",
    "desc": "Lệnh trong menu Application > Nudge Volume -3dB",
    "cmd": "Nudge Volume -3dB"
  },
  {
    "name": "Open Search",
    "key": "Ctrl+Shift+F",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Open Search",
    "desc": "Lệnh trong menu Application > Open Search",
    "cmd": "Open Search"
  },
  {
    "name": "Overlay Settings",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Overlay Settings",
    "desc": "Lệnh trong menu Application > Overlay Settings",
    "cmd": "Overlay Settings"
  },
  {
    "name": "Overlays",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Overlays",
    "desc": "Lệnh trong menu Application > Overlays",
    "cmd": "Overlays"
  },
  {
    "name": "Play Around",
    "key": "Shift+K",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Play Around",
    "desc": "Phát một đoạn quanh vị trí playhead để nghe kiểm tra",
    "cmd": "Play Around"
  },
  {
    "name": "Play Audio In to Out",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Play Audio In to Out",
    "desc": "Lệnh trong menu Application > Play Audio In to Out",
    "cmd": "Play Audio In to Out"
  },
  {
    "name": "Play In to Out",
    "key": "Ctrl+Shift+Space",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Play In to Out",
    "desc": "Phát từ điểm In tới điểm Out",
    "cmd": "Play In to Out"
  },
  {
    "name": "Play In to Out with Preroll/Postroll",
    "key": "Shift+Space",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Play In to Out with Preroll/Postroll",
    "desc": "Lệnh trong menu Application > Play In to Out with Preroll/Postroll",
    "cmd": "Play In to Out with Preroll/Postroll"
  },
  {
    "name": "Play Video In to Out",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Play Video In to Out",
    "desc": "Lệnh trong menu Application > Play Video In to Out",
    "cmd": "Play Video In to Out"
  },
  {
    "name": "Play from Playhead to Audio Out Point",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Play from Playhead to Audio Out Point",
    "desc": "Lệnh trong menu Application > Play from Playhead to Audio Out Point",
    "cmd": "Play from Playhead to Audio Out Point"
  },
  {
    "name": "Play from Playhead to Out Point",
    "key": "Ctrl+Space",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Play from Playhead to Out Point",
    "desc": "Phát từ playhead tới điểm Out",
    "cmd": "Play from Playhead to Out Point"
  },
  {
    "name": "Play from Playhead to Video Out Point",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Play from Playhead to Video Out Point",
    "desc": "Lệnh trong menu Application > Play from Playhead to Video Out Point",
    "cmd": "Play from Playhead to Video Out Point"
  },
  {
    "name": "Play-Stop Toggle",
    "key": "Space",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Play-Stop Toggle",
    "desc": "Phát hoặc dừng video (Space)",
    "cmd": "Play-Stop Toggle"
  },
  {
    "name": "Previous Preview Item",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Previous Preview Item",
    "desc": "Lệnh trong menu Application > Previous Preview Item",
    "cmd": "Previous Preview Item"
  },
  {
    "name": "Quick Export",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Quick Export",
    "desc": "Lệnh trong menu Application > Quick Export",
    "cmd": "Quick Export"
  },
  {
    "name": "Record Voiceover",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Record Voiceover",
    "desc": "Lệnh trong menu Application > Record Voiceover",
    "cmd": "Record Voiceover"
  },
  {
    "name": "Rename Mask Or Selection",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Rename Mask Or Selection",
    "desc": "Lệnh trong menu Application > Rename Mask Or Selection",
    "cmd": "Rename Mask Or Selection"
  },
  {
    "name": "Restore Trim Selection",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Restore Trim Selection",
    "desc": "Lệnh trong menu Application > Restore Trim Selection",
    "cmd": "Restore Trim Selection"
  },
  {
    "name": "Reveal In Explorer",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Reveal In Explorer",
    "desc": "Lệnh trong menu Application > Reveal In Explorer",
    "cmd": "Reveal In Explorer"
  },
  {
    "name": "Reveal Nested Sequence",
    "key": "Ctrl+Alt+F",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Reveal Nested Sequence",
    "desc": "Lệnh trong menu Application > Reveal Nested Sequence",
    "cmd": "Reveal Nested Sequence"
  },
  {
    "name": "Revert Trim Session",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Revert Trim Session",
    "desc": "Lệnh trong menu Application > Revert Trim Session",
    "cmd": "Revert Trim Session"
  },
  {
    "name": "Rewind",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Rewind",
    "desc": "Lệnh trong menu Application > Rewind",
    "cmd": "Rewind"
  },
  {
    "name": "Right align text",
    "key": "Ctrl+Shift+R",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Right align text",
    "desc": "Căn phải văn bản chữ",
    "cmd": "Right align text"
  },
  {
    "name": "Right to left typing",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Right to left typing",
    "desc": "Lệnh trong menu Application > Right to left typing",
    "cmd": "Right to left typing"
  },
  {
    "name": "Ripple Delete Head Frame",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Ripple Delete Head Frame",
    "desc": "Lệnh trong menu Application > Ripple Delete Head Frame",
    "cmd": "Ripple Delete Head Frame"
  },
  {
    "name": "Ripple Trim Next Edit To Playhead",
    "key": "W",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Ripple Trim Next Edit To Playhead",
    "desc": "Cắt bỏ đuôi clip từ playhead tới điểm cắt sau và dồn lại (W)",
    "cmd": "Ripple Trim Next Edit To Playhead"
  },
  {
    "name": "Ripple Trim Previous Edit To Playhead",
    "key": "Q",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Ripple Trim Previous Edit To Playhead",
    "desc": "Cắt bỏ đầu clip từ điểm cắt trước tới playhead và dồn lại (Q)",
    "cmd": "Ripple Trim Previous Edit To Playhead"
  },
  {
    "name": "Save Source Assignment Preset",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Save Source Assignment Preset",
    "desc": "Lệnh trong menu Application > Save Source Assignment Preset",
    "cmd": "Save Source Assignment Preset"
  },
  {
    "name": "Save Track Height Preset",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Save Track Height Preset",
    "desc": "Lệnh trong menu Application > Save Track Height Preset",
    "cmd": "Save Track Height Preset"
  },
  {
    "name": "Search Similar Frames",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Search Similar Frames",
    "desc": "Lệnh trong menu Application > Search Similar Frames",
    "cmd": "Search Similar Frames"
  },
  {
    "name": "Select Camera 1",
    "key": "1",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 1",
    "desc": "Chọn Camera 1 trong Multicam",
    "cmd": "Select Camera 1"
  },
  {
    "name": "Select Camera 2",
    "key": "2",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 2",
    "desc": "Chọn Camera 2 trong Multicam",
    "cmd": "Select Camera 2"
  },
  {
    "name": "Select Camera 3",
    "key": "3",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 3",
    "desc": "Chọn Camera 3 trong Multicam",
    "cmd": "Select Camera 3"
  },
  {
    "name": "Select Camera 4",
    "key": "4",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 4",
    "desc": "Chọn Camera 4 trong Multicam",
    "cmd": "Select Camera 4"
  },
  {
    "name": "Select Camera 5",
    "key": "5",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 5",
    "desc": "Chọn Camera 5 trong Multicam",
    "cmd": "Select Camera 5"
  },
  {
    "name": "Select Camera 6",
    "key": "6",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 6",
    "desc": "Chọn Camera 6 trong Multicam",
    "cmd": "Select Camera 6"
  },
  {
    "name": "Select Camera 7",
    "key": "7",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 7",
    "desc": "Chọn Camera 7 trong Multicam",
    "cmd": "Select Camera 7"
  },
  {
    "name": "Select Camera 8",
    "key": "8",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 8",
    "desc": "Chọn Camera 8 trong Multicam",
    "cmd": "Select Camera 8"
  },
  {
    "name": "Select Camera 9",
    "key": "9",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 9",
    "desc": "Chọn Camera 9 trong Multicam",
    "cmd": "Select Camera 9"
  },
  {
    "name": "Select Camera 10",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 10",
    "desc": "Lệnh trong menu Application > Select Camera 10",
    "cmd": "Select Camera 10"
  },
  {
    "name": "Select Camera 11",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 11",
    "desc": "Lệnh trong menu Application > Select Camera 11",
    "cmd": "Select Camera 11"
  },
  {
    "name": "Select Camera 12",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 12",
    "desc": "Lệnh trong menu Application > Select Camera 12",
    "cmd": "Select Camera 12"
  },
  {
    "name": "Select Camera 13",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 13",
    "desc": "Lệnh trong menu Application > Select Camera 13",
    "cmd": "Select Camera 13"
  },
  {
    "name": "Select Camera 14",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 14",
    "desc": "Lệnh trong menu Application > Select Camera 14",
    "cmd": "Select Camera 14"
  },
  {
    "name": "Select Camera 15",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 15",
    "desc": "Lệnh trong menu Application > Select Camera 15",
    "cmd": "Select Camera 15"
  },
  {
    "name": "Select Camera 16",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Camera 16",
    "desc": "Lệnh trong menu Application > Select Camera 16",
    "cmd": "Select Camera 16"
  },
  {
    "name": "Select Clip at Playhead",
    "key": "D",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Select Clip at Playhead",
    "desc": "Chọn clip nằm ngay dưới playhead",
    "cmd": "Select Clip at Playhead"
  },
  {
    "name": "Select Find Box",
    "key": "Shift+F",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Select Find Box",
    "desc": "Lệnh trong menu Application > Select Find Box",
    "cmd": "Select Find Box"
  },
  {
    "name": "Select In to Out",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Select In to Out",
    "desc": "Lệnh trong menu Application > Select In to Out",
    "cmd": "Select In to Out"
  },
  {
    "name": "Select Nearest Edit Point as Ripple In",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Select Nearest Edit Point as Ripple In",
    "desc": "Lệnh trong menu Application > Select Nearest Edit Point as Ripple In",
    "cmd": "Select Nearest Edit Point as Ripple In"
  },
  {
    "name": "Select Nearest Edit Point as Ripple Out",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Select Nearest Edit Point as Ripple Out",
    "desc": "Lệnh trong menu Application > Select Nearest Edit Point as Ripple Out",
    "cmd": "Select Nearest Edit Point as Ripple Out"
  },
  {
    "name": "Select Nearest Edit Point as Roll",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Select Nearest Edit Point as Roll",
    "desc": "Lệnh trong menu Application > Select Nearest Edit Point as Roll",
    "cmd": "Select Nearest Edit Point as Roll"
  },
  {
    "name": "Select Nearest Edit Point as Trim In",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Select Nearest Edit Point as Trim In",
    "desc": "Lệnh trong menu Application > Select Nearest Edit Point as Trim In",
    "cmd": "Select Nearest Edit Point as Trim In"
  },
  {
    "name": "Select Nearest Edit Point as Trim Out",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Select Nearest Edit Point as Trim Out",
    "desc": "Lệnh trong menu Application > Select Nearest Edit Point as Trim Out",
    "cmd": "Select Nearest Edit Point as Trim Out"
  },
  {
    "name": "Select Next Camera",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Next Camera",
    "desc": "Lệnh trong menu Application > Select Next Camera",
    "cmd": "Select Next Camera"
  },
  {
    "name": "Select Next Clip",
    "key": "Ctrl+Down",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Select Next Clip",
    "desc": "Chọn clip tiếp theo trên track",
    "cmd": "Select Next Clip"
  },
  {
    "name": "Select Next Effect Controls Properties Filter",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Select Next Effect Controls Properties Filter",
    "desc": "Lệnh trong menu Application > Select Next Effect Controls Properties Filter",
    "cmd": "Select Next Effect Controls Properties Filter"
  },
  {
    "name": "Select Next Panel",
    "key": "Ctrl+Shift+.",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Select Next Panel",
    "desc": "Tính năng trong bảng Application",
    "cmd": "Select Next Panel"
  },
  {
    "name": "Select Previous Camera",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Select Previous Camera",
    "desc": "Lệnh trong menu Application > Select Previous Camera",
    "cmd": "Select Previous Camera"
  },
  {
    "name": "Select Previous Clip",
    "key": "Ctrl+Up",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Select Previous Clip",
    "desc": "Chọn clip phía trước trên track",
    "cmd": "Select Previous Clip"
  },
  {
    "name": "Select Previous Panel",
    "key": "Ctrl+Shift+,",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Select Previous Panel",
    "desc": "Tính năng trong bảng Application",
    "cmd": "Select Previous Panel"
  },
  {
    "name": "Select next Keyframe",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Select next Keyframe",
    "desc": "Lệnh trong menu Application > Select next Keyframe",
    "cmd": "Select next Keyframe"
  },
  {
    "name": "Select previous Keyframe",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Select previous Keyframe",
    "desc": "Lệnh trong menu Application > Select previous Keyframe",
    "cmd": "Select previous Keyframe"
  },
  {
    "name": "Set All Source Audio To Gaps",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Set All Source Audio To Gaps",
    "desc": "Lệnh trong menu Application > Set All Source Audio To Gaps",
    "cmd": "Set All Source Audio To Gaps"
  },
  {
    "name": "Set All Source Caption To Gaps",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Application > Set All Source Caption To Gaps",
    "desc": "Lệnh trong menu Application > Set All Source Caption To Gaps",
    "cmd": "Set All Source Caption To Gaps"
  },
  {
    "name": "Set All Source Video To Gaps",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Set All Source Video To Gaps",
    "desc": "Lệnh trong menu Application > Set All Source Video To Gaps",
    "cmd": "Set All Source Video To Gaps"
  },
  {
    "name": "Set Clip Pan to Center",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Set Clip Pan to Center",
    "desc": "Lệnh trong menu Application > Set Clip Pan to Center",
    "cmd": "Set Clip Pan to Center"
  },
  {
    "name": "Set Clip Pan to Left",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Set Clip Pan to Left",
    "desc": "Lệnh trong menu Application > Set Clip Pan to Left",
    "cmd": "Set Clip Pan to Left"
  },
  {
    "name": "Set Clip Pan to Right",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Set Clip Pan to Right",
    "desc": "Lệnh trong menu Application > Set Clip Pan to Right",
    "cmd": "Set Clip Pan to Right"
  },
  {
    "name": "Set Intro End",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Set Intro End",
    "desc": "Lệnh trong menu Application > Set Intro End",
    "cmd": "Set Intro End"
  },
  {
    "name": "Set Marker Blue",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Set Marker Blue",
    "desc": "Lệnh trong menu Application > Set Marker Blue",
    "cmd": "Set Marker Blue"
  },
  {
    "name": "Set Marker Cyan",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Set Marker Cyan",
    "desc": "Lệnh trong menu Application > Set Marker Cyan",
    "cmd": "Set Marker Cyan"
  },
  {
    "name": "Set Marker Green",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Set Marker Green",
    "desc": "Lệnh trong menu Application > Set Marker Green",
    "cmd": "Set Marker Green"
  },
  {
    "name": "Set Marker Magenta",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Set Marker Magenta",
    "desc": "Lệnh trong menu Application > Set Marker Magenta",
    "cmd": "Set Marker Magenta"
  },
  {
    "name": "Set Marker Orange",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Set Marker Orange",
    "desc": "Lệnh trong menu Application > Set Marker Orange",
    "cmd": "Set Marker Orange"
  },
  {
    "name": "Set Marker Red",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Set Marker Red",
    "desc": "Lệnh trong menu Application > Set Marker Red",
    "cmd": "Set Marker Red"
  },
  {
    "name": "Set Marker White",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Set Marker White",
    "desc": "Lệnh trong menu Application > Set Marker White",
    "cmd": "Set Marker White"
  },
  {
    "name": "Set Marker Yellow",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Application > Set Marker Yellow",
    "desc": "Lệnh trong menu Application > Set Marker Yellow",
    "cmd": "Set Marker Yellow"
  },
  {
    "name": "Set Opacity Blend Mode Difference",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Set Opacity Blend Mode Difference",
    "desc": "Lệnh trong menu Application > Set Opacity Blend Mode Difference",
    "cmd": "Set Opacity Blend Mode Difference"
  },
  {
    "name": "Set Opacity Blend Mode Normal",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Set Opacity Blend Mode Normal",
    "desc": "Lệnh trong menu Application > Set Opacity Blend Mode Normal",
    "cmd": "Set Opacity Blend Mode Normal"
  },
  {
    "name": "Set Outro Start",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Set Outro Start",
    "desc": "Lệnh trong menu Application > Set Outro Start",
    "cmd": "Set Outro Start"
  },
  {
    "name": "Set Poster Frame",
    "key": "Shift+P",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Set Poster Frame",
    "desc": "Lệnh trong menu Application > Set Poster Frame",
    "cmd": "Set Poster Frame"
  },
  {
    "name": "Show All Properties",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Show All Properties",
    "desc": "Lệnh trong menu Application > Show All Properties",
    "cmd": "Show All Properties"
  },
  {
    "name": "Show Direct Manipulation During Playback",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Show Direct Manipulation During Playback",
    "desc": "Lệnh trong menu Application > Show Direct Manipulation During Playback",
    "cmd": "Show Direct Manipulation During Playback"
  },
  {
    "name": "Show Only Edited Properties",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Show Only Edited Properties",
    "desc": "Lệnh trong menu Application > Show Only Edited Properties",
    "cmd": "Show Only Edited Properties"
  },
  {
    "name": "Show Only Keyframed Properties",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Show Only Keyframed Properties",
    "desc": "Lệnh trong menu Application > Show Only Keyframed Properties",
    "cmd": "Show Only Keyframed Properties"
  },
  {
    "name": "Shuttle Left",
    "key": "J",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Shuttle Left",
    "desc": "Tua lùi (J - bấm nhiều lần tua càng nhanh)",
    "cmd": "Shuttle Left"
  },
  {
    "name": "Shuttle Right",
    "key": "L",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Shuttle Right",
    "desc": "Tua tới (L - bấm nhiều lần tua càng nhanh)",
    "cmd": "Shuttle Right"
  },
  {
    "name": "Shuttle Slow Left",
    "key": "Shift+J",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Shuttle Slow Left",
    "desc": "Tua lùi chậm từng bước",
    "cmd": "Shuttle Slow Left"
  },
  {
    "name": "Shuttle Slow Right",
    "key": "Shift+L",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Shuttle Slow Right",
    "desc": "Tua tới chậm từng bước",
    "cmd": "Shuttle Slow Right"
  },
  {
    "name": "Shuttle Stop",
    "key": "K",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Shuttle Stop",
    "desc": "Dừng tua (K)",
    "cmd": "Shuttle Stop"
  },
  {
    "name": "Small Caps",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Small Caps",
    "desc": "Lệnh trong menu Application > Small Caps",
    "cmd": "Small Caps"
  },
  {
    "name": "Source Assignment Preset 1",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 1",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 1",
    "cmd": "Source Assignment Preset 1"
  },
  {
    "name": "Source Assignment Preset 2",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 2",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 2",
    "cmd": "Source Assignment Preset 2"
  },
  {
    "name": "Source Assignment Preset 3",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 3",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 3",
    "cmd": "Source Assignment Preset 3"
  },
  {
    "name": "Source Assignment Preset 4",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 4",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 4",
    "cmd": "Source Assignment Preset 4"
  },
  {
    "name": "Source Assignment Preset 5",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 5",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 5",
    "cmd": "Source Assignment Preset 5"
  },
  {
    "name": "Source Assignment Preset 6",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 6",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 6",
    "cmd": "Source Assignment Preset 6"
  },
  {
    "name": "Source Assignment Preset 7",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 7",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 7",
    "cmd": "Source Assignment Preset 7"
  },
  {
    "name": "Source Assignment Preset 8",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 8",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 8",
    "cmd": "Source Assignment Preset 8"
  },
  {
    "name": "Source Assignment Preset 9",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 9",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 9",
    "cmd": "Source Assignment Preset 9"
  },
  {
    "name": "Source Assignment Preset 10",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Source Assignment Preset 10",
    "desc": "Lệnh trong menu Application > Source Assignment Preset 10",
    "cmd": "Source Assignment Preset 10"
  },
  {
    "name": "Split Caption Segment Under Playhead",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Application > Split Caption Segment Under Playhead",
    "desc": "Lệnh trong menu Application > Split Caption Segment Under Playhead",
    "cmd": "Split Caption Segment Under Playhead"
  },
  {
    "name": "Step Back 1 Frame",
    "key": "Left",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Step Back 1 Frame",
    "desc": "Lùi lại 1 frame",
    "cmd": "Step Back 1 Frame"
  },
  {
    "name": "Step Back Many Frames - Units",
    "key": "Shift+Left",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Step Back Many Frames - Units",
    "desc": "Lùi lại 5 frame",
    "cmd": "Step Back Many Frames - Units"
  },
  {
    "name": "Step Forward 1 Frame",
    "key": "Right",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Step Forward 1 Frame",
    "desc": "Tiến tới 1 frame",
    "cmd": "Step Forward 1 Frame"
  },
  {
    "name": "Step Forward Many Frames - Units",
    "key": "Shift+Right",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Step Forward Many Frames - Units",
    "desc": "Tiến tới 5 frame",
    "cmd": "Step Forward Many Frames - Units"
  },
  {
    "name": "Stop",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Stop",
    "desc": "Lệnh trong menu Application > Stop",
    "cmd": "Stop"
  },
  {
    "name": "Subscript",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Subscript",
    "desc": "Lệnh trong menu Application > Subscript",
    "cmd": "Subscript"
  },
  {
    "name": "Subtract from object",
    "key": "Ctrl+-",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Subtract from object",
    "desc": "Lệnh trong menu Application > Subtract from object",
    "cmd": "Subtract from object"
  },
  {
    "name": "Superscript",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Superscript",
    "desc": "Lệnh trong menu Application > Superscript",
    "cmd": "Superscript"
  },
  {
    "name": "Targets Follow Inserts and Overwrites",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Targets Follow Inserts and Overwrites",
    "desc": "Lệnh trong menu Application > Targets Follow Inserts and Overwrites",
    "cmd": "Targets Follow Inserts and Overwrites"
  },
  {
    "name": "Timecode Preset 1",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 1",
    "desc": "Lệnh trong menu Application > Timecode Preset 1",
    "cmd": "Timecode Preset 1"
  },
  {
    "name": "Timecode Preset 2",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 2",
    "desc": "Lệnh trong menu Application > Timecode Preset 2",
    "cmd": "Timecode Preset 2"
  },
  {
    "name": "Timecode Preset 3",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 3",
    "desc": "Lệnh trong menu Application > Timecode Preset 3",
    "cmd": "Timecode Preset 3"
  },
  {
    "name": "Timecode Preset 4",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 4",
    "desc": "Lệnh trong menu Application > Timecode Preset 4",
    "cmd": "Timecode Preset 4"
  },
  {
    "name": "Timecode Preset 5",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 5",
    "desc": "Lệnh trong menu Application > Timecode Preset 5",
    "cmd": "Timecode Preset 5"
  },
  {
    "name": "Timecode Preset 6",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 6",
    "desc": "Lệnh trong menu Application > Timecode Preset 6",
    "cmd": "Timecode Preset 6"
  },
  {
    "name": "Timecode Preset 7",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 7",
    "desc": "Lệnh trong menu Application > Timecode Preset 7",
    "cmd": "Timecode Preset 7"
  },
  {
    "name": "Timecode Preset 8",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 8",
    "desc": "Lệnh trong menu Application > Timecode Preset 8",
    "cmd": "Timecode Preset 8"
  },
  {
    "name": "Timecode Preset 9",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 9",
    "desc": "Lệnh trong menu Application > Timecode Preset 9",
    "cmd": "Timecode Preset 9"
  },
  {
    "name": "Timecode Preset 10",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Timecode Preset 10",
    "desc": "Lệnh trong menu Application > Timecode Preset 10",
    "cmd": "Timecode Preset 10"
  },
  {
    "name": "Toggle All Audio Targets",
    "key": "Ctrl+9",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle All Audio Targets",
    "desc": "Bật/tắt target tất cả audio track",
    "cmd": "Toggle All Audio Targets"
  },
  {
    "name": "Toggle All Source Audio",
    "key": "Ctrl+Alt+9",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle All Source Audio",
    "desc": "Bật/tắt patch nguồn audio",
    "cmd": "Toggle All Source Audio"
  },
  {
    "name": "Toggle All Source Caption",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Application > Toggle All Source Caption",
    "desc": "Lệnh trong menu Application > Toggle All Source Caption",
    "cmd": "Toggle All Source Caption"
  },
  {
    "name": "Toggle All Source Video",
    "key": "Ctrl+Alt+0",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle All Source Video",
    "desc": "Bật/tắt patch nguồn video",
    "cmd": "Toggle All Source Video"
  },
  {
    "name": "Toggle All Video Targets",
    "key": "Ctrl+0",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle All Video Targets",
    "desc": "Bật/tắt target tất cả video track",
    "cmd": "Toggle All Video Targets"
  },
  {
    "name": "Toggle Audio During Scrubbing",
    "key": "Shift+S",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Audio During Scrubbing",
    "desc": "Bật/tắt phát âm thanh khi scrub chuột trên timeline",
    "cmd": "Toggle Audio During Scrubbing"
  },
  {
    "name": "Toggle Control Surface Clip Mixer Mode",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Control Surface Clip Mixer Mode",
    "desc": "Lệnh trong menu Application > Toggle Control Surface Clip Mixer Mode",
    "cmd": "Toggle Control Surface Clip Mixer Mode"
  },
  {
    "name": "Toggle Crop Direct Manipulation",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Crop Direct Manipulation",
    "desc": "Lệnh trong menu Application > Toggle Crop Direct Manipulation",
    "cmd": "Toggle Crop Direct Manipulation"
  },
  {
    "name": "Toggle Full Screen",
    "key": "Ctrl+`",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Full Screen",
    "desc": "Bật/tắt chế độ toàn màn hình",
    "cmd": "Toggle Full Screen"
  },
  {
    "name": "Toggle Maintain Pitch During Shuttling",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Maintain Pitch During Shuttling",
    "desc": "Lệnh trong menu Application > Toggle Maintain Pitch During Shuttling",
    "cmd": "Toggle Maintain Pitch During Shuttling"
  },
  {
    "name": "Toggle Maximize Monitor",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Toggle Maximize Monitor",
    "desc": "Lệnh trong menu Application > Toggle Maximize Monitor",
    "cmd": "Toggle Maximize Monitor"
  },
  {
    "name": "Toggle Multi-Camera View",
    "key": "Shift+0",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Toggle Multi-Camera View",
    "desc": "Bật/tắt chế độ xem Multicam",
    "cmd": "Toggle Multi-Camera View"
  },
  {
    "name": "Toggle Mute for All Targeted Audio Tracks",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Mute for All Targeted Audio Tracks",
    "desc": "Lệnh trong menu Application > Toggle Mute for All Targeted Audio Tracks",
    "cmd": "Toggle Mute for All Targeted Audio Tracks"
  },
  {
    "name": "Toggle Proxies",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Proxies",
    "desc": "Lệnh trong menu Application > Toggle Proxies",
    "cmd": "Toggle Proxies"
  },
  {
    "name": "Toggle Solo for All Targeted Audio Tracks",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Solo for All Targeted Audio Tracks",
    "desc": "Lệnh trong menu Application > Toggle Solo for All Targeted Audio Tracks",
    "cmd": "Toggle Solo for All Targeted Audio Tracks"
  },
  {
    "name": "Toggle Source/Program Monitor Focus",
    "key": "",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Toggle Source/Program Monitor Focus",
    "desc": "Lệnh trong menu Application > Toggle Source/Program Monitor Focus",
    "cmd": "Toggle Source/Program Monitor Focus"
  },
  {
    "name": "Toggle Style Browser",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Style Browser",
    "desc": "Lệnh trong menu Application > Toggle Style Browser",
    "cmd": "Toggle Style Browser"
  },
  {
    "name": "Toggle Target Audio 1",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Target Audio 1",
    "desc": "Lệnh trong menu Application > Toggle Target Audio 1",
    "cmd": "Toggle Target Audio 1"
  },
  {
    "name": "Toggle Target Audio 2",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Target Audio 2",
    "desc": "Lệnh trong menu Application > Toggle Target Audio 2",
    "cmd": "Toggle Target Audio 2"
  },
  {
    "name": "Toggle Target Audio 3",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Target Audio 3",
    "desc": "Lệnh trong menu Application > Toggle Target Audio 3",
    "cmd": "Toggle Target Audio 3"
  },
  {
    "name": "Toggle Target Audio 4",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Target Audio 4",
    "desc": "Lệnh trong menu Application > Toggle Target Audio 4",
    "cmd": "Toggle Target Audio 4"
  },
  {
    "name": "Toggle Target Audio 5",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Target Audio 5",
    "desc": "Lệnh trong menu Application > Toggle Target Audio 5",
    "cmd": "Toggle Target Audio 5"
  },
  {
    "name": "Toggle Target Audio 6",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Target Audio 6",
    "desc": "Lệnh trong menu Application > Toggle Target Audio 6",
    "cmd": "Toggle Target Audio 6"
  },
  {
    "name": "Toggle Target Audio 7",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Target Audio 7",
    "desc": "Lệnh trong menu Application > Toggle Target Audio 7",
    "cmd": "Toggle Target Audio 7"
  },
  {
    "name": "Toggle Target Audio 8",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Application > Toggle Target Audio 8",
    "desc": "Lệnh trong menu Application > Toggle Target Audio 8",
    "cmd": "Toggle Target Audio 8"
  },
  {
    "name": "Toggle Target Video 1",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Target Video 1",
    "desc": "Lệnh trong menu Application > Toggle Target Video 1",
    "cmd": "Toggle Target Video 1"
  },
  {
    "name": "Toggle Target Video 2",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Target Video 2",
    "desc": "Lệnh trong menu Application > Toggle Target Video 2",
    "cmd": "Toggle Target Video 2"
  },
  {
    "name": "Toggle Target Video 3",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Target Video 3",
    "desc": "Lệnh trong menu Application > Toggle Target Video 3",
    "cmd": "Toggle Target Video 3"
  },
  {
    "name": "Toggle Target Video 4",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Target Video 4",
    "desc": "Lệnh trong menu Application > Toggle Target Video 4",
    "cmd": "Toggle Target Video 4"
  },
  {
    "name": "Toggle Target Video 5",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Target Video 5",
    "desc": "Lệnh trong menu Application > Toggle Target Video 5",
    "cmd": "Toggle Target Video 5"
  },
  {
    "name": "Toggle Target Video 6",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Target Video 6",
    "desc": "Lệnh trong menu Application > Toggle Target Video 6",
    "cmd": "Toggle Target Video 6"
  },
  {
    "name": "Toggle Target Video 7",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Target Video 7",
    "desc": "Lệnh trong menu Application > Toggle Target Video 7",
    "cmd": "Toggle Target Video 7"
  },
  {
    "name": "Toggle Target Video 8",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Target Video 8",
    "desc": "Lệnh trong menu Application > Toggle Target Video 8",
    "cmd": "Toggle Target Video 8"
  },
  {
    "name": "Toggle Track Output for All Targeted Video Tracks",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Track Output for All Targeted Video Tracks",
    "desc": "Lệnh trong menu Application > Toggle Track Output for All Targeted Video Tracks",
    "cmd": "Toggle Track Output for All Targeted Video Tracks"
  },
  {
    "name": "Toggle Transform Direct Manipulation",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Toggle Transform Direct Manipulation",
    "desc": "Lệnh trong menu Application > Toggle Transform Direct Manipulation",
    "cmd": "Toggle Transform Direct Manipulation"
  },
  {
    "name": "Toggle Trim Type",
    "key": "Ctrl+Shift+T",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Toggle Trim Type",
    "desc": "Chuyển đổi kiểu trim (Ripple, Roll, Regular)",
    "cmd": "Toggle Trim Type"
  },
  {
    "name": "Track Height Preset 1",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 1",
    "desc": "Lệnh trong menu Application > Track Height Preset 1",
    "cmd": "Track Height Preset 1"
  },
  {
    "name": "Track Height Preset 2",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 2",
    "desc": "Lệnh trong menu Application > Track Height Preset 2",
    "cmd": "Track Height Preset 2"
  },
  {
    "name": "Track Height Preset 3",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 3",
    "desc": "Lệnh trong menu Application > Track Height Preset 3",
    "cmd": "Track Height Preset 3"
  },
  {
    "name": "Track Height Preset 4",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 4",
    "desc": "Lệnh trong menu Application > Track Height Preset 4",
    "cmd": "Track Height Preset 4"
  },
  {
    "name": "Track Height Preset 5",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 5",
    "desc": "Lệnh trong menu Application > Track Height Preset 5",
    "cmd": "Track Height Preset 5"
  },
  {
    "name": "Track Height Preset 6",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 6",
    "desc": "Lệnh trong menu Application > Track Height Preset 6",
    "cmd": "Track Height Preset 6"
  },
  {
    "name": "Track Height Preset 7",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 7",
    "desc": "Lệnh trong menu Application > Track Height Preset 7",
    "cmd": "Track Height Preset 7"
  },
  {
    "name": "Track Height Preset 8",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 8",
    "desc": "Lệnh trong menu Application > Track Height Preset 8",
    "cmd": "Track Height Preset 8"
  },
  {
    "name": "Track Height Preset 9",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 9",
    "desc": "Lệnh trong menu Application > Track Height Preset 9",
    "cmd": "Track Height Preset 9"
  },
  {
    "name": "Track Height Preset 10",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Track Height Preset 10",
    "desc": "Lệnh trong menu Application > Track Height Preset 10",
    "cmd": "Track Height Preset 10"
  },
  {
    "name": "Track mask",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Track mask",
    "desc": "Lệnh trong menu Application > Track mask",
    "cmd": "Track mask"
  },
  {
    "name": "Transmit Multi-Camera View",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Application > Transmit Multi-Camera View",
    "desc": "Lệnh trong menu Application > Transmit Multi-Camera View",
    "cmd": "Transmit Multi-Camera View"
  },
  {
    "name": "Trim Backward",
    "key": "Ctrl+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Trim Backward",
    "desc": "Trim lùi 1 frame",
    "cmd": "Trim Backward"
  },
  {
    "name": "Trim Backward Many",
    "key": "Ctrl+Shift+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Trim Backward Many",
    "desc": "Trim lùi 5 frame",
    "cmd": "Trim Backward Many"
  },
  {
    "name": "Trim Forward",
    "key": "Ctrl+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Trim Forward",
    "desc": "Trim tới 1 frame",
    "cmd": "Trim Forward"
  },
  {
    "name": "Trim Forward Many",
    "key": "Ctrl+Shift+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Trim Forward Many",
    "desc": "Trim tới 5 frame",
    "cmd": "Trim Forward Many"
  },
  {
    "name": "Trim Next Edit to Playhead",
    "key": "Ctrl+Alt+W",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Trim Next Edit to Playhead",
    "desc": "Cắt đuôi clip tới playhead (Ctrl+Alt+W)",
    "cmd": "Trim Next Edit to Playhead"
  },
  {
    "name": "Trim Previous Edit to Playhead",
    "key": "Ctrl+Alt+Q",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Application > Trim Previous Edit to Playhead",
    "desc": "Cắt đầu clip tới playhead (Ctrl+Alt+Q)",
    "cmd": "Trim Previous Edit to Playhead"
  },
  {
    "name": "Unassign mask",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Unassign mask",
    "desc": "Lệnh trong menu Application > Unassign mask",
    "cmd": "Unassign mask"
  },
  {
    "name": "Underline",
    "key": "",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Underline",
    "desc": "Lệnh trong menu Application > Underline",
    "cmd": "Underline"
  },
  {
    "name": "Workspace 1",
    "key": "Alt+Shift+1",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 1",
    "desc": "Chuyển sang Workspace 1",
    "cmd": "Workspace 1"
  },
  {
    "name": "Workspace 2",
    "key": "Alt+Shift+2",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 2",
    "desc": "Chuyển sang Workspace 2",
    "cmd": "Workspace 2"
  },
  {
    "name": "Workspace 3",
    "key": "Alt+Shift+3",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 3",
    "desc": "Chuyển sang Workspace 3",
    "cmd": "Workspace 3"
  },
  {
    "name": "Workspace 4",
    "key": "Alt+Shift+4",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 4",
    "desc": "Chuyển sang Workspace 4",
    "cmd": "Workspace 4"
  },
  {
    "name": "Workspace 5",
    "key": "Alt+Shift+5",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 5",
    "desc": "Chuyển sang Workspace 5",
    "cmd": "Workspace 5"
  },
  {
    "name": "Workspace 6",
    "key": "Alt+Shift+6",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 6",
    "desc": "Chuyển sang Workspace 6",
    "cmd": "Workspace 6"
  },
  {
    "name": "Workspace 7",
    "key": "Alt+Shift+7",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 7",
    "desc": "Chuyển sang Workspace 7",
    "cmd": "Workspace 7"
  },
  {
    "name": "Workspace 8",
    "key": "Alt+Shift+8",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 8",
    "desc": "Chuyển sang Workspace 8",
    "cmd": "Workspace 8"
  },
  {
    "name": "Workspace 9",
    "key": "Alt+Shift+9",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Application > Workspace 9",
    "desc": "Chuyển sang Workspace 9",
    "cmd": "Workspace 9"
  },
  {
    "name": "Zoom Program Monitor to 100%",
    "key": "Ctrl+Shift+1",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Zoom Program Monitor to 100%",
    "desc": "Zoom Program Monitor về kích thước thực 100%",
    "cmd": "Zoom Program Monitor to 100%"
  },
  {
    "name": "Zoom Program Monitor to Fit",
    "key": "Ctrl+Shift+0",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Zoom Program Monitor to Fit",
    "desc": "Zoom Program Monitor vừa khít khung nhìn",
    "cmd": "Zoom Program Monitor to Fit"
  },
  {
    "name": "Zoom Source Monitor to 100%",
    "key": "Ctrl+Alt+Shift+1",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Zoom Source Monitor to 100%",
    "desc": "Zoom Source Monitor về kích thước thực 100%",
    "cmd": "Zoom Source Monitor to 100%"
  },
  {
    "name": "Zoom Source Monitor to Fit",
    "key": "Ctrl+Alt+Shift+0",
    "cat": "view",
    "catName": "View & Màn hình Monitor",
    "path": "Application > Zoom Source Monitor to Fit",
    "desc": "Zoom Source Monitor vừa khít khung nhìn",
    "cmd": "Zoom Source Monitor to Fit"
  },
  {
    "name": "Zoom to Frame",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Application > Zoom to Frame",
    "desc": "Lệnh trong menu Application > Zoom to Frame",
    "cmd": "Zoom to Frame"
  },
  {
    "name": "Zoom to Sequence",
    "key": "\\",
    "cat": "general",
    "catName": "Tính năng khác",
    "path": "Application > Zoom to Sequence",
    "desc": "Zoom toàn bộ sequence vừa khít timeline",
    "cmd": "Zoom to Sequence"
  },
  {
    "name": "Keyframe Mode Latch",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Audio Clip Mixer Panel > Audio Clip Mixer Panel Menu > Keyframe Mode Latch",
    "desc": "Tính năng trong bảng Audio Clip Mixer Panel Menu",
    "cmd": "Keyframe Mode Latch"
  },
  {
    "name": "Keyframe Mode Touch",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Audio Clip Mixer Panel > Audio Clip Mixer Panel Menu > Keyframe Mode Touch",
    "desc": "Tính năng trong bảng Audio Clip Mixer Panel Menu",
    "cmd": "Keyframe Mode Touch"
  },
  {
    "name": "Show/Hide Tracks...",
    "key": "Ctrl+Alt+T",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Audio Track Mixer Panel > Audio Track Mixer Panel Menu > Show/Hide Tracks...",
    "desc": "Tính năng trong bảng Audio Track Mixer Panel Menu",
    "cmd": "Show/Hide Tracks..."
  },
  {
    "name": "Show Audio Time Units",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Audio Track Mixer Panel > Audio Track Mixer Panel Menu > Show Audio Time Units",
    "desc": "Tính năng trong bảng Audio Track Mixer Panel Menu",
    "cmd": "Show Audio Time Units"
  },
  {
    "name": "Loop",
    "key": "Ctrl+L",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Audio Track Mixer Panel > Audio Track Mixer Panel Menu > Loop",
    "desc": "Tính năng trong bảng Audio Track Mixer Panel Menu",
    "cmd": "Loop"
  },
  {
    "name": "Meter Input(s) Only",
    "key": "Ctrl+Shift+I",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Audio Track Mixer Panel > Audio Track Mixer Panel Menu > Meter Input(s) Only",
    "desc": "Tính năng trong bảng Audio Track Mixer Panel Menu",
    "cmd": "Meter Input(s) Only"
  },
  {
    "name": "Switch to Touch after Write",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Audio Track Mixer Panel > Audio Track Mixer Panel Menu > Switch to Touch after Write",
    "desc": "Tính năng trong bảng Audio Track Mixer Panel Menu",
    "cmd": "Switch to Touch after Write"
  },
  {
    "name": "Save Preset...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Save Preset...",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Save Preset..."
  },
  {
    "name": "Effect Enabled",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Effect Enabled",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Effect Enabled"
  },
  {
    "name": "Remove Selected Effect",
    "key": "Backspace",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Remove Selected Effect",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Remove Selected Effect"
  },
  {
    "name": "Remove Effects...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Remove Effects...",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Remove Effects..."
  },
  {
    "name": "Snap",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Snap",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Snap"
  },
  {
    "name": "Video Keyframes",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Snap To > Video Keyframes",
    "desc": "Tính năng trong bảng Snap To",
    "cmd": "Video Keyframes"
  },
  {
    "name": "Audio Keyframes",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Snap To > Audio Keyframes",
    "desc": "Tính năng trong bảng Snap To",
    "cmd": "Audio Keyframes"
  },
  {
    "name": "Sequence Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Snap To > Sequence Markers",
    "desc": "Tính năng trong bảng Snap To",
    "cmd": "Sequence Markers"
  },
  {
    "name": "Playhead",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Snap To > Playhead",
    "desc": "Tính năng trong bảng Snap To",
    "cmd": "Playhead"
  },
  {
    "name": "Clip",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Snap To > Clip",
    "desc": "Tính năng trong bảng Snap To",
    "cmd": "Clip"
  },
  {
    "name": "All",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Snap To > All",
    "desc": "Tính năng trong bảng Snap To",
    "cmd": "All"
  },
  {
    "name": "None",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Snap To > None",
    "desc": "Tính năng trong bảng Snap To",
    "cmd": "None"
  },
  {
    "name": "Show Audio Time Units",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Show Audio Time Units",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Show Audio Time Units"
  },
  {
    "name": "Time Ruler Numbers",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Time Ruler Numbers",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Time Ruler Numbers"
  },
  {
    "name": "Loop During Audio-Only Playback",
    "key": "Ctrl+L",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Loop During Audio-Only Playback",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Loop During Audio-Only Playback"
  },
  {
    "name": "Pin to Clip",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Effect Controls Panel Menu > Pin to Clip",
    "desc": "Tính năng trong bảng Effect Controls Panel Menu",
    "cmd": "Pin to Clip"
  },
  {
    "name": "Expand Audio Effects",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Effect Controls Panel > Expand Audio Effects",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Expand Audio Effects"
  },
  {
    "name": "Expand Video Effects",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Expand Video Effects",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Expand Video Effects"
  },
  {
    "name": "Keyframe Spatial Interpolation - Auto Bezier",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Spatial Interpolation - Auto Bezier",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Spatial Interpolation - Auto Bezier"
  },
  {
    "name": "Keyframe Spatial Interpolation - Bezier",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Spatial Interpolation - Bezier",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Spatial Interpolation - Bezier"
  },
  {
    "name": "Keyframe Spatial Interpolation - Continuous Bezier",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Spatial Interpolation - Continuous Bezier",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Spatial Interpolation - Continuous Bezier"
  },
  {
    "name": "Keyframe Spatial Interpolation - Linear",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Spatial Interpolation - Linear",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Spatial Interpolation - Linear"
  },
  {
    "name": "Keyframe Temporal Interpolation - Auto Bezier",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Temporal Interpolation - Auto Bezier",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Temporal Interpolation - Auto Bezier"
  },
  {
    "name": "Keyframe Temporal Interpolation - Bezier",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Temporal Interpolation - Bezier",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Temporal Interpolation - Bezier"
  },
  {
    "name": "Keyframe Temporal Interpolation - Continuous Bezier",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Temporal Interpolation - Continuous Bezier",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Temporal Interpolation - Continuous Bezier"
  },
  {
    "name": "Keyframe Temporal Interpolation - Ease In",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Temporal Interpolation - Ease In",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Temporal Interpolation - Ease In"
  },
  {
    "name": "Keyframe Temporal Interpolation - Ease Out",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Temporal Interpolation - Ease Out",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Temporal Interpolation - Ease Out"
  },
  {
    "name": "Keyframe Temporal Interpolation - Hold",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Temporal Interpolation - Hold",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Temporal Interpolation - Hold"
  },
  {
    "name": "Keyframe Temporal Interpolation - Linear",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effect Controls Panel > Keyframe Temporal Interpolation - Linear",
    "desc": "Tính năng trong bảng Effect Controls Panel",
    "cmd": "Keyframe Temporal Interpolation - Linear"
  },
  {
    "name": "New Custom Bin",
    "key": "Ctrl+/",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effects Panel > Effects Panel Menu > New Custom Bin",
    "desc": "Tính năng trong bảng Effects Panel Menu",
    "cmd": "New Custom Bin"
  },
  {
    "name": "New Presets Bin",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effects Panel > Effects Panel Menu > New Presets Bin",
    "desc": "Tính năng trong bảng Effects Panel Menu",
    "cmd": "New Presets Bin"
  },
  {
    "name": "Delete Custom Item",
    "key": "Backspace",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effects Panel > Effects Panel Menu > Delete Custom Item",
    "desc": "Tính năng trong bảng Effects Panel Menu",
    "cmd": "Delete Custom Item"
  },
  {
    "name": "Set Selected as Default Transition",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effects Panel > Effects Panel Menu > Set Selected as Default Transition",
    "desc": "Tính năng trong bảng Effects Panel Menu",
    "cmd": "Set Selected as Default Transition"
  },
  {
    "name": "Import Presets...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effects Panel > Effects Panel Menu > Import Presets...",
    "desc": "Tính năng trong bảng Effects Panel Menu",
    "cmd": "Import Presets..."
  },
  {
    "name": "Export Presets...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effects Panel > Effects Panel Menu > Export Presets...",
    "desc": "Tính năng trong bảng Effects Panel Menu",
    "cmd": "Export Presets..."
  },
  {
    "name": "Preset Properties...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effects Panel > Effects Panel Menu > Preset Properties...",
    "desc": "Tính năng trong bảng Effects Panel Menu",
    "cmd": "Preset Properties..."
  },
  {
    "name": "Dynamic Lumetri Preset Previews",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Effects Panel > Effects Panel Menu > Dynamic Lumetri Preset Previews",
    "desc": "Tính năng trong bảng Effects Panel Menu",
    "cmd": "Dynamic Lumetri Preset Previews"
  },
  {
    "name": "Step Backward",
    "key": "Left",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > History Panel > History Panel Menu > Step Backward",
    "desc": "Tính năng trong bảng History Panel Menu",
    "cmd": "Step Backward"
  },
  {
    "name": "Step Forward",
    "key": "Right",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > History Panel > History Panel Menu > Step Forward",
    "desc": "Tính năng trong bảng History Panel Menu",
    "cmd": "Step Forward"
  },
  {
    "name": "Delete",
    "key": "Backspace",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > History Panel > History Panel Menu > Delete",
    "desc": "Tính năng trong bảng History Panel Menu",
    "cmd": "Delete"
  },
  {
    "name": "Clear History",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > History Panel > History Panel Menu > Clear History",
    "desc": "Tính năng trong bảng History Panel Menu",
    "cmd": "Clear History"
  },
  {
    "name": "Settings...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > History Panel > History Panel Menu > Settings...",
    "desc": "Tính năng trong bảng History Panel Menu",
    "cmd": "Settings..."
  },
  {
    "name": "Open Clip",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Libraries Panel > Open Clip",
    "desc": "Tính năng trong bảng Libraries Panel",
    "cmd": "Open Clip"
  },
  {
    "name": "Solo Mode",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Lumetri Color Panel > Lumetri Color Panel Menu > Solo Mode",
    "desc": "Tính năng trong bảng Lumetri Color Panel Menu",
    "cmd": "Solo Mode"
  },
  {
    "name": "Export .look...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Lumetri Color Panel > Lumetri Color Panel Menu > Export .look...",
    "desc": "Tính năng trong bảng Lumetri Color Panel Menu",
    "cmd": "Export .look..."
  },
  {
    "name": "Export .cube...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Lumetri Color Panel > Lumetri Color Panel Menu > Export .cube...",
    "desc": "Tính năng trong bảng Lumetri Color Panel Menu",
    "cmd": "Export .cube..."
  },
  {
    "name": "Save Preset...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Lumetri Color Panel > Lumetri Color Panel Menu > Save Preset...",
    "desc": "Tính năng trong bảng Lumetri Color Panel Menu",
    "cmd": "Save Preset..."
  },
  {
    "name": "Bypass Lumetri Color Effects",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Lumetri Color Panel > Bypass Lumetri Color Effects",
    "desc": "Tính năng trong bảng Lumetri Color Panel",
    "cmd": "Bypass Lumetri Color Effects"
  },
  {
    "name": "Show All Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Markers Panel > Markers Panel Menu > Show All Markers",
    "desc": "Tính năng trong bảng Markers Panel Menu",
    "cmd": "Show All Markers"
  },
  {
    "name": "Show Sequence Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Markers Panel > Markers Panel Menu > Show Sequence Markers",
    "desc": "Tính năng trong bảng Markers Panel Menu",
    "cmd": "Show Sequence Markers"
  },
  {
    "name": "Show Clip Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Markers Panel > Markers Panel Menu > Show Clip Markers",
    "desc": "Tính năng trong bảng Markers Panel Menu",
    "cmd": "Show Clip Markers"
  },
  {
    "name": "Ignore Selection in Timeline",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Markers Panel > Markers Panel Menu > Ignore Selection in Timeline",
    "desc": "Tính năng trong bảng Markers Panel Menu",
    "cmd": "Ignore Selection in Timeline"
  },
  {
    "name": "Show In and Out",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Markers Panel > Markers Panel Menu > Show In and Out",
    "desc": "Tính năng trong bảng Markers Panel Menu",
    "cmd": "Show In and Out"
  },
  {
    "name": "Next Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Markers Panel > Next Marker",
    "desc": "Tính năng trong bảng Markers Panel",
    "cmd": "Next Marker"
  },
  {
    "name": "Previous Marker",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Markers Panel > Previous Marker",
    "desc": "Tính năng trong bảng Markers Panel",
    "cmd": "Previous Marker"
  },
  {
    "name": "Edit Columns...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Media Browser Panel Menu > Edit Columns...",
    "desc": "Tính năng trong bảng Media Browser Panel Menu",
    "cmd": "Edit Columns..."
  },
  {
    "name": "Import as Image Sequence",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Media Browser Panel Menu > Import as Image Sequence",
    "desc": "Tính năng trong bảng Media Browser Panel Menu",
    "cmd": "Import as Image Sequence"
  },
  {
    "name": "Hover Scrub",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Media Browser Panel Menu > Hover Scrub",
    "desc": "Bật/tắt xem nhanh video khi rê chuột qua thumbnail (Shift+H)",
    "cmd": "Hover Scrub"
  },
  {
    "name": "New Media Browser Panel",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Media Browser Panel > Media Browser Panel Menu > New Media Browser Panel",
    "desc": "Tính năng trong bảng Media Browser Panel Menu",
    "cmd": "New Media Browser Panel"
  },
  {
    "name": "Create Folder For Imported Projects",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Media Browser Panel Menu > Create Folder For Imported Projects",
    "desc": "Tính năng trong bảng Media Browser Panel Menu",
    "cmd": "Create Folder For Imported Projects"
  },
  {
    "name": "Allow Duplicate Media During Project Import",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Media Browser Panel Menu > Allow Duplicate Media During Project Import",
    "desc": "Tính năng trong bảng Media Browser Panel Menu",
    "cmd": "Allow Duplicate Media During Project Import"
  },
  {
    "name": "Refresh",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Media Browser Panel Menu > Refresh",
    "desc": "Tính năng trong bảng Media Browser Panel Menu",
    "cmd": "Refresh"
  },
  {
    "name": "Add to Favorites",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Add to Favorites",
    "desc": "Tính năng trong bảng Media Browser Panel",
    "cmd": "Add to Favorites"
  },
  {
    "name": "Clear Recent Directories",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Clear Recent Directories",
    "desc": "Tính năng trong bảng Media Browser Panel",
    "cmd": "Clear Recent Directories"
  },
  {
    "name": "Import",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Import",
    "desc": "Tính năng trong bảng Media Browser Panel",
    "cmd": "Import"
  },
  {
    "name": "Open In Source Monitor",
    "key": "Shift+O",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Open In Source Monitor",
    "desc": "Tính năng trong bảng Media Browser Panel",
    "cmd": "Open In Source Monitor"
  },
  {
    "name": "Open Project",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Open Project",
    "desc": "Tính năng trong bảng Media Browser Panel",
    "cmd": "Open Project"
  },
  {
    "name": "Remove from Favorites",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Remove from Favorites",
    "desc": "Tính năng trong bảng Media Browser Panel",
    "cmd": "Remove from Favorites"
  },
  {
    "name": "Select Directory List",
    "key": "Shift+Left",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Select Directory List",
    "desc": "Tính năng trong bảng Media Browser Panel",
    "cmd": "Select Directory List"
  },
  {
    "name": "Select Media List",
    "key": "Shift+Right",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Media Browser Panel > Select Media List",
    "desc": "Tính năng trong bảng Media Browser Panel",
    "cmd": "Select Media List"
  },
  {
    "name": "Metadata Display...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Metadata Panel > Metadata Panel Menu > Metadata Display...",
    "desc": "Tính năng trong bảng Metadata Panel Menu",
    "cmd": "Metadata Display..."
  },
  {
    "name": "Loop",
    "key": "Ctrl+L",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Metadata Panel > Loop",
    "desc": "Tính năng trong bảng Metadata Panel",
    "cmd": "Loop"
  },
  {
    "name": "Next Matching Word",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Metadata Panel > Next Matching Word",
    "desc": "Tính năng trong bảng Metadata Panel",
    "cmd": "Next Matching Word"
  },
  {
    "name": "Play",
    "key": "Space",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Metadata Panel > Play",
    "desc": "Tính năng trong bảng Metadata Panel",
    "cmd": "Play"
  },
  {
    "name": "Play In to Out",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Metadata Panel > Play In to Out",
    "desc": "Phát từ điểm In tới điểm Out",
    "cmd": "Play In to Out"
  },
  {
    "name": "Previous Matching Word",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Metadata Panel > Previous Matching Word",
    "desc": "Tính năng trong bảng Metadata Panel",
    "cmd": "Previous Matching Word"
  },
  {
    "name": "New Project...",
    "key": "Ctrl+Alt+N",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Production Panel Menu > New Project...",
    "desc": "Tính năng trong bảng Production Panel Menu",
    "cmd": "New Project..."
  },
  {
    "name": "New Folder...",
    "key": "Ctrl+B",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Production Panel Menu > New Folder...",
    "desc": "Tính năng trong bảng Production Panel Menu",
    "cmd": "New Folder..."
  },
  {
    "name": "Add Project To Production...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Production Panel Menu > Add Project To Production...",
    "desc": "Tính năng trong bảng Production Panel Menu",
    "cmd": "Add Project To Production..."
  },
  {
    "name": "Rename Production...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Production Panel Menu > Rename Production...",
    "desc": "Tính năng trong bảng Production Panel Menu",
    "cmd": "Rename Production..."
  },
  {
    "name": "Refresh All Projects",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Production Panel Menu > Refresh All Projects",
    "desc": "Tính năng trong bảng Production Panel Menu",
    "cmd": "Refresh All Projects"
  },
  {
    "name": "Save All Projects",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Production Panel Menu > Save All Projects",
    "desc": "Tính năng trong bảng Production Panel Menu",
    "cmd": "Save All Projects"
  },
  {
    "name": "Close All Projects",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Production Panel Menu > Close All Projects",
    "desc": "Tính năng trong bảng Production Panel Menu",
    "cmd": "Close All Projects"
  },
  {
    "name": "Reveal Production in Explorer",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Production Panel Menu > Reveal Production in Explorer",
    "desc": "Tính năng trong bảng Production Panel Menu",
    "cmd": "Reveal Production in Explorer"
  },
  {
    "name": "Close Project",
    "key": "Ctrl+Shift+W",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Close Project",
    "desc": "Đóng project hiện tại",
    "cmd": "Close Project"
  },
  {
    "name": "Make a Copy",
    "key": "Ctrl+Shift+/",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Make a Copy",
    "desc": "Tính năng trong bảng Production Panel",
    "cmd": "Make a Copy"
  },
  {
    "name": "Move Selection End",
    "key": "End",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Move Selection End",
    "desc": "Tính năng trong bảng Production Panel",
    "cmd": "Move Selection End"
  },
  {
    "name": "Move Selection Home",
    "key": "Home",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Move Selection Home",
    "desc": "Tính năng trong bảng Production Panel",
    "cmd": "Move Selection Home"
  },
  {
    "name": "Move Selection Page Down",
    "key": "Page Down",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Move Selection Page Down",
    "desc": "Tính năng trong bảng Production Panel",
    "cmd": "Move Selection Page Down"
  },
  {
    "name": "Move Selection Page Up",
    "key": "Page Up",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Move Selection Page Up",
    "desc": "Tính năng trong bảng Production Panel",
    "cmd": "Move Selection Page Up"
  },
  {
    "name": "Move To Trash",
    "key": "Ctrl+Backspace",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Move To Trash",
    "desc": "Tính năng trong bảng Production Panel",
    "cmd": "Move To Trash"
  },
  {
    "name": "Open Project",
    "key": "Ctrl+O",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Open Project",
    "desc": "Tính năng trong bảng Production Panel",
    "cmd": "Open Project"
  },
  {
    "name": "Zoom In",
    "key": "=",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Zoom In",
    "desc": "Phóng to timeline hoặc monitor",
    "cmd": "Zoom In"
  },
  {
    "name": "Zoom Out",
    "key": "-",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Production Panel > Zoom Out",
    "desc": "Thu nhỏ timeline hoặc monitor",
    "cmd": "Zoom Out"
  },
  {
    "name": "Composite Video",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Composite Video",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Composite Video"
  },
  {
    "name": "Alpha",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > RGBA Channels > Alpha",
    "desc": "Tính năng trong bảng RGBA Channels",
    "cmd": "Alpha"
  },
  {
    "name": "Red",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > RGBA Channels > Red",
    "desc": "Tính năng trong bảng RGBA Channels",
    "cmd": "Red"
  },
  {
    "name": "Green",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > RGBA Channels > Green",
    "desc": "Tính năng trong bảng RGBA Channels",
    "cmd": "Green"
  },
  {
    "name": "Blue",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > RGBA Channels > Blue",
    "desc": "Tính năng trong bảng RGBA Channels",
    "cmd": "Blue"
  },
  {
    "name": "Multi-Camera",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Multi-Camera",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Multi-Camera"
  },
  {
    "name": "Display First Field",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Display First Field",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Display First Field"
  },
  {
    "name": "Display Second Field",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Display Second Field",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Display Second Field"
  },
  {
    "name": "Display Both Fields",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Display Both Fields",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Display Both Fields"
  },
  {
    "name": "Full",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Playback Resolution > Full",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "Full"
  },
  {
    "name": "1/2",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Playback Resolution > 1/2",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "1/2"
  },
  {
    "name": "1/4",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Playback Resolution > 1/4",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "1/4"
  },
  {
    "name": "1/8",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Playback Resolution > 1/8",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "1/8"
  },
  {
    "name": "1/16",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Playback Resolution > 1/16",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "1/16"
  },
  {
    "name": "Full",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Paused Resolution > Full",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "Full"
  },
  {
    "name": "1/2",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Paused Resolution > 1/2",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "1/2"
  },
  {
    "name": "1/4",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Paused Resolution > 1/4",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "1/4"
  },
  {
    "name": "1/8",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Paused Resolution > 1/8",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "1/8"
  },
  {
    "name": "1/16",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Paused Resolution > 1/16",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "1/16"
  },
  {
    "name": "High Quality Playback",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > High Quality Playback",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "High Quality Playback"
  },
  {
    "name": "Timecode Overlay During Edit",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Timecode Overlay During Edit",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Timecode Overlay During Edit"
  },
  {
    "name": "Show Transport Controls",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Show Transport Controls",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Show Transport Controls"
  },
  {
    "name": "Show Scroll Bars",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Show Scroll Bars",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Show Scroll Bars"
  },
  {
    "name": "Show Audio Time Units",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Show Audio Time Units",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Show Audio Time Units"
  },
  {
    "name": "Show Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Show Markers",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Show Markers"
  },
  {
    "name": "Show Dropped Frame Indicator",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Show Dropped Frame Indicator",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Show Dropped Frame Indicator"
  },
  {
    "name": "Time Ruler Numbers",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Time Ruler Numbers",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Time Ruler Numbers"
  },
  {
    "name": "Show Rulers",
    "key": "Ctrl+R",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Show Rulers",
    "desc": "Hiện/ẩn thước kẻ căn chỉnh (Rulers)",
    "cmd": "Show Rulers"
  },
  {
    "name": "Show Guides",
    "key": "Ctrl+;",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Show Guides",
    "desc": "Hiện/ẩn đường gióng căn chỉnh (Guides)",
    "cmd": "Show Guides"
  },
  {
    "name": "Snap in Program Monitor",
    "key": "Ctrl+Shift+;",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Snap in Program Monitor",
    "desc": "Bật chế độ hít nam châm căn chỉnh trên Program Monitor",
    "cmd": "Snap in Program Monitor"
  },
  {
    "name": "Show Multi-Camera Preview Monitor",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Show Multi-Camera Preview Monitor",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Show Multi-Camera Preview Monitor"
  },
  {
    "name": "Auto-Adjust Multi-Camera Playback Quality",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Auto-Adjust Multi-Camera Playback Quality",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Auto-Adjust Multi-Camera Playback Quality"
  },
  {
    "name": "Edit Cameras...",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Panels > Program Monitor Panel > Program Monitor Panel Menu > Edit Cameras...",
    "desc": "Tính năng trong bảng Program Monitor Panel Menu",
    "cmd": "Edit Cameras..."
  },
  {
    "name": "Add Guide",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Add Guide",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Add Guide"
  },
  {
    "name": "Clear Guides",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Clear Guides",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Clear Guides"
  },
  {
    "name": "Comparison View",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Comparison View",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Comparison View"
  },
  {
    "name": "Global FX Mute",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Global FX Mute",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Global FX Mute"
  },
  {
    "name": "Lock Guides",
    "key": "Ctrl+Alt+Shift+R",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Lock Guides",
    "desc": "Khóa cố định các đường gióng",
    "cmd": "Lock Guides"
  },
  {
    "name": "Manage Guides",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Manage Guides",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Manage Guides"
  },
  {
    "name": "Monitor Ambisonics",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Monitor Ambisonics",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Monitor Ambisonics"
  },
  {
    "name": "Nudge Selected Object down by five",
    "key": "Ctrl+Shift+Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Program Monitor Panel > Nudge Selected Object down by five",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Nudge Selected Object down by five"
  },
  {
    "name": "Nudge Selected Object down by one",
    "key": "Ctrl+Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Program Monitor Panel > Nudge Selected Object down by one",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Nudge Selected Object down by one"
  },
  {
    "name": "Nudge Selected Object to left by five",
    "key": "Ctrl+Shift+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Program Monitor Panel > Nudge Selected Object to left by five",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Nudge Selected Object to left by five"
  },
  {
    "name": "Nudge Selected Object to left by one",
    "key": "Ctrl+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Program Monitor Panel > Nudge Selected Object to left by one",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Nudge Selected Object to left by one"
  },
  {
    "name": "Nudge Selected Object to right by five",
    "key": "Ctrl+Shift+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Program Monitor Panel > Nudge Selected Object to right by five",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Nudge Selected Object to right by five"
  },
  {
    "name": "Nudge Selected Object to right by one",
    "key": "Ctrl+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Program Monitor Panel > Nudge Selected Object to right by one",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Nudge Selected Object to right by one"
  },
  {
    "name": "Nudge Selected Object up by five",
    "key": "Ctrl+Shift+Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Program Monitor Panel > Nudge Selected Object up by five",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Nudge Selected Object up by five"
  },
  {
    "name": "Nudge Selected Object up by one",
    "key": "Ctrl+Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Program Monitor Panel > Nudge Selected Object up by one",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Nudge Selected Object up by one"
  },
  {
    "name": "Percentages",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Percentages",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Percentages"
  },
  {
    "name": "Pixels",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Pixels",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Pixels"
  },
  {
    "name": "Play-Stop Toggle",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Program Monitor Panel > Play-Stop Toggle",
    "desc": "Phát hoặc dừng video (Space)",
    "cmd": "Play-Stop Toggle"
  },
  {
    "name": "Safe Margins",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Safe Margins",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Safe Margins"
  },
  {
    "name": "Save Guides as Template",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Save Guides as Template",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Save Guides as Template"
  },
  {
    "name": "Step Back",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Program Monitor Panel > Step Back",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Step Back"
  },
  {
    "name": "Step Forward",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Program Monitor Panel > Step Forward",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Step Forward"
  },
  {
    "name": "Toggle Grade",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Toggle Grade",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Toggle Grade"
  },
  {
    "name": "Toggle Transparency Grid",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Toggle Transparency Grid",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Toggle Transparency Grid"
  },
  {
    "name": "Toggle VR Video Display",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Toggle VR Video Display",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Toggle VR Video Display"
  },
  {
    "name": "Toggle mask bounding box",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Toggle mask bounding box",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Toggle mask bounding box"
  },
  {
    "name": "VR Video - Hide Controls",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > VR Video - Hide Controls",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "VR Video - Hide Controls"
  },
  {
    "name": "VR Video Display Settings",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > VR Video Display Settings",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "VR Video Display Settings"
  },
  {
    "name": "Zoom Monitor In",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Zoom Monitor In",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Zoom Monitor In"
  },
  {
    "name": "Zoom Monitor Out",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Program Monitor Panel > Zoom Monitor Out",
    "desc": "Tính năng trong bảng Program Monitor Panel",
    "cmd": "Zoom Monitor Out"
  },
  {
    "name": "Close Project",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Close Project",
    "desc": "Đóng project hiện tại",
    "cmd": "Close Project"
  },
  {
    "name": "Save Project",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Save Project",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Save Project"
  },
  {
    "name": "Refresh Project",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Refresh Project",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Refresh Project"
  },
  {
    "name": "New Bin",
    "key": "Ctrl+B",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > New Bin",
    "desc": "Tạo thư mục bin mới trong project (Ctrl+B)",
    "cmd": "New Bin"
  },
  {
    "name": "New Bin From Selection",
    "key": "Shift+B",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > New Bin From Selection",
    "desc": "Gom các clip đang chọn vào bin mới (Shift+B)",
    "cmd": "New Bin From Selection"
  },
  {
    "name": "New Search Bin",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > New Search Bin",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "New Search Bin"
  },
  {
    "name": "Rename",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Rename",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Rename"
  },
  {
    "name": "Delete",
    "key": "Backspace",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Delete",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Delete"
  },
  {
    "name": "Automate to Sequence...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Automate to Sequence...",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Automate to Sequence..."
  },
  {
    "name": "Find...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Find...",
    "desc": "Tìm kiếm clip hoặc text",
    "cmd": "Find..."
  },
  {
    "name": "List",
    "key": "Ctrl+Page Up",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > List",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "List"
  },
  {
    "name": "Icon",
    "key": "Ctrl+Page Down",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Icon",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Icon"
  },
  {
    "name": "Freeform",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Freeform",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Freeform"
  },
  {
    "name": "Preview Area",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Preview Area",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Preview Area"
  },
  {
    "name": "Thumbnails",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Thumbnails",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Thumbnails"
  },
  {
    "name": "Thumbnails show effects applied",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Thumbnails show effects applied",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Thumbnails show effects applied"
  },
  {
    "name": "Hover Scrub",
    "key": "Shift+H",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Hover Scrub",
    "desc": "Bật/tắt xem nhanh video khi rê chuột qua thumbnail (Shift+H)",
    "cmd": "Hover Scrub"
  },
  {
    "name": "Thumbnail controls for all pointing devices",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Thumbnail controls for all pointing devices",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Thumbnail controls for all pointing devices"
  },
  {
    "name": "Small",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Font Size > Small",
    "desc": "Tính năng trong bảng Font Size",
    "cmd": "Small"
  },
  {
    "name": "Medium (default)",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Font Size > Medium (default)",
    "desc": "Tính năng trong bảng Font Size",
    "cmd": "Medium (default)"
  },
  {
    "name": "Large",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Font Size > Large",
    "desc": "Tính năng trong bảng Font Size",
    "cmd": "Large"
  },
  {
    "name": "Extra Large",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Font Size > Extra Large",
    "desc": "Tính năng trong bảng Font Size",
    "cmd": "Extra Large"
  },
  {
    "name": "Refresh Sort Order",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Refresh Sort Order",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Refresh Sort Order"
  },
  {
    "name": "Metadata Display...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Metadata Display...",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Metadata Display..."
  },
  {
    "name": "Save Current View Preset",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Save Current View Preset",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Save Current View Preset"
  },
  {
    "name": "Save As New View Preset",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Save As New View Preset",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Save As New View Preset"
  },
  {
    "name": "Project View Preset 1",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 1",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 1"
  },
  {
    "name": "Project View Preset 2",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 2",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 2"
  },
  {
    "name": "Project View Preset 3",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 3",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 3"
  },
  {
    "name": "Project View Preset 4",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 4",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 4"
  },
  {
    "name": "Project View Preset 5",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 5",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 5"
  },
  {
    "name": "Project View Preset 6",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 6",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 6"
  },
  {
    "name": "Project View Preset 7",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 7",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 7"
  },
  {
    "name": "Project View Preset 8",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 8",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 8"
  },
  {
    "name": "Project View Preset 9",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 9",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 9"
  },
  {
    "name": "Project View Preset 10",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Restore View Preset > Project View Preset 10",
    "desc": "Tính năng trong bảng Restore View Preset",
    "cmd": "Project View Preset 10"
  },
  {
    "name": "Manage Saved View Presets",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Manage Saved View Presets",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Manage Saved View Presets"
  },
  {
    "name": "Freeform View Options...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Project Panel Menu > Freeform View Options...",
    "desc": "Tính năng trong bảng Project Panel Menu",
    "cmd": "Freeform View Options..."
  },
  {
    "name": "Align to Grid",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Align to Grid",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Align to Grid"
  },
  {
    "name": "Align to Grid - Sorted",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Align to Grid - Sorted",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Align to Grid - Sorted"
  },
  {
    "name": "Attach Proxies...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Attach Proxies...",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Attach Proxies..."
  },
  {
    "name": "Clip Size Next",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Clip Size Next",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Clip Size Next"
  },
  {
    "name": "Clip Size Previous",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Clip Size Previous",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Clip Size Previous"
  },
  {
    "name": "Create Proxies...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Create Proxies...",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Create Proxies..."
  },
  {
    "name": "Create Search Bin From Query",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Create Search Bin From Query",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Create Search Bin From Query"
  },
  {
    "name": "Delete Selection with Options",
    "key": "Ctrl+Delete",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Delete Selection with Options",
    "desc": "Xóa item kèm tùy chọn trong Project Panel (Ctrl+Delete)",
    "cmd": "Delete Selection with Options"
  },
  {
    "name": "Detach Proxies",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Detach Proxies",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Detach Proxies"
  },
  {
    "name": "Export Text Styles...",
    "key": "",
    "cat": "graphics",
    "catName": "Graphics & Chữ",
    "path": "Panels > Project Panel > Export Text Styles...",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Export Text Styles..."
  },
  {
    "name": "Extend Selection Down",
    "key": "Shift+Down",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Extend Selection Down",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Extend Selection Down"
  },
  {
    "name": "Extend Selection Left",
    "key": "Shift+Left",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Extend Selection Left",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Extend Selection Left"
  },
  {
    "name": "Extend Selection Right",
    "key": "Shift+Right",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Extend Selection Right",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Extend Selection Right"
  },
  {
    "name": "Extend Selection Up",
    "key": "Shift+Up",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Extend Selection Up",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Extend Selection Up"
  },
  {
    "name": "Go Back",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Go Back",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Go Back"
  },
  {
    "name": "Hide",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Hide",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Hide"
  },
  {
    "name": "Icon View Ascending Sort",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Icon View Ascending Sort",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Icon View Ascending Sort"
  },
  {
    "name": "Icon View Column List Sort",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Icon View Column List Sort",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Icon View Column List Sort"
  },
  {
    "name": "Icon View Descending Sort",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Icon View Descending Sort",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Icon View Descending Sort"
  },
  {
    "name": "Icon View Toggle Sort",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Icon View Toggle Sort",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Icon View Toggle Sort"
  },
  {
    "name": "Icon View User Order Sort",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Icon View User Order Sort",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Icon View User Order Sort"
  },
  {
    "name": "Move Selection Down",
    "key": "Down",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Move Selection Down",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Move Selection Down"
  },
  {
    "name": "Move Selection End",
    "key": "End",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Move Selection End",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Move Selection End"
  },
  {
    "name": "Move Selection Home",
    "key": "Home",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Move Selection Home",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Move Selection Home"
  },
  {
    "name": "Move Selection Left",
    "key": "Left",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Move Selection Left",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Move Selection Left"
  },
  {
    "name": "Move Selection Page Down",
    "key": "Page Down",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Move Selection Page Down",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Move Selection Page Down"
  },
  {
    "name": "Move Selection Page Up",
    "key": "Page Up",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Move Selection Page Up",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Move Selection Page Up"
  },
  {
    "name": "Move Selection Right",
    "key": "Right",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Move Selection Right",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Move Selection Right"
  },
  {
    "name": "Move Selection Up",
    "key": "Up",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Move Selection Up",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Move Selection Up"
  },
  {
    "name": "Next Column Field",
    "key": "Tab",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Next Column Field",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Next Column Field"
  },
  {
    "name": "Next Row Field",
    "key": "Enter",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Next Row Field",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Next Row Field"
  },
  {
    "name": "Open in Source Monitor",
    "key": "Shift+O",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Open in Source Monitor",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Open in Source Monitor"
  },
  {
    "name": "Open in Timeline",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Open in Timeline",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Open in Timeline"
  },
  {
    "name": "Previous Column Field",
    "key": "Shift+Tab",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Previous Column Field",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Previous Column Field"
  },
  {
    "name": "Previous Row Field",
    "key": "Shift+Enter",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Previous Row Field",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Previous Row Field"
  },
  {
    "name": "Reconnect Full Resolution Media...",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Reconnect Full Resolution Media...",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Reconnect Full Resolution Media..."
  },
  {
    "name": "Reveal In Project",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Reveal In Project",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Reveal In Project"
  },
  {
    "name": "Reveal Original",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Reveal Original",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Reveal Original"
  },
  {
    "name": "Reveal Project In Explorer",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Reveal Project In Explorer",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Reveal Project In Explorer"
  },
  {
    "name": "Reveal in Explorer",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Reveal in Explorer",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Reveal in Explorer"
  },
  {
    "name": "Scan for Content Credentials",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Scan for Content Credentials",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Scan for Content Credentials"
  },
  {
    "name": "Thumbnail Size Next",
    "key": "Shift+]",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Thumbnail Size Next",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Thumbnail Size Next"
  },
  {
    "name": "Thumbnail Size Previous",
    "key": "Shift+[",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Thumbnail Size Previous",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Thumbnail Size Previous"
  },
  {
    "name": "Toggle View",
    "key": "Shift+\\",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Toggle View",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Toggle View"
  },
  {
    "name": "Toggle side navigator",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Toggle side navigator",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "Toggle side navigator"
  },
  {
    "name": "View Hidden",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > View Hidden",
    "desc": "Tính năng trong bảng Project Panel",
    "cmd": "View Hidden"
  },
  {
    "name": "Zoom In",
    "key": "=",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Zoom In",
    "desc": "Phóng to timeline hoặc monitor",
    "cmd": "Zoom In"
  },
  {
    "name": "Zoom Out",
    "key": "-",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Project Panel > Zoom Out",
    "desc": "Thu nhỏ timeline hoặc monitor",
    "cmd": "Zoom Out"
  },
  {
    "name": "Properties Panel Menu",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Properties Panel > Properties Panel Menu",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Properties Panel Menu"
  },
  {
    "name": "Clear Selection",
    "key": "Backspace",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Properties Panel > Clear Selection",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Clear Selection"
  },
  {
    "name": "Nudge Selected Object down by five",
    "key": "Ctrl+Shift+Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Properties Panel > Nudge Selected Object down by five",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Nudge Selected Object down by five"
  },
  {
    "name": "Nudge Selected Object down by one",
    "key": "Ctrl+Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Properties Panel > Nudge Selected Object down by one",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Nudge Selected Object down by one"
  },
  {
    "name": "Nudge Selected Object to left by five",
    "key": "Ctrl+Shift+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Properties Panel > Nudge Selected Object to left by five",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Nudge Selected Object to left by five"
  },
  {
    "name": "Nudge Selected Object to left by one",
    "key": "Ctrl+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Properties Panel > Nudge Selected Object to left by one",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Nudge Selected Object to left by one"
  },
  {
    "name": "Nudge Selected Object to right by five",
    "key": "Ctrl+Shift+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Properties Panel > Nudge Selected Object to right by five",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Nudge Selected Object to right by five"
  },
  {
    "name": "Nudge Selected Object to right by one",
    "key": "Ctrl+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Properties Panel > Nudge Selected Object to right by one",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Nudge Selected Object to right by one"
  },
  {
    "name": "Nudge Selected Object up by five",
    "key": "Ctrl+Shift+Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Properties Panel > Nudge Selected Object up by five",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Nudge Selected Object up by five"
  },
  {
    "name": "Nudge Selected Object up by one",
    "key": "Ctrl+Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Properties Panel > Nudge Selected Object up by one",
    "desc": "Tính năng trong bảng Properties Panel",
    "cmd": "Nudge Selected Object up by one"
  },
  {
    "name": "New Sequence from Selection",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Search Panel > New Sequence from Selection",
    "desc": "Tính năng trong bảng Search Panel",
    "cmd": "New Sequence from Selection"
  },
  {
    "name": "Open in Source Monitor",
    "key": "Shift+O",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Search Panel > Open in Source Monitor",
    "desc": "Tính năng trong bảng Search Panel",
    "cmd": "Open in Source Monitor"
  },
  {
    "name": "Open in Timeline",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Search Panel > Open in Timeline",
    "desc": "Tính năng trong bảng Search Panel",
    "cmd": "Open in Timeline"
  },
  {
    "name": "Reveal in Project",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Search Panel > Reveal in Project",
    "desc": "Tính năng trong bảng Search Panel",
    "cmd": "Reveal in Project"
  },
  {
    "name": "Open Sequence in Timeline",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Open Sequence in Timeline",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Open Sequence in Timeline"
  },
  {
    "name": "Composite Video",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Composite Video",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Composite Video"
  },
  {
    "name": "Audio Waveform",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Audio Waveform",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Audio Waveform"
  },
  {
    "name": "Alpha",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > RGBA Channels > Alpha",
    "desc": "Tính năng trong bảng RGBA Channels",
    "cmd": "Alpha"
  },
  {
    "name": "Red",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > RGBA Channels > Red",
    "desc": "Tính năng trong bảng RGBA Channels",
    "cmd": "Red"
  },
  {
    "name": "Green",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > RGBA Channels > Green",
    "desc": "Tính năng trong bảng RGBA Channels",
    "cmd": "Green"
  },
  {
    "name": "Blue",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > RGBA Channels > Blue",
    "desc": "Tính năng trong bảng RGBA Channels",
    "cmd": "Blue"
  },
  {
    "name": "Video and Audio Waveform Split",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Video and Audio Waveform Split",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Video and Audio Waveform Split"
  },
  {
    "name": "Display First Field",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Display First Field",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Display First Field"
  },
  {
    "name": "Display Second Field",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Display Second Field",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Display Second Field"
  },
  {
    "name": "Display Both Fields",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Display Both Fields",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Display Both Fields"
  },
  {
    "name": "Full",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Playback Resolution > Full",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "Full"
  },
  {
    "name": "1/2",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Playback Resolution > 1/2",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "1/2"
  },
  {
    "name": "1/4",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Playback Resolution > 1/4",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "1/4"
  },
  {
    "name": "1/8",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Playback Resolution > 1/8",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "1/8"
  },
  {
    "name": "1/16",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Playback Resolution > 1/16",
    "desc": "Tính năng trong bảng Playback Resolution",
    "cmd": "1/16"
  },
  {
    "name": "Full",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Paused Resolution > Full",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "Full"
  },
  {
    "name": "1/2",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Paused Resolution > 1/2",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "1/2"
  },
  {
    "name": "1/4",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Paused Resolution > 1/4",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "1/4"
  },
  {
    "name": "1/8",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Paused Resolution > 1/8",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "1/8"
  },
  {
    "name": "1/16",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Paused Resolution > 1/16",
    "desc": "Tính năng trong bảng Paused Resolution",
    "cmd": "1/16"
  },
  {
    "name": "High Quality Playback",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > High Quality Playback",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "High Quality Playback"
  },
  {
    "name": "Gang to Active Sequence Color Management",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Monitor Color Management > Gang to Active Sequence Color Management",
    "desc": "Tính năng trong bảng Monitor Color Management",
    "cmd": "Gang to Active Sequence Color Management"
  },
  {
    "name": "Show Wide Gamut Source Media As Log",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Monitor Color Management > Show Wide Gamut Source Media As Log",
    "desc": "Tính năng trong bảng Monitor Color Management",
    "cmd": "Show Wide Gamut Source Media As Log"
  },
  {
    "name": "Show Source in Extended Dynamic Range",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Monitor Color Management > Show Source in Extended Dynamic Range",
    "desc": "Tính năng trong bảng Monitor Color Management",
    "cmd": "Show Source in Extended Dynamic Range"
  },
  {
    "name": "Show Transport Controls",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Show Transport Controls",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Show Transport Controls"
  },
  {
    "name": "Show Scroll Bars",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Show Scroll Bars",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Show Scroll Bars"
  },
  {
    "name": "Show Audio Time Units",
    "key": "",
    "cat": "audio",
    "catName": "Âm thanh & Mixer",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Show Audio Time Units",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Show Audio Time Units"
  },
  {
    "name": "Show Markers",
    "key": "",
    "cat": "markers",
    "catName": "Markers & In/Out",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Show Markers",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Show Markers"
  },
  {
    "name": "Show Dropped Frame Indicator",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Show Dropped Frame Indicator",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Show Dropped Frame Indicator"
  },
  {
    "name": "Time Ruler Numbers",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Time Ruler Numbers",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Time Ruler Numbers"
  },
  {
    "name": "Edit Cameras...",
    "key": "",
    "cat": "multicam",
    "catName": "Multi-Camera",
    "path": "Panels > Source Monitor Panel > Source Monitor Panel Menu > Edit Cameras...",
    "desc": "Tính năng trong bảng Source Monitor Panel Menu",
    "cmd": "Edit Cameras..."
  },
  {
    "name": "Add Clip to Project",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Add Clip to Project",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Add Clip to Project"
  },
  {
    "name": "Monitor Ambisonics",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Monitor Ambisonics",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Monitor Ambisonics"
  },
  {
    "name": "Play-Stop Toggle",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Source Monitor Panel > Play-Stop Toggle",
    "desc": "Phát hoặc dừng video (Space)",
    "cmd": "Play-Stop Toggle"
  },
  {
    "name": "Reveal in Project",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Reveal in Project",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Reveal in Project"
  },
  {
    "name": "Safe Margins",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Safe Margins",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Safe Margins"
  },
  {
    "name": "Source Clip: Close",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Clip: Close",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Source Clip: Close"
  },
  {
    "name": "Source Clip: Close All",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Clip: Close All",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Source Clip: Close All"
  },
  {
    "name": "Source Clip: First",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Clip: First",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Source Clip: First"
  },
  {
    "name": "Source Clip: Last",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Clip: Last",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Source Clip: Last"
  },
  {
    "name": "Source Clip: Next",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Clip: Next",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Source Clip: Next"
  },
  {
    "name": "Source Clip: Previous",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Source Clip: Previous",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Source Clip: Previous"
  },
  {
    "name": "Step Back",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Source Monitor Panel > Step Back",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Step Back"
  },
  {
    "name": "Step Forward",
    "key": "",
    "cat": "playback",
    "catName": "Playback & Điều hướng",
    "path": "Panels > Source Monitor Panel > Step Forward",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Step Forward"
  },
  {
    "name": "Toggle Transparency Grid",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Toggle Transparency Grid",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Toggle Transparency Grid"
  },
  {
    "name": "Toggle VR Video Display",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Toggle VR Video Display",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Toggle VR Video Display"
  },
  {
    "name": "VR Video - Hide Controls",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > VR Video - Hide Controls",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "VR Video - Hide Controls"
  },
  {
    "name": "VR Video Display Settings",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > VR Video Display Settings",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "VR Video Display Settings"
  },
  {
    "name": "View Caption Stream 1",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 1",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 1"
  },
  {
    "name": "View Caption Stream 2",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 2",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 2"
  },
  {
    "name": "View Caption Stream 3",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 3",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 3"
  },
  {
    "name": "View Caption Stream 4",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 4",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 4"
  },
  {
    "name": "View Caption Stream 5",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 5",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 5"
  },
  {
    "name": "View Caption Stream 6",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 6",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 6"
  },
  {
    "name": "View Caption Stream 7",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 7",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 7"
  },
  {
    "name": "View Caption Stream 8",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 8",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 8"
  },
  {
    "name": "View Caption Stream 9",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 9",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 9"
  },
  {
    "name": "View Caption Stream 10",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream 10",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream 10"
  },
  {
    "name": "View Caption Stream Enable",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Source Monitor Panel > View Caption Stream Enable",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "View Caption Stream Enable"
  },
  {
    "name": "Zoom Monitor In",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Zoom Monitor In",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Zoom Monitor In"
  },
  {
    "name": "Zoom Monitor Out",
    "key": "",
    "cat": "panels",
    "catName": "Panels & Workspace",
    "path": "Panels > Source Monitor Panel > Zoom Monitor Out",
    "desc": "Tính năng trong bảng Source Monitor Panel",
    "cmd": "Zoom Monitor Out"
  },
  {
    "name": "Automatically Set In/Out Points",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Automatically Set In/Out Points",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Automatically Set In/Out Points"
  },
  {
    "name": "Check Spelling",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Check Spelling",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Check Spelling"
  },
  {
    "name": "Create Captions",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Create Captions",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Create Captions"
  },
  {
    "name": "Decrease Font Size",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Decrease Font Size",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Decrease Font Size"
  },
  {
    "name": "Delete",
    "key": "Alt+Backspace",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Delete",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Delete"
  },
  {
    "name": "Display Disfluencies",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Display Disfluencies",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Display Disfluencies"
  },
  {
    "name": "Display Pauses",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Display Pauses",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Display Pauses"
  },
  {
    "name": "Edit Segment",
    "key": "Enter",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Edit Segment",
    "desc": "Vào chế độ chỉnh sửa câu thoại trong Text Panel",
    "cmd": "Edit Segment"
  },
  {
    "name": "Enable Auto-scrolling",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Enable Auto-scrolling",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Enable Auto-scrolling"
  },
  {
    "name": "Export Transcript",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Export Transcript",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Export Transcript"
  },
  {
    "name": "Export to CSV File",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Export to CSV File",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Export to CSV File"
  },
  {
    "name": "Export to Text File",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Export to Text File",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Export to Text File"
  },
  {
    "name": "Follow Active Monitor",
    "key": "Shift+C",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Follow Active Monitor",
    "desc": "Cuộn transcript tự động theo video đang phát",
    "cmd": "Follow Active Monitor"
  },
  {
    "name": "Import Transcript",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Import Transcript",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Import Transcript"
  },
  {
    "name": "Increase Font Size",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Increase Font Size",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Increase Font Size"
  },
  {
    "name": "Merge Segments",
    "key": "Alt+M",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Merge Segments",
    "desc": "Gộp các câu phụ đề/transcript đang chọn thành một câu",
    "cmd": "Merge Segments"
  },
  {
    "name": "Merge with Corrected Transcript",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Merge with Corrected Transcript",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Merge with Corrected Transcript"
  },
  {
    "name": "Navigate to End of Segment",
    "key": "End",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Navigate to End of Segment",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Navigate to End of Segment"
  },
  {
    "name": "Navigate to Next Line",
    "key": "Down",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Navigate to Next Line",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Navigate to Next Line"
  },
  {
    "name": "Navigate to Next Word",
    "key": "Right",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Navigate to Next Word",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Navigate to Next Word"
  },
  {
    "name": "Navigate to Previous Line",
    "key": "Up",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Navigate to Previous Line",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Navigate to Previous Line"
  },
  {
    "name": "Navigate to Previous Word",
    "key": "Left",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Navigate to Previous Word",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Navigate to Previous Word"
  },
  {
    "name": "Navigate to Start of Segment",
    "key": "Home",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Navigate to Start of Segment",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Navigate to Start of Segment"
  },
  {
    "name": "Ripple Delete",
    "key": "Backspace",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Ripple Delete",
    "desc": "Xóa đối tượng và dồn toàn bộ khoảng trống lại",
    "cmd": "Ripple Delete"
  },
  {
    "name": "Select to Next Line",
    "key": "Shift+Down",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Select to Next Line",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Select to Next Line"
  },
  {
    "name": "Select to Next Word",
    "key": "Shift+Right",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Select to Next Word",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Select to Next Word"
  },
  {
    "name": "Select to Previous Line",
    "key": "Shift+Up",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Select to Previous Line",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Select to Previous Line"
  },
  {
    "name": "Select to Previous Word",
    "key": "Shift+Left",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Select to Previous Word",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Select to Previous Word"
  },
  {
    "name": "Select to Segment End",
    "key": "Shift+End",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Select to Segment End",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Select to Segment End"
  },
  {
    "name": "Select to Segment Start",
    "key": "Shift+Home",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Select to Segment Start",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Select to Segment Start"
  },
  {
    "name": "Show Program Transcript",
    "key": "Shift+X",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Show Program Transcript",
    "desc": "Hiển thị transcript của sequence đang dựng",
    "cmd": "Show Program Transcript"
  },
  {
    "name": "Show Source Transcript",
    "key": "Shift+Z",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Show Source Transcript",
    "desc": "Hiển thị transcript của clip nguồn gốc",
    "cmd": "Show Source Transcript"
  },
  {
    "name": "Show Speakers",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Show Speakers",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Show Speakers"
  },
  {
    "name": "Show Untranscribed Sources",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Show Untranscribed Sources",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Show Untranscribed Sources"
  },
  {
    "name": "Split Segment",
    "key": "Alt+S",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Split Segment",
    "desc": "Tách câu phụ đề/transcript tại vị trí con trỏ thành hai câu",
    "cmd": "Split Segment"
  },
  {
    "name": "Translate Captions",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Text Panel > Translate Captions",
    "desc": "Tính năng trong bảng Text Panel",
    "cmd": "Translate Captions"
  },
  {
    "name": "Work Area Bar",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Work Area Bar",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Work Area Bar"
  },
  {
    "name": "Show Audio Time Units",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Show Audio Time Units",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Show Audio Time Units"
  },
  {
    "name": "Audio Waveforms Use Label Color",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Audio Waveforms Use Label Color",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Audio Waveforms Use Label Color"
  },
  {
    "name": "Rectified Audio Waveforms",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Rectified Audio Waveforms",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Rectified Audio Waveforms"
  },
  {
    "name": "Logarithmic Waveform Scaling",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Logarithmic Waveform Scaling",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Logarithmic Waveform Scaling"
  },
  {
    "name": "Time Ruler Numbers",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Time Ruler Numbers",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Time Ruler Numbers"
  },
  {
    "name": "Start Time...",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Start Time...",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Start Time..."
  },
  {
    "name": "Video Head and Tail Thumbnails",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Video Head and Tail Thumbnails",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Video Head and Tail Thumbnails"
  },
  {
    "name": "Video Head Thumbnails",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Video Head Thumbnails",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Video Head Thumbnails"
  },
  {
    "name": "Continuous Video Thumbnails",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Continuous Video Thumbnails",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Continuous Video Thumbnails"
  },
  {
    "name": "Create Preset from Sequence...",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Create Preset from Sequence...",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Create Preset from Sequence..."
  },
  {
    "name": "Reveal Sequence in Project",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Reveal Sequence in Project",
    "desc": "Tính năng trong bảng Timeline Panel Menu",
    "cmd": "Reveal Sequence in Project"
  },
  {
    "name": "Violet",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Violet",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Violet"
  },
  {
    "name": "Iris",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Iris",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Iris"
  },
  {
    "name": "Caribbean",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Caribbean",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Caribbean"
  },
  {
    "name": "Lavender",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Lavender",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Lavender"
  },
  {
    "name": "Cerulean",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Cerulean",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Cerulean"
  },
  {
    "name": "Forest",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Forest",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Forest"
  },
  {
    "name": "Rose",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Rose",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Rose"
  },
  {
    "name": "Mango",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Mango",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Mango"
  },
  {
    "name": "Purple",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Purple",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Purple"
  },
  {
    "name": "Blue",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Blue",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Blue"
  },
  {
    "name": "Teal",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Teal",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Teal"
  },
  {
    "name": "Magenta",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Magenta",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Magenta"
  },
  {
    "name": "Tan",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Tan",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Tan"
  },
  {
    "name": "Green",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Green",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Green"
  },
  {
    "name": "Brown",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Brown",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Brown"
  },
  {
    "name": "Yellow",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Timeline Panel Menu > Label > Yellow",
    "desc": "Tính năng trong bảng Label",
    "cmd": "Yellow"
  },
  {
    "name": "Activate next caption track",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Activate next caption track",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Activate next caption track"
  },
  {
    "name": "Activate previous caption track",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Activate previous caption track",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Activate previous caption track"
  },
  {
    "name": "Apply Audio Crossfade Transition",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Apply Audio Crossfade Transition",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Apply Audio Crossfade Transition"
  },
  {
    "name": "Apply Default Audio Transition From Playhead",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Apply Default Audio Transition From Playhead",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Apply Default Audio Transition From Playhead"
  },
  {
    "name": "Apply Default Audio Transition To Playhead",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Apply Default Audio Transition To Playhead",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Apply Default Audio Transition To Playhead"
  },
  {
    "name": "Apply Default Video Transition From Playhead",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Apply Default Video Transition From Playhead",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Apply Default Video Transition From Playhead"
  },
  {
    "name": "Apply Default Video Transition To Playhead",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Apply Default Video Transition To Playhead",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Apply Default Video Transition To Playhead"
  },
  {
    "name": "Apply Video Crossfade Transition",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Apply Video Crossfade Transition",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Apply Video Crossfade Transition"
  },
  {
    "name": "Apply Video Dip To White Transition",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Apply Video Dip To White Transition",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Apply Video Dip To White Transition"
  },
  {
    "name": "Apply Video Wipe Transition",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Apply Video Wipe Transition",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Apply Video Wipe Transition"
  },
  {
    "name": "Clear Selection",
    "key": "Backspace",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Clear Selection",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Clear Selection"
  },
  {
    "name": "Composite Preview During Trim",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Composite Preview During Trim",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Composite Preview During Trim"
  },
  {
    "name": "Decrease Audio Tracks Height",
    "key": "Alt+-",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Decrease Audio Tracks Height",
    "desc": "Giảm độ cao các track âm thanh",
    "cmd": "Decrease Audio Tracks Height"
  },
  {
    "name": "Decrease Video Tracks Height",
    "key": "Ctrl+-",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Decrease Video Tracks Height",
    "desc": "Giảm độ cao các track hình ảnh",
    "cmd": "Decrease Video Tracks Height"
  },
  {
    "name": "Go to next caption segment",
    "key": "Ctrl+Alt+Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Go to next caption segment",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Go to next caption segment"
  },
  {
    "name": "Go to previous caption segment",
    "key": "Ctrl+Alt+Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Go to previous caption segment",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Go to previous caption segment"
  },
  {
    "name": "Hide All Caption Tracks",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Timeline Panel > Hide All Caption Tracks",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Hide All Caption Tracks"
  },
  {
    "name": "Increase Audio Tracks Height",
    "key": "Alt+=",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Increase Audio Tracks Height",
    "desc": "Tăng độ cao các track âm thanh",
    "cmd": "Increase Audio Tracks Height"
  },
  {
    "name": "Increase Video Tracks Height",
    "key": "Ctrl+=",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Increase Video Tracks Height",
    "desc": "Tăng độ cao các track hình ảnh",
    "cmd": "Increase Video Tracks Height"
  },
  {
    "name": "Join All Through Edits",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Join All Through Edits",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Join All Through Edits"
  },
  {
    "name": "Keyframe Delete",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Keyframe Delete",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Keyframe Delete"
  },
  {
    "name": "Keyframe Interpolation - Auto Bezier",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Keyframe Interpolation - Auto Bezier",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Keyframe Interpolation - Auto Bezier"
  },
  {
    "name": "Keyframe Interpolation - Bezier",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Keyframe Interpolation - Bezier",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Keyframe Interpolation - Bezier"
  },
  {
    "name": "Keyframe Interpolation - Continuous Bezier",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Keyframe Interpolation - Continuous Bezier",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Keyframe Interpolation - Continuous Bezier"
  },
  {
    "name": "Keyframe Interpolation - Ease In",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Keyframe Interpolation - Ease In",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Keyframe Interpolation - Ease In"
  },
  {
    "name": "Keyframe Interpolation - Ease Out",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Keyframe Interpolation - Ease Out",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Keyframe Interpolation - Ease Out"
  },
  {
    "name": "Keyframe Interpolation - Hold",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Keyframe Interpolation - Hold",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Keyframe Interpolation - Hold"
  },
  {
    "name": "Keyframe Interpolation - Linear",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Keyframe Interpolation - Linear",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Keyframe Interpolation - Linear"
  },
  {
    "name": "Lock/Unlock All Audio Tracks",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Lock/Unlock All Audio Tracks",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Lock/Unlock All Audio Tracks"
  },
  {
    "name": "Lock/Unlock All Video Tracks",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Lock/Unlock All Video Tracks",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Lock/Unlock All Video Tracks"
  },
  {
    "name": "Move Playhead to Cursor",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Move Playhead to Cursor",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Move Playhead to Cursor"
  },
  {
    "name": "Nudge Clip Selection Down",
    "key": "Alt+Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Nudge Clip Selection Down",
    "desc": "Đưa clip xuống track dưới (Alt+Xuống)",
    "cmd": "Nudge Clip Selection Down"
  },
  {
    "name": "Nudge Clip Selection Left Five Frames",
    "key": "Alt+Shift+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Nudge Clip Selection Left Five Frames",
    "desc": "Dịch clip sang trái 5 frame (Alt+Shift+Trái)",
    "cmd": "Nudge Clip Selection Left Five Frames"
  },
  {
    "name": "Nudge Clip Selection Left One Frame",
    "key": "Alt+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Nudge Clip Selection Left One Frame",
    "desc": "Dịch clip sang trái 1 frame (Alt+Trái)",
    "cmd": "Nudge Clip Selection Left One Frame"
  },
  {
    "name": "Nudge Clip Selection Right Five Frames",
    "key": "Alt+Shift+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Nudge Clip Selection Right Five Frames",
    "desc": "Dịch clip sang phải 5 frame (Alt+Shift+Phải)",
    "cmd": "Nudge Clip Selection Right Five Frames"
  },
  {
    "name": "Nudge Clip Selection Right One Frame",
    "key": "Alt+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Nudge Clip Selection Right One Frame",
    "desc": "Dịch clip sang phải 1 frame (Alt+Phải)",
    "cmd": "Nudge Clip Selection Right One Frame"
  },
  {
    "name": "Nudge Clip Selection Up",
    "key": "Alt+Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Nudge Clip Selection Up",
    "desc": "Đưa clip lên track trên (Alt+Lên)",
    "cmd": "Nudge Clip Selection Up"
  },
  {
    "name": "Open Text panel",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Open Text panel",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Open Text panel"
  },
  {
    "name": "Paste Insert To Same Track",
    "key": "Ctrl+Shift+V",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Paste Insert To Same Track",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Paste Insert To Same Track"
  },
  {
    "name": "Paste Insert To Target Track",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Paste Insert To Target Track",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Paste Insert To Target Track"
  },
  {
    "name": "Paste To Same Track",
    "key": "Ctrl+V",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Paste To Same Track",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Paste To Same Track"
  },
  {
    "name": "Paste To Target Track",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Paste To Target Track",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Paste To Target Track"
  },
  {
    "name": "Reveal In Project",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Reveal In Project",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Reveal In Project"
  },
  {
    "name": "Ripple Delete",
    "key": "Alt+Backspace",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Ripple Delete",
    "desc": "Xóa đối tượng và dồn toàn bộ khoảng trống lại",
    "cmd": "Ripple Delete"
  },
  {
    "name": "Set Work Area Bar In Point",
    "key": "Alt+[",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Set Work Area Bar In Point",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Set Work Area Bar In Point"
  },
  {
    "name": "Set Work Area Bar Out Point",
    "key": "Alt+]",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Set Work Area Bar Out Point",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Set Work Area Bar Out Point"
  },
  {
    "name": "Show AI-generated Labels",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show AI-generated Labels",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show AI-generated Labels"
  },
  {
    "name": "Show Active Caption Tracks",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Timeline Panel > Show Active Caption Tracks",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Active Caption Tracks"
  },
  {
    "name": "Show All Caption Tracks",
    "key": "",
    "cat": "text",
    "catName": "Text Panel & Phụ đề",
    "path": "Panels > Timeline Panel > Show All Caption Tracks",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show All Caption Tracks"
  },
  {
    "name": "Show Audio Channel Labels",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Audio Channel Labels",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Audio Channel Labels"
  },
  {
    "name": "Show Audio Clip Header on Small Tracks",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Audio Clip Header on Small Tracks",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Audio Clip Header on Small Tracks"
  },
  {
    "name": "Show Audio Keyframes",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Audio Keyframes",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Audio Keyframes"
  },
  {
    "name": "Show Audio Names",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Audio Names",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Audio Names"
  },
  {
    "name": "Show Audio Waveforms",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Audio Waveforms",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Audio Waveforms"
  },
  {
    "name": "Show Clip Markers",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Clip Markers",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Clip Markers"
  },
  {
    "name": "Show Duplicate Frame Markers",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Duplicate Frame Markers",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Duplicate Frame Markers"
  },
  {
    "name": "Show Essential Sound Badges",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Essential Sound Badges",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Essential Sound Badges"
  },
  {
    "name": "Show FX Badges",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show FX Badges",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show FX Badges"
  },
  {
    "name": "Show Next Screen",
    "key": "Page Down",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Next Screen",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Next Screen"
  },
  {
    "name": "Show Previous Screen",
    "key": "Page Up",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Previous Screen",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Previous Screen"
  },
  {
    "name": "Show Proxy Badges",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Proxy Badges",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Proxy Badges"
  },
  {
    "name": "Show Sequence Label Color",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Sequence Label Color",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Sequence Label Color"
  },
  {
    "name": "Show Source Clip Name and Label",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Source Clip Name and Label",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Source Clip Name and Label"
  },
  {
    "name": "Show Video Keyframes",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Video Keyframes",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Video Keyframes"
  },
  {
    "name": "Show Video Names",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Video Names",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Video Names"
  },
  {
    "name": "Show Video Thumbnails",
    "key": "",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Show Video Thumbnails",
    "desc": "Tính năng trong bảng Timeline Panel",
    "cmd": "Show Video Thumbnails"
  },
  {
    "name": "Slide Clip Selection Left Five Frames",
    "key": "Alt+Shift+,",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Slide Clip Selection Left Five Frames",
    "desc": "Slide clip sang trái 5 frame",
    "cmd": "Slide Clip Selection Left Five Frames"
  },
  {
    "name": "Slide Clip Selection Left One Frame",
    "key": "Alt+,",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Slide Clip Selection Left One Frame",
    "desc": "Slide clip sang trái 1 frame",
    "cmd": "Slide Clip Selection Left One Frame"
  },
  {
    "name": "Slide Clip Selection Right Five Frames",
    "key": "Alt+Shift+.",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Slide Clip Selection Right Five Frames",
    "desc": "Slide clip sang phải 5 frame",
    "cmd": "Slide Clip Selection Right Five Frames"
  },
  {
    "name": "Slide Clip Selection Right One Frame",
    "key": "Alt+.",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Slide Clip Selection Right One Frame",
    "desc": "Slide clip sang phải 1 frame",
    "cmd": "Slide Clip Selection Right One Frame"
  },
  {
    "name": "Slip Clip Selection Left Five Frames",
    "key": "Ctrl+Alt+Shift+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Slip Clip Selection Left Five Frames",
    "desc": "Slip nội dung clip sang trái 5 frame",
    "cmd": "Slip Clip Selection Left Five Frames"
  },
  {
    "name": "Slip Clip Selection Left One Frame",
    "key": "Ctrl+Alt+Left",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Slip Clip Selection Left One Frame",
    "desc": "Slip nội dung clip sang trái 1 frame",
    "cmd": "Slip Clip Selection Left One Frame"
  },
  {
    "name": "Slip Clip Selection Right Five Frames",
    "key": "Ctrl+Alt+Shift+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Slip Clip Selection Right Five Frames",
    "desc": "Slip nội dung clip sang phải 5 frame",
    "cmd": "Slip Clip Selection Right Five Frames"
  },
  {
    "name": "Slip Clip Selection Right One Frame",
    "key": "Ctrl+Alt+Right",
    "cat": "timeline",
    "catName": "Timeline & Trim",
    "path": "Panels > Timeline Panel > Slip Clip Selection Right One Frame",
    "desc": "Slip nội dung clip sang phải 1 frame",
    "cmd": "Slip Clip Selection Right One Frame"
  }
];

  function executeCommand(cmdName) {
    if (!window.NX || !window.NX.evalHost) {
      alert("Lỗi: Không kết nối được với Premiere Pro.");
      return;
    }
    window.NX.log("▶ Chạy lệnh Premiere: " + cmdName);
    window.NX.evalHost("jesExecuteCommand(" + JSON.stringify(cmdName) + ")").then(function (r) {
      var j; try { j = JSON.parse(r); } catch (e) {}
      if (j && j.ok) {
        window.NX.log("✔ Đã thực thi lệnh: " + cmdName, "#6fd08c");
        showToast("✔ Đã chạy: " + cmdName);
      } else {
        var err = (j && j.error) ? j.error : String(r);
        window.NX.log("⚠ Không thể chạy trực tiếp '" + cmdName + "' (lệnh cần mở cửa sổ hoặc chọn đối tượng): " + err, "#f0b43c");
        showToast("⚠ " + err);
      }
    }).catch(function (e) {
      window.NX.log("✖ Lỗi chạy lệnh: " + e.message, "#ef5b5b");
      showToast("✖ Lỗi: " + e.message);
    });
  }

  function showToast(msg) {
    var t = $("keysToast");
    if (!t) {
      t = document.createElement("div");
      t.id = "keysToast";
      t.style.cssText = "position:fixed;bottom:18px;right:18px;background:#232529;color:#dcdfe4;border:1px solid #4fd1c5;padding:8px 14px;border-radius:8px;font-size:11px;z-index:99;box-shadow:0 6px 20px rgba(0,0,0,.6);transition:opacity .2s;";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.display = "block";
    t.style.opacity = "1";
    clearTimeout(t._timer);
    t._timer = setTimeout(function () {
      t.style.opacity = "0";
      setTimeout(function () { t.style.display = "none"; }, 200);
    }, 2600);
  }

  function renderKeys(filterText, selectedCat, onlyShortcuts) {
    var tbody = $("keysTbody");
    var statsEl = $("keysStats");
    if (!tbody) return;

    var q = (filterText || "").trim().toLowerCase();
    var cat = selectedCat || "all";
    var onlyKey = !!onlyShortcuts;

    var matched = ITEMS.filter(function (it) {
      if (onlyKey && !it.key) return false;
      if (cat !== "all" && it.cat !== cat) return false;
      if (!q) return true;
      return it.name.toLowerCase().indexOf(q) >= 0 ||
             (it.key && it.key.toLowerCase().indexOf(q) >= 0) ||
             (it.desc && it.desc.toLowerCase().indexOf(q) >= 0) ||
             (it.path && it.path.toLowerCase().indexOf(q) >= 0);
    });

    if (statsEl) {
      statsEl.textContent = "Tìm thấy " + matched.length + " / " + ITEMS.length + " tính năng" + (onlyKey ? " (có phím tắt)" : "");
    }

    var html = "";
    var limit = 250;
    var displayed = matched.slice(0, limit);

    for (var i = 0; i < displayed.length; i++) {
      var it = displayed[i];
      var keyHtml = it.key ? renderKeyBadge(it.key) : "<span class='muted' style='font-size:10px'>—</span>";
      var runBtn = "<button class='btn btn-run' data-cmd='" + escapeHtml(it.name).replace(/'/g, "&#39;") + "' title='Chạy lệnh này trực tiếp trong Premiere'>▶ Chạy</button>";

      html += "<tr class='key-row'>" +
              "<td><div class='key-name'>" + escapeHtml(it.name) + "</div><div class='key-desc'>" + escapeHtml(it.desc) + "</div></td>" +
              "<td style='white-space:nowrap'>" + keyHtml + "</td>" +
              "<td><span class='chip'>" + escapeHtml(it.catName) + "</span><div class='key-path'>" + escapeHtml(it.path) + "</div></td>" +
              "<td style='text-align:right'>" + runBtn + "</td>" +
              "</tr>";
    }

    if (!displayed.length) {
      html = "<tr><td colspan='4' class='empty' style='padding:24px'>Không tìm thấy phím tắt phù hợp với từ khóa '" + escapeHtml(q) + "'</td></tr>";
    } else if (matched.length > limit) {
      html += "<tr><td colspan='4' class='muted' style='text-align:center;padding:8px'>Hiển thị " + limit + " kết quả đầu tiên. Hãy gõ từ khóa cụ thể hơn để lọc.</td></tr>";
    }

    tbody.innerHTML = html;
    if (!tbody._bound) {                                   // one delegated handler instead of 250 listeners per render
      tbody._bound = true;
      tbody.addEventListener("click", function (ev) {
        var b = ev.target.closest && ev.target.closest(".btn-run"); if (!b) return;
        ev.stopPropagation(); var cmd = b.getAttribute("data-cmd"); if (cmd) executeCommand(cmd);
      });
    }
  }

  function renderKeyBadge(keyStr) {
    var parts = keyStr.split("+");
    var res = [];
    for (var i = 0; i < parts.length; i++) {
      var k = parts[i].trim();
      res.push("<kbd>" + escapeHtml(k) + "</kbd>");
    }
    return res.join("<span class='kplus'>+</span>");
  }

  function escapeHtml(s) {
    return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function init() {
    var input = $("keysSearch");
    var catSel = $("keysCat");
    var onlyChk = $("keysOnly");

    if (catSel) {
      var catHtml = "<option value='all'>Tất cả phân loại (" + ITEMS.length + ")</option>";
      Object.keys(CATEGORIES).forEach(function (k) {
        var count = ITEMS.filter(function (x) { return x.cat === k; }).length;
        catHtml += "<option value='" + k + "'>" + CATEGORIES[k][0] + " (" + count + ")</option>";
      });
      catSel.innerHTML = catHtml;
    }

    function update() {
      renderKeys(input ? input.value : "", catSel ? catSel.value : "all", onlyChk ? onlyChk.checked : false);
    }

    if (input) {
      var deb;
      input.addEventListener("input", function () {
        clearTimeout(deb);
        deb = setTimeout(update, 120);
      });
    }
    if (catSel) catSel.addEventListener("change", update);
    if (onlyChk) onlyChk.addEventListener("change", update);

    // v1.8: first render when the tab is opened (250 rows at panel start slowed every launch)
    var done = false;
    function first() { if (done) return; done = true; update(); }
    document.addEventListener("nxtab", function (e) { if (e.detail === "keys") first(); });
  }

  document.addEventListener("DOMContentLoaded", init);

  window.JESKEYS = {
    CATEGORIES: CATEGORIES,
    ITEMS: ITEMS,
    execute: executeCommand,
    render: renderKeys
  };
})();
