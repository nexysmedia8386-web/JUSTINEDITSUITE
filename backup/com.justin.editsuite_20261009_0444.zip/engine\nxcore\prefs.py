"""Editor profile — what Justin EDIT Suite has learned from the editor's own decisions.

Stored at %APPDATA%/JustinEditSuite/profile.json (override: env JES_PROFILE), shared by the panel (JS writes events)
and the engine (Python derives rules). Only aggregated counters + a short history are kept.

stats (all incremental, exponential moving averages where it makes sense):
  broll_len   — shot length of b-roll the editor keeps (from finished timelines / trims)
  talk_len    — length of dialogue pieces kept
  slowmo      — 50/60p b-roll shots seen vs slowed, mean speed used
  rotate      — tilt fixes kept vs reverted / applied by hand
  take        — when two takes compete: steadier/better-framed one kept vs the other
  triage      — groups needing upscale / wrong orientation: excluded vs kept
  quality     — quality of shots the editor removes vs keeps (sets the minimum)
  sfx         — density picked
  dissolve    — cuts vs dissolves, typical dissolve length
rules (derived, used as defaults; each needs enough evidence):
  broll_dur, broll_dur_static, auto_slowmo_60p, slowmo_speed, auto_rotate, quality_weight, min_quality,
  triage_auto_exclude_upscale, sfx_density, dissolve_s
"""
import json
import os
import time

MIN_N = 3


def path():
    p = os.environ.get("JES_PROFILE")
    if p:
        return p
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "JustinEditSuite", "profile.json")


def load():
    try:
        return json.load(open(path(), encoding="utf-8"))
    except Exception:
        return {"version": 1, "stats": {}, "history": []}


def save(P):
    P["rules"] = derive(P)
    P["updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(path()), exist_ok=True)
    tmp = path() + ".tmp"
    json.dump(P, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    os.replace(tmp, path())
    return P


def ema(stat, x, alpha=0.2):
    """Running mean that follows the editor's recent habits (and a plain count)."""
    n = stat.get("n", 0)
    stat["mean"] = x if n == 0 else stat["mean"] * (1 - alpha) + x * alpha
    stat["n"] = n + 1
    return stat


def bump(P, key, field, by=1):
    s = P.setdefault("stats", {}).setdefault(key, {})
    s[field] = s.get(field, 0) + by
    return s


def note(P, kind, text):
    P.setdefault("history", []).append({"t": time.strftime("%Y-%m-%d %H:%M"), "kind": kind, "text": text})
    P["history"] = P["history"][-200:]


def derive(P):
    s = P.get("stats", {})
    r = {}
    bl = s.get("broll_len", {})
    if bl.get("n", 0) >= MIN_N:
        r["broll_dur"] = round(min(4.5, max(1.0, bl["mean"])), 2)
        r["broll_dur_static"] = round(max(0.9, r["broll_dur"] * 0.8), 2)
    sm = s.get("slowmo", {})
    if sm.get("seen", 0) >= 5:
        rate = sm.get("slowed", 0) / max(1, sm["seen"])
        r["auto_slowmo_60p"] = rate >= 0.35
        r["slowmo_rate"] = round(rate, 2)
        if sm.get("speed_n", 0) >= MIN_N:
            r["slowmo_speed"] = int(round(max(20, min(80, sm["speed_sum"] / sm["speed_n"])) / 5) * 5)
    ro = s.get("rotate", {})
    if ro.get("kept", 0) + ro.get("reverted", 0) + ro.get("manual", 0) >= MIN_N:
        r["auto_rotate"] = ro.get("reverted", 0) <= 0.3 * (ro.get("kept", 0) + ro.get("manual", 0) + ro.get("reverted", 0))
    tk = s.get("take", {})
    if tk.get("stab_win", 0) + tk.get("stab_loss", 0) >= MIN_N:
        w = tk["stab_win"] / (tk["stab_win"] + tk["stab_loss"])
        r["quality_weight"] = round(0.04 + 0.2 * w, 3)          # 0.04 (ignores steadiness) … 0.24 (always the steadier take)
    q = s.get("quality", {})
    if q.get("removed_n", 0) >= MIN_N and q.get("kept_n", 0) >= MIN_N:
        rm, kp = q["removed_sum"] / q["removed_n"], q["kept_sum"] / q["kept_n"]
        if kp - rm >= 8:
            r["min_quality"] = int(round((rm + kp) / 2))
    tr = s.get("triage", {})
    if tr.get("upscale_excluded", 0) + tr.get("upscale_kept", 0) >= 2:
        r["triage_auto_exclude_upscale"] = tr.get("upscale_excluded", 0) >= 2 * tr.get("upscale_kept", 0)
    sf = s.get("sfx", {})
    if sum(sf.get(k, 0) for k in ("light", "medium", "heavy")) >= MIN_N:
        r["sfx_density"] = max(("light", "medium", "heavy"), key=lambda k: sf.get(k, 0))
    ds = s.get("dissolve", {})
    if ds.get("n", 0) >= MIN_N:
        r["dissolve_s"] = round(ds["mean"], 2)
        r["dissolve_rate"] = round(ds.get("n", 0) / max(1, ds.get("n", 0) + s.get("cuts", {}).get("n", 0)), 2)
    return r


def rules():
    return derive(load())


def asm_overrides():
    """Rules translated into assemble/brollpick config keys (only confident ones)."""
    r = rules()
    out = {}
    for k in ("broll_dur", "broll_dur_static", "slowmo_speed", "quality_weight", "min_quality"):
        if k in r:
            out[k] = r[k]
    if "auto_slowmo_60p" in r:              # rule name (panel) → the key assemble actually reads
        out["auto_slowmo"] = r["auto_slowmo_60p"]
    if "auto_rotate" in r:
        out["auto_rotate"] = r["auto_rotate"]
    return out
