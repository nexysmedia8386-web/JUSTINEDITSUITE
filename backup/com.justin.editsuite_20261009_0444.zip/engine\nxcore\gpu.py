"""GPU selection shared by the engine — Windows/Linux: NVIDIA CUDA · macOS: Apple VideoToolbox (decode) + MLX (Whisper).

The panel's "GPU" setting arrives as the legacy `cuda` flag everywhere; on a Mac it means "use the Apple GPU":
  • ffmpeg decode   → -hwaccel videotoolbox (H.264/HEVC incl. 10-bit 4:2:2 on Apple Silicon), CPU fallback as before
  • Whisper         → mlx-whisper on the Metal GPU (faster-whisper/CTranslate2 has no Metal backend → CPU only on Mac)
"""
import platform
import sys

IS_MAC = sys.platform == "darwin"
IS_APPLE_SILICON = IS_MAC and platform.machine() in ("arm64", "aarch64")


def name():
    return "videotoolbox" if IS_MAC else "cuda"


def hwaccel_args(use_gpu):
    """ffmpeg input args for hardware decode (frames come back to RAM)."""
    if not use_gpu:
        return []
    return ["-hwaccel", "videotoolbox"] if IS_MAC else ["-hwaccel", "cuda"]


# Whisper model ids → MLX conversions on the Hugging Face hub (mlx-community)
MLX_REPOS = {
    "large-v3": "mlx-community/whisper-large-v3-mlx",
    "large-v3-turbo": "mlx-community/whisper-large-v3-turbo",
    "turbo": "mlx-community/whisper-large-v3-turbo",
    "medium": "mlx-community/whisper-medium-mlx",
    "small": "mlx-community/whisper-small-mlx",
    "base": "mlx-community/whisper-base-mlx",
}


class _Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)


class MLXWhisper:
    """Apple Silicon Whisper (mlx-whisper) behind the faster-whisper call shape used by nxcut transcribe:
    .transcribe(audio, language=, vad_filter=, vad_parameters=, word_timestamps=, initial_prompt=, …) → (segments, info)
    with segment.start/end/text/avg_logprob/no_speech_prob/compression_ratio/words[word,start,end,probability]."""

    def __init__(self, model):
        import mlx_whisper                      # pip install mlx-whisper (Apple Silicon only)
        self._mw = mlx_whisper
        self.repo = MLX_REPOS.get(model, model if "/" in str(model) else MLX_REPOS["large-v3-turbo"])

    def transcribe(self, audio, language=None, vad_filter=False, vad_parameters=None, condition_on_previous_text=False,
                   word_timestamps=True, initial_prompt=None, beam_size=None, batch_size=None, **_):
        clip = "0"
        if vad_filter:                          # same Silero VAD as on Windows → only speech goes to the GPU
            try:
                from faster_whisper.vad import get_speech_timestamps, VadOptions
                vp = dict(vad_parameters or {})
                ts = get_speech_timestamps(audio, VadOptions(**vp))
                if not ts:
                    return [], None
                clip = [x for t in ts for x in (round(t["start"] / 16000.0, 3), round(t["end"] / 16000.0, 3))]
            except Exception:
                clip = "0"
        # beam search is not implemented in mlx-whisper (greedy + temperature fallback) — beam_size is ignored
        r = self._mw.transcribe(audio, path_or_hf_repo=self.repo, language=language, word_timestamps=word_timestamps,
                                condition_on_previous_text=condition_on_previous_text, initial_prompt=initial_prompt,
                                clip_timestamps=clip, verbose=None)
        segs = []
        for s in r.get("segments") or []:
            words = [_Obj(start=float(w.get("start", 0)), end=float(w.get("end", 0)), word=str(w.get("word", "")),
                          probability=float(w.get("probability", 1.0))) for w in (s.get("words") or [])]
            segs.append(_Obj(start=float(s.get("start", 0)), end=float(s.get("end", 0)), text=str(s.get("text", "")),
                             avg_logprob=float(s.get("avg_logprob", 0.0)), no_speech_prob=float(s.get("no_speech_prob", 0.0)),
                             compression_ratio=float(s.get("compression_ratio", 1.0)), words=words))
        return segs, None
